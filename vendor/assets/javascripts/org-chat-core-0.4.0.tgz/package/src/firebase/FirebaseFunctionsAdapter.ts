import { getApp, getApps, initializeApp } from "firebase/app";
import { getFunctions, httpsCallable } from "firebase/functions";
import { MediaAdapter } from "../ChatClient.js";

function ensureApp(firebaseConfig: Record<string, unknown>) {
  const existing = getApps();
  if (existing.length > 0) {
    return getApp();
  }
  return initializeApp(firebaseConfig);
}

async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(",")[1];
      if (!base64) {
        reject(new Error("Nie udało się przekonwertować pliku na Base64"));
        return;
      }
      resolve(base64);
    };
    reader.onerror = () => reject(new Error("Błąd odczytu pliku"));
    reader.readAsDataURL(file);
  });
}

function validateImage(file: File): void {
  if (!file.type.startsWith("image/")) {
    throw new Error("Dozwolone są tylko pliki graficzne");
  }
  if (file.size > 5 * 1024 * 1024) {
    throw new Error("Zdjęcie jest za duże (maksymalnie 5MB)");
  }
}

export class FirebaseFunctionsAdapter implements MediaAdapter {
  private readonly firebaseConfig: Record<string, unknown>;

  constructor(params: { firebaseConfig: Record<string, unknown> }) {
    this.firebaseConfig = params.firebaseConfig;
  }

  async uploadImage(file: File): Promise<string> {
    validateImage(file);
    const functions = getFunctions(ensureApp(this.firebaseConfig));
    const uploadFn = httpsCallable<
      { imageBase64: string; mimeType: string; fileName: string },
      { url: string }
    >(functions, "uploadImage");

    const base64 = await fileToBase64(file);
    const result = await uploadFn({
      imageBase64: base64,
      mimeType: file.type,
      fileName: file.name,
    });

    if (!result.data?.url) {
      throw new Error("Brak adresu URL zwróconego przez uploadImage");
    }
    return result.data.url;
  }

  async uploadImageBase64(data: { base64: string; mimeType: string; fileName: string }): Promise<string> {
    if (!data.mimeType.startsWith("image/")) {
      throw new Error("Dozwolone są tylko pliki graficzne");
    }
    // Estimate size from base64: base64 length * 3/4 = binary size
    const estimatedSize = Math.ceil((data.base64.length * 3) / 4);
    if (estimatedSize > 5 * 1024 * 1024) {
      throw new Error("Zdjęcie jest za duże (maksymalnie 5MB)");
    }

    const functions = getFunctions(ensureApp(this.firebaseConfig));
    const uploadFn = httpsCallable<
      { imageBase64: string; mimeType: string; fileName: string },
      { url: string }
    >(functions, "uploadImage");

    const result = await uploadFn({
      imageBase64: data.base64,
      mimeType: data.mimeType,
      fileName: data.fileName,
    });

    if (!result.data?.url) {
      throw new Error("Brak adresu URL zwróconego przez uploadImage");
    }
    return result.data.url;
  }
}
