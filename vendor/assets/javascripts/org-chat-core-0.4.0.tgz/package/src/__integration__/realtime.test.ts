/**
 * Integration test: Real-time Subscriptions
 * Tests real-time message delivery, thread updates, and typing indicators
 */
import { describe, it, expect, beforeAll, afterEach, afterAll } from "vitest";
import {
  createTestUser,
  initializeAdmin,
  clearFirestore,
  cleanupTestUsers,
  wait,
  initializeTestData,
  getAdmin,
  type TestUser,
} from "./setup.js";
import type { Message } from "../types.js";

let userA: TestUser;
let userB: TestUser;

beforeAll(async () => {
  await initializeAdmin();
  userA = await createTestUser("user-a");
  userB = await createTestUser("user-b");
});

afterEach(async () => {
  await clearFirestore();
  await wait(500);
});

afterAll(async () => {
  await cleanupTestUsers();
});

describe("Real-time Subscriptions", () => {
  it("subscribeToMessages otrzymuje wiadomości w czasie rzeczywistym", async () => {
    await initializeTestData(["user-a", "user-b"]);

    // User A creates thread
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true,
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "Initial message",
      },
    });

    await wait(500);

    // User B subscribes to messages
    const receivedMessages: Message[] = [];
    const unsubscribe = userB.adapter.subscribeToMessages(thread.id, (message) => {
      receivedMessages.push(message);
    });

    await wait(500);

    // User A sends new message
    const newMessage = await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Real-time message",
      },
    });

    // Wait for subscription to receive message
    await wait(1000);

    // Verify User B received the message via subscription
    expect(receivedMessages.length).toBeGreaterThan(0);
    const rtMessage = receivedMessages.find((m) => m.text === "Real-time message");
    expect(rtMessage).toBeDefined();
    expect(rtMessage?.senderId).toBe("user-a");

    unsubscribe();
  });

  it("subscribeToThreads otrzymuje nowe wątki w czasie rzeczywistym", async () => {
    await initializeTestData(["user-a", "user-b"]);

    // User B subscribes to threads
    const receivedThreads: any[] = [];
    const unsubscribe = userB.adapter.subscribeToThreads("user-b", (threads) => {
      receivedThreads.push([...threads]);
    });

    await wait(500);

    // User A creates thread with User B
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true,
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "Hello User B!",
      },
    });

    // Wait for subscription to receive thread
    await wait(1000);

    // Verify User B received the thread via subscription
    expect(receivedThreads.length).toBeGreaterThan(0);
    const latestThreads = receivedThreads[receivedThreads.length - 1];
    const newThread = latestThreads.find((t: any) => t.id === thread.id);
    expect(newThread).toBeDefined();
    expect(newThread.members).toContain("user-b");

    unsubscribe();
  });

  it("subscribeToTyping pokazuje gdy użytkownik pisze", async () => {
    await initializeTestData(["user-a", "user-b"]);

    // Create thread
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true,
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "Hello",
      },
    });

    await wait(500);

    // User B subscribes to typing indicators
    const typingUsers: string[][] = [];
    const unsubscribe = userB.adapter.subscribeToTyping(thread.id, (userIds) => {
      typingUsers.push([...userIds]);
    });

    await wait(500);

    // User A starts typing
    await userA.adapter.setTyping(thread.id, "user-a", true);
    await wait(1000);

    // Verify User B received typing indicator
    expect(typingUsers.length).toBeGreaterThan(0);
    const latestTyping = typingUsers[typingUsers.length - 1];
    expect(latestTyping).toContain("user-a");

    // User A stops typing
    await userA.adapter.setTyping(thread.id, "user-a", false);
    await wait(1000);

    // Verify typing indicator cleared
    const finalTyping = typingUsers[typingUsers.length - 1];
    expect(finalTyping).not.toContain("user-a");

    unsubscribe();
  });

  it("unsubscribe zatrzymuje otrzymywanie aktualizacji", async () => {
    await initializeTestData(["user-a", "user-b"]);

    // Create thread
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true,
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "Initial",
      },
    });

    await wait(500);

    // User B subscribes
    const receivedMessages: Message[] = [];
    const unsubscribe = userB.adapter.subscribeToMessages(thread.id, (message) => {
      receivedMessages.push(message);
    });

    await wait(500);

    // Send message while subscribed
    await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message 1",
      },
    });

    await wait(1000);
    const countBeforeUnsubscribe = receivedMessages.length;
    expect(countBeforeUnsubscribe).toBeGreaterThan(0);

    // Unsubscribe
    unsubscribe();
    await wait(500);

    // Send message after unsubscribe
    await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message 2",
      },
    });

    await wait(1000);

    // Verify no new messages received after unsubscribe
    expect(receivedMessages.length).toBe(countBeforeUnsubscribe);
  });
});
