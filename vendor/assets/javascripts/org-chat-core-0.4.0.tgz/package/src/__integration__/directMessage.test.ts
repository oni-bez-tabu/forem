/**
 * Integration test: Direct Message Flow
 * Tests full end-to-end flow for direct messaging with WAIT_FOR_REPLY
 */
import { describe, it, expect, beforeAll, afterEach, afterAll } from "vitest";
import {
  createTestUser,
  initializeAdmin,
  clearFirestore,
  cleanupTestUsers,
  wait,
  simulateDirectUnlock,
  simulateLastMessageUpdate,
  initializeTestData,
  getAdmin,
  type TestUser,
} from "./setup.js";
import * as admin from "firebase-admin";

let userA: TestUser;
let userB: TestUser;

beforeAll(async () => {
  await initializeAdmin();
  userA = await createTestUser("user-a");
  userB = await createTestUser("user-b");
});

afterEach(async () => {
  await clearFirestore();
  await wait(500); // Wait for cleanup to propagate
});

afterAll(async () => {
  await cleanupTestUsers();
});

describe("Direct Message Flow", () => {
  it("końcowy flow: WAIT_FOR_REPLY blokuje drugą wiadomość do odpowiedzi", async () => {
    const { adminDb } = getAdmin();

    // Initialize test data (userBlocks etc.)
    await initializeTestData(["user-a", "user-b"]);

    // Step 1: User A creates direct thread and sends first message
    const { thread, message: firstMessage } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: false,
      },
      message: {
        threadId: "", // Will be set by adapter
        senderId: "user-a",
        type: "text",
        text: "Hello from User A!",
      },
    });

    expect(thread.type).toBe("direct");
    expect(thread.members).toEqual(["user-a", "user-b"]);
    expect(firstMessage.text).toBe("Hello from User A!");

    // Simulate Cloud Function: Update thread with lastMessage and directUnlocked=false
    await adminDb.collection("threads").doc(thread.id).update({
      directUnlocked: false,
      lastMessage: {
        id: firstMessage.id,
        senderId: firstMessage.senderId,
        text: firstMessage.text,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      },
    });

    await wait(500);

    // Verify directUnlocked is false
    const threadAfterFirst = await userA.adapter.getThread(thread.id);
    expect(threadAfterFirst?.directUnlocked).toBe(false);

    // Step 2: User B receives thread
    const threadsForB = await userB.adapter.getThreadsForUser("user-b");
    const threadForB = threadsForB.find((t) => t.id === thread.id);
    expect(threadForB).toBeDefined();
    expect(threadForB?.lastMessage?.text).toBe("Hello from User A!");

    // Step 3: User A tries to send second message - WAIT_FOR_REPLY should block
    await expect(
      userA.messageService.sendMessage({
        threadId: thread.id,
        message: {
          text: "Second message (should be blocked)",
        },
      })
    ).rejects.toThrow("Wait for the other user to reply");

    // Step 4: User B sends reply
    const replyMessage = await userB.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Reply from User B",
      },
    });

    expect((replyMessage as any).text).toBe("Reply from User B");

    // Simulate Cloud Function: Unlock direct thread after reply
    await simulateDirectUnlock(thread.id);
    await simulateLastMessageUpdate(thread.id, {
      id: (replyMessage as any).id,
      senderId: (replyMessage as any).senderId,
      text: (replyMessage as any).text,
    });

    await wait(500);

    // Step 5: Verify directUnlocked is now true
    const threadAfterReply = await userA.adapter.getThread(thread.id);
    expect(threadAfterReply?.directUnlocked).toBe(true);

    // Step 6: User A can now send another message
    const thirdMessage = await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Third message (now allowed)",
      },
    });

    expect((thirdMessage as any).text).toBe("Third message (now allowed)");

    // Verify all messages are in thread
    const messages = await userA.adapter.listMessages(thread.id, { limit: 10 });
    expect(messages.length).toBe(3);
    expect(messages.map((m) => m.text)).toEqual([
      "Hello from User A!",
      "Reply from User B",
      "Third message (now allowed)",
    ]);
  });

  it("pozwala na kolejne wiadomości po pierwszej odpowiedzi", async () => {
    const { adminDb } = getAdmin();

    // Initialize test data (userBlocks etc.)
    await initializeTestData(["user-a", "user-b"]);

    // Create thread and send first message
    const { thread, message: firstMessage } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: false,
      },
      message: {
        threadId: "", // Will be set by adapter
        senderId: "user-a",
        type: "text",
        text: "Initial message",
      },
    });

    // Simulate Cloud Function setup
    await adminDb.collection("threads").doc(thread.id).update({
      directUnlocked: false,
      lastMessage: {
        id: firstMessage.id,
        senderId: firstMessage.senderId,
        text: firstMessage.text,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      },
    });

    await wait(500);

    // User B replies (first reply unlocks conversation)
    const reply = await userB.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "First reply",
      },
    });

    // Simulate unlock
    await simulateDirectUnlock(thread.id);
    await wait(500);

    // Now both users can send multiple messages
    await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message 2 from A",
      },
    });

    await userB.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message 2 from B",
      },
    });

    await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message 3 from A",
      },
    });

    await wait(500);

    // Verify all messages exist
    const messages = await userA.adapter.listMessages(thread.id, { limit: 10 });
    expect(messages.length).toBe(5);
  });
});
