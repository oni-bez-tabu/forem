/**
 * Integration test: User Blocking Flow
 * Tests end-to-end blocking and unblocking between users
 */
import { describe, it, expect, beforeAll, afterEach, afterAll } from "vitest";
import {
  createTestUser,
  initializeAdmin,
  clearFirestore,
  cleanupTestUsers,
  wait,
  initializeTestData,
  getAdmin,
  type TestUser,
} from "./setup.js";
import * as admin from "firebase-admin";

let userA: TestUser;
let userB: TestUser;

beforeAll(async () => {
  await initializeAdmin();
  userA = await createTestUser("user-a");
  userB = await createTestUser("user-b");
});

afterEach(async () => {
  await clearFirestore();
  await wait(500);
});

afterAll(async () => {
  await cleanupTestUsers();
});

describe("Blocking Flow", () => {
  it("blokowanie użytkownika uniemożliwia wysyłanie wiadomości", async () => {
    const { adminDb } = getAdmin();
    await initializeTestData(["user-a", "user-b"]);

    // Create direct thread between users
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true, // Start unlocked for this test
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "Initial message",
      },
    });

    await wait(500);

    // User A blocks User B
    await userA.adapter.updateUserBlockList("user-a", "user-b", true);
    await wait(1000);

    // Verify block exists
    const isBlocked = await userA.adapter.isUserBlocked("user-a", "user-b");
    expect(isBlocked).toBe(true);

    // User A should NOT be able to send to User B (blocked recipient)
    await expect(
      userA.messageService.sendMessage({
        threadId: thread.id,
        message: {
          text: "Message after blocking",
        },
      })
    ).rejects.toThrow("User is blocked");
  });

  it("odblokowanie użytkownika przywraca możliwość wysyłania", async () => {
    const { adminDb } = getAdmin();
    await initializeTestData(["user-a", "user-b"]);

    // Create direct thread
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true,
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "First message",
      },
    });

    await wait(500);

    // User A blocks User B
    await userA.adapter.updateUserBlockList("user-a", "user-b", true);
    await wait(1000);

    // Verify blocked
    const blockedBefore = await userA.adapter.isUserBlocked("user-a", "user-b");
    expect(blockedBefore).toBe(true);

    // User A unblocks User B
    await userA.adapter.updateUserBlockList("user-a", "user-b", false);
    await wait(1000);

    // Verify unblocked
    const blockedAfter = await userA.adapter.isUserBlocked("user-a", "user-b");
    expect(blockedAfter).toBe(false);

    // User A can now send messages again
    const message = await userA.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message after unblocking",
      },
    });

    expect((message as any).text).toBe("Message after unblocking");
  });

  it("blokowanie jest jednostronne - nie wpływa na drugiego użytkownika", async () => {
    const { adminDb } = getAdmin();
    await initializeTestData(["user-a", "user-b"]);

    // Create direct thread
    const { thread } = await userA.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "direct",
        members: ["user-a", "user-b"],
        directUnlocked: true,
      },
      message: {
        threadId: "",
        senderId: "user-a",
        type: "text",
        text: "Hello",
      },
    });

    await wait(500);

    // User A blocks User B
    await userA.adapter.updateUserBlockList("user-a", "user-b", true);
    await wait(1000);

    // User A cannot send (blocked User B)
    await expect(
      userA.messageService.sendMessage({
        threadId: thread.id,
        message: {
          text: "From A (should fail)",
        },
      })
    ).rejects.toThrow("User is blocked");

    // User B CAN still send (User B didn't block User A)
    // Note: In production, Cloud Functions would check if User A blocked User B
    const messageFromB = await userB.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "From B (should succeed)",
      },
    });

    expect((messageFromB as any).text).toBe("From B (should succeed)");
  });

  it("można zablokować wielu użytkowników niezależnie", async () => {
    await initializeTestData(["user-a", "user-b"]);

    const userC = await createTestUser("user-c");
    await initializeTestData(["user-c"]);

    // User A blocks User B
    await userA.adapter.updateUserBlockList("user-a", "user-b", true);
    await wait(1000);

    // User A blocks User C
    await userA.adapter.updateUserBlockList("user-a", "user-c", true);
    await wait(1000);

    // Verify both blocked
    const blockedB = await userA.adapter.isUserBlocked("user-a", "user-b");
    const blockedC = await userA.adapter.isUserBlocked("user-a", "user-c");

    expect(blockedB).toBe(true);
    expect(blockedC).toBe(true);

    // Unblock only User B
    await userA.adapter.updateUserBlockList("user-a", "user-b", false);
    await wait(1000);

    // User B unblocked, User C still blocked
    const blockedBAfter = await userA.adapter.isUserBlocked("user-a", "user-b");
    const blockedCAfter = await userA.adapter.isUserBlocked("user-a", "user-c");

    expect(blockedBAfter).toBe(false);
    expect(blockedCAfter).toBe(true);
  });
});
