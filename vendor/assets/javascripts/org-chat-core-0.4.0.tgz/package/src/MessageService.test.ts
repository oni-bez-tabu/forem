import { describe, expect, it } from "vitest";
import { FirestoreAdapter, MessageService } from "./MessageService.js";
import { Message, MessageType, Timestamp, Thread } from "./types.js";
import { ChatGloballyBannedError, UserBannedInCommunityError, UserBlockedError } from "./types.js";
import { InMemoryFirestoreAdapter } from "./__tests__/mocks/InMemoryFirestoreAdapter.js";

// NOTE: Rate limiting jest teraz wymuszany tylko przez Cloud Functions
// Testy rate limitingu zostaly przeniesione do functions/__tests__

const fixedTimestamp: Timestamp = { seconds: 1, nanoseconds: 2 };

describe("MessageService", () => {
  it("throws when sending empty or whitespace text", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await expect(service.sendMessage({ threadId: "thread-1", message: { text: "" } })).rejects.toHaveProperty(
      "code",
      "EMPTY_MESSAGE"
    );
    await expect(service.sendMessage({ threadId: "thread-1", message: { text: "   " } })).rejects.toHaveProperty(
      "code",
      "EMPTY_MESSAGE"
    );
  });

  it("throws when sending image-only message", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await expect(
      service.sendMessage({ threadId: "thread-1", message: { imageUrl: "https://img" } })
    ).rejects.toHaveProperty("code", "IMAGE_ONLY_NOT_ALLOWED");
  });

  it("throws when text exceeds 1000 characters", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    const longText = "a".repeat(1001);
    await expect(service.sendMessage({ threadId: "thread-1", message: { text: longText } })).rejects.toHaveProperty(
      "code",
      "TEXT_TOO_LONG"
    );
  });

  it("sends text messages and updates lastMessage", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({
      firestore,
      currentUserId: "u1",
    });

    const message = (await service.sendMessage({ threadId: "thread-1", message: { text: "hello" } })) as Message;

    const stored = firestore.getStoredMessage("thread-1", message.id);
    expect(stored?.text).toBe("hello");
    expect(stored?.senderId).toBe("u1");
    expect(stored?.readBy).toEqual(["u1"]);

    const last = firestore.getLastMessage("thread-1");
    expect(last).toMatchObject({
      id: message.id,
      senderId: "u1",
      text: "hello",
      createdAt: fixedTimestamp,
    });
  });

  it("emits only the first message once in group before acceptance", async () => {
    const ts: Timestamp = { seconds: 10, nanoseconds: 0 };
    const thread: Thread = {
      id: "g1",
      type: "group",
      members: ["u1", "u2"],
      createdAt: ts,
      acceptedBy: ["u1"],
      unreadCount: 0,
    };
    const firstMessage: Message = {
      id: "m1",
      threadId: "g1",
      senderId: "u1",
      type: "text",
      text: "hello",
      likes: [],
      readBy: [],
      createdAt: ts,
    };

    const firestore: FirestoreAdapter = {
      addMessageAtomic: async () => firstMessage,
      createThreadWithMessageAtomic: async () => ({ thread, message: firstMessage }),
      getThread: async () => thread,
      findDirectThreadByMembers: async () => null,
      getMessage: async () => firstMessage,
      listMessages: async () => [firstMessage],
      appendMessageLike: async () => {},
      removeMessageLike: async () => {},
      appendMessageReadBy: async () => {},
      appendThreadAcceptedBy: async () => {},
      getThreadUserPrefs: async (threadId: string, userId: string) => ({ threadId, userId, muted: false }),
      resolveUsernamesToIds: async (usernames: string[]) => {
        const map = new Map<string, string>();
        usernames.forEach((u: string) => map.set(u, u));
        return map;
      },
      setThreadMuted: async () => {},
      consumeRateLimit: async () => ({ allowed: true }),
      subscribeToMessages: (_threadId: string, onMessage: (message: Message) => void) => {
        onMessage(firstMessage);
        onMessage(firstMessage); // symulacja duplicated change
        return () => {};
      },
    };

    const service = new MessageService({ firestore, currentUserId: "u2" });
    const received: Message[] = [];
    const unsubscribe = await service.openThread("g1", (m: Message) => received.push(m));

    expect(received.length).toBeGreaterThanOrEqual(1);
    expect(received.every((m) => m.id === "m1")).toBe(true);
    unsubscribe();
  });

  it("sends text+image messages and updates lastMessage", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    const message = (await service.sendMessage({
      threadId: "thread-1",
      message: {
        text: "caption",
        imageUrl: "https://img/test.png",
      },
    })) as Message;

    const stored = firestore.getStoredMessage("thread-1", message.id);
    expect(stored?.text).toBe("caption");
    expect(stored?.imageUrl).toBe("https://img/test.png");
    expect(stored?.type).toBe("image");

    const last = firestore.getLastMessage("thread-1");
    expect(last).toMatchObject({
      id: message.id,
      senderId: "u1",
      text: "caption",
      imageUrl: "https://img/test.png",
      createdAt: fixedTimestamp,
    });
  });

  it("includes reply data when replying to an existing message", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const original: Message = {
      id: "msg-0",
      threadId: "thread-1",
      senderId: "u1",
      type: "text",
      text: "orig",
      likes: [],
      readBy: [],
      createdAt: fixedTimestamp,
    };
    firestore.seedMessage("thread-1", original);
    const service = new MessageService({ firestore, currentUserId: "u2" });

    const reply = (await service.sendMessage({
      threadId: "thread-1",
      message: { text: "reply", replyToId: "msg-0" },
    })) as Message;

    expect(reply.replyTo).toEqual({
      messageId: "msg-0",
      senderId: "u1",
      text: "orig",
      imageUrl: undefined,
    });
  });

  it("likes a message and is idempotent for the same user", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
      unreadCount: 0,
    });
    const message = await firestore.addMessageAtomic(
      {
        threadId: "thread-1",
        senderId: "u2",
        type: "text",
        text: "hey",
      },
      { threadUpdates: { directUnlocked: true } }
    );
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await service.likeMessage("thread-1", message.id);
    await service.likeMessage("thread-1", message.id);

    const stored = firestore.getStoredMessage("thread-1", message.id);
    expect(stored?.likes).toEqual(["u1"]);
  });

  it("unlikes a message and is idempotent", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
      unreadCount: 0,
    });
    const message = await firestore.addMessageAtomic(
      {
        threadId: "thread-1",
        senderId: "u2",
        type: "text",
        text: "hey",
      },
      { threadUpdates: { directUnlocked: true } }
    );
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await service.likeMessage("thread-1", message.id);
    await service.unlikeMessage("thread-1", message.id);
    await service.unlikeMessage("thread-1", message.id);

    const stored = firestore.getStoredMessage("thread-1", message.id);
    expect(stored?.likes).toEqual([]);
  });

  it("paginates messages with cursor", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
      unreadCount: 0,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    const m1 = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u2",
      type: "text",
      text: "old",
    });
    const m2 = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u2",
      type: "text",
      text: "mid",
    });
    const m3 = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u2",
      type: "text",
      text: "new",
    });
    // Ustaw sztuczne czasy, aby deterministycznie posortować
    const mutate = (msg: Message, seconds: number) => {
      const stored = firestore.getStoredMessage("thread-1", msg.id);
      if (stored) {
        stored.createdAt = { seconds, nanoseconds: 0 };
      }
    };
    mutate(m1, 1);
    mutate(m2, 2);
    mutate(m3, 3);

    const page1 = await service.fetchMessages("thread-1", { limit: 2 });
    expect(page1.map((m: Message) => m.text)).toEqual(["mid", "new"]);

    const page2 = await service.fetchMessages("thread-1", { limit: 2, beforeMessageId: m2.id });
    expect(page2.map((m: Message) => m.text)).toEqual(["old"]);
  });

  it("marks a message as read and is idempotent for the same user", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      directUnlocked: true,
    });
    const message = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u2",
      type: "text",
      text: "hey",
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await service.markAsRead("thread-1", message.id);
    await service.markAsRead("thread-1", message.id);

    const stored = firestore.getStoredMessage("thread-1", message.id);
    expect(stored?.readBy).toEqual(["u2", "u1"]);
  });

  it("does not auto-mark other users' messages as read", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      directUnlocked: true,
    });
    const authorService = new MessageService({ firestore, currentUserId: "u1" });

    const message = (await authorService.sendMessage({ threadId: "thread-1", message: { text: "hello" } })) as Message;

    const stored = firestore.getStoredMessage("thread-1", message.id);
    expect(stored?.readBy).toEqual(["u1"]);
  });

  it("rejects markAsRead when user is not a thread member", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      directUnlocked: true,
    });
    const message = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u1",
      type: "text",
      text: "hey",
    });
    const outsider = new MessageService({ firestore, currentUserId: "u3" });

    await expect(outsider.markAsRead("thread-1", message.id)).rejects.toHaveProperty("code", "NOT_THREAD_MEMBER");
  });

  it("marks messages individually without leaking across messages", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      directUnlocked: true,
    });
    const messageA = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u2",
      type: "text",
      text: "first",
    });
    const messageB = await firestore.addMessageAtomic({
      threadId: "thread-1",
      senderId: "u2",
      type: "text",
      text: "second",
    });
    const reader = new MessageService({ firestore, currentUserId: "u1" });

    await reader.markAsRead("thread-1", messageA.id);

    expect(firestore.getStoredMessage("thread-1", messageA.id)?.readBy).toEqual(["u2", "u1"]);
    expect(firestore.getStoredMessage("thread-1", messageB.id)?.readBy).toEqual(["u2"]);
  });

  it("throws when marking a missing message as read", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await expect(service.markAsRead("thread-1", "missing")).rejects.toHaveProperty("code", "MESSAGE_NOT_FOUND");
  });

  it("throws when replying to a missing message", async () => {
    const firestore = new InMemoryFirestoreAdapter({
      now: fixedTimestamp,
    });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await expect(
      service.sendMessage({ threadId: "thread-1", message: { text: "reply", replyToId: "missing-id" } })
    ).rejects.toHaveProperty("code", "REPLY_NOT_FOUND");
  });

  it("blocks second direct message until reply and unlocks after reply", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      directUnlocked: false,
      lastMessage: {
        id: "m-0",
        senderId: "u1",
        createdAt: fixedTimestamp,
      },
    });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await expect(
      service.sendMessage({ threadId: "thread-1", message: { text: "second" } })
    ).rejects.toHaveProperty(
      "code",
      "WAIT_FOR_REPLY"
    );

    // other user replies -> should unlock
    const otherService = new MessageService({ firestore, currentUserId: "u2" });
    await otherService.sendMessage({ threadId: "thread-1", message: { text: "reply" } });
    const thread = await firestore.getThread("thread-1");
    expect(thread?.directUnlocked).toBe(true);
  });

  it("prevents sending in group when user has not accepted", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "group",
      members: ["u1", "u2", "u3"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1"], // tylko nadawca pierwszej wiadomości
      unreadCount: 0,
    });
    const service = new MessageService({ firestore, currentUserId: "u2" });

    await expect(
      service.sendMessage({ threadId: "thread-1", message: { text: "hi" } })
    ).rejects.toHaveProperty("code", "CONSENT_REQUIRED");
  });

  it("blocks sending when user is globally banned", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
    });
    const service = new MessageService({ firestore, currentUserId: "u1", chatBanned: true });

    await expect(service.sendMessage({ threadId: "thread-1", message: { text: "hello" } })).rejects.toBeInstanceOf(
      ChatGloballyBannedError
    );
  });

  it("blocks send and like when banned in community", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "c-1",
      type: "community",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      bannedMembers: ["u1"],
      unreadCount: 0,
    } as Thread);
    const service = new MessageService({ firestore, currentUserId: "u1" });

    await expect(service.sendMessage({ threadId: "c-1", message: { text: "hi" } })).rejects.toBeInstanceOf(
      UserBannedInCommunityError
    );

    const otherMessage = await firestore.addMessageAtomic(
      {
        threadId: "c-1",
        senderId: "u2",
        type: "text",
        text: "hey",
      },
      { threadUpdates: { directUnlocked: true } }
    );

    await expect(service.likeMessage("c-1", otherMessage.id)).rejects.toBeInstanceOf(UserBannedInCommunityError);
  });

  it("blocks direct send when sender blocked recipient", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    firestore.seedThread({
      id: "d-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["u1", "u2"],
      directUnlocked: true,
      unreadCount: 0,
    });
    // u1 blocks u2 (current user blocks recipient)
    // Note: Checking if recipient blocked sender is done server-side by Cloud Functions
    firestore.block("u1", "u2");
    const service = new MessageService({ firestore, currentUserId: "u1" });
    await expect(service.sendMessage({ threadId: "d-1", message: { text: "hello" } })).rejects.toBeInstanceOf(
      UserBlockedError
    );
  });

  // NOTE: Testy rate limitingu zostaly przeniesione do functions/__tests__
  // Rate limiting jest wymuszany tylko przez Cloud Functions

  it("creates a direct thread with first message and enforces uniqueness", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    const created = (await service.sendMessage({
      threadType: "direct",
      members: ["u2"],
      message: { text: "hello" },
    })) as Thread;
    expect(created.type).toBe("direct");
    expect(created.lastMessage?.text).toBe("hello");

    await expect(
      service.sendMessage({
        threadType: "direct",
        members: ["u2"],
        message: { text: "again" },
      })
    ).rejects.toHaveProperty("code", "DIRECT_ALREADY_EXISTS");
  });

  it("requires name for community and forbids name for group", async () => {
    const firestore = new InMemoryFirestoreAdapter({ now: fixedTimestamp });
    const service = new MessageService({ firestore, currentUserId: "u1" });

    const group = await service.sendMessage({
      threadType: "group",
      members: ["u2", "u3"],
      name: "group-name",
      message: { text: "hi" },
    });
    expect((group as Thread).name).toBe("group-name");

    await expect(
      service.sendMessage({
        threadType: "community",
        members: ["u2", "u3"],
        message: { text: "hi" },
      })
    ).rejects.toHaveProperty("code", "COMMUNITY_NAME_REQUIRED");
  });
});

