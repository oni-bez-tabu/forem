import {
  Message,
  MessageType,
  ReplyTo,
  SendMessageInput,
  SendMessageRequest,
  MessageValidationError,
  ReplyNotFoundError,
  Thread,
  ThreadValidationError,
  MessageNotFoundError,
  ChatGloballyBannedError,
  UserBannedInCommunityError,
  UserBlockedError,
  ThreadType,
  RateLimitExceededError,
  TempChatSuspendedError,
} from "./types.js";
// NOTE: RateLimitConfig usunięty - rate limiting jest wymuszany przez Cloud Functions

type NewMessageInput = {
  threadId: string;
  senderId: string;
  clientMessageId?: string;
  type: MessageType;
  text?: string;
  imageUrl?: string;
  replyTo?: ReplyTo;
  mentions?: string[];
};

type AddMessageOptions = {
  threadUpdates?: {
    directUnlocked?: boolean;
    acceptedByAdd?: string[];
  };
  unreadFanout?: {
    recipients: string[];
    senderId: string;
  };
};

type CreateThreadWithMessageInput = {
  thread: {
    type: Thread["type"];
    members: string[];
    name?: string;
    acceptedBy?: string[];
    directUnlocked?: boolean;
    roles?: Thread["roles"];
    bannedMembers?: string[];
  };
  message: NewMessageInput;
  unreadFanout?: {
    recipients: string[];
    senderId: string;
  };
};

const MAX_GROUP_MEMBERS = 8;

export type RateLimitConsumeInput =
  | {
      userId: string;
      action: "send_message";
      threadType: ThreadType;
      nowMs: number;
      // NOTE: config usunięty - rate limiting jest wymuszany przez Cloud Functions
    }
  | {
      userId: string;
      action: "create_thread";
      threadType: ThreadType;
      nowMs: number;
      // NOTE: config usunięty - rate limiting jest wymuszany przez Cloud Functions
    };

export type RateLimitConsumeResult =
  | { allowed: true }
  | { allowed: false; code: "RATE_LIMIT_EXCEEDED" }
  | { allowed: false; code: "TEMP_CHAT_SUSPENDED"; suspendedUntilMs?: number };

export interface FirestoreAdapter {
  addMessageAtomic(input: NewMessageInput, options?: AddMessageOptions): Promise<Message>;
  createThreadWithMessageAtomic(input: CreateThreadWithMessageInput): Promise<{ thread: Thread; message: Message }>;
  getThread(threadId: string): Promise<Thread | null>;
  findDirectThreadByMembers(memberA: string, memberB: string): Promise<Thread | null>;
  getMessage(threadId: string, messageId: string): Promise<Message | null>;
  listMessages(
    threadId: string,
    options: { limit: number; beforeMessageId?: string }
  ): Promise<Message[]>;
  appendMessageLike(threadId: string, messageId: string, userId: string): Promise<void>;
  removeMessageLike(threadId: string, messageId: string, userId: string): Promise<void>;
  appendMessageReadBy(threadId: string, messageId: string, userId: string): Promise<void>;
  appendThreadAcceptedBy(threadId: string, userId: string): Promise<void>;
  subscribeToMessages(threadId: string, onMessage: (message: Message) => void): () => void;
  isUserBlocked(blockingUserId: string, blockedUserId: string): Promise<boolean>;
  getThreadUserPrefs(threadId: string, userId: string): Promise<{ threadId: string; userId: string; muted: boolean; mutedAt?: import("./types.js").Timestamp }>;
  resolveUsernamesToIds(usernames: string[]): Promise<Map<string, string>>;
  setThreadMuted(threadId: string, userId: string, muted: boolean): Promise<void>;
  consumeRateLimit(input: RateLimitConsumeInput): Promise<RateLimitConsumeResult>;
}

export class MessageService {
  private readonly firestore: FirestoreAdapter;
  private readonly currentUserId: string;
  private readonly chatBanned: boolean;
  // rateLimitConfig usunięty - CF wymusza limity
  private readonly nowProvider: () => number;
  private readonly acceptedThreads = new Set<string>();
  private readonly openThreadContexts = new Map<
    string,
    {
      buffer: Map<string, Message>;
      accepted: boolean;
      unsubscribe: () => void;
      onMessage: (message: Message) => void;
    }
  >();

  constructor(params: {
    firestore: FirestoreAdapter;
    currentUserId: string;
    chatBanned?: boolean;
    // rateLimitConfig usunięty - CF wymusza limity
    nowProvider?: () => number;
  }) {
    this.firestore = params.firestore;
    this.currentUserId = params.currentUserId;
    this.chatBanned = params.chatBanned ?? false;
    // rateLimitConfig usunięty
    this.nowProvider = params.nowProvider ?? Date.now;
  }

  async sendMessage(input: SendMessageRequest): Promise<Thread | Message> {
    this.assertNotGloballyBanned();
    if (typeof input !== "object" || input === null) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    if ("threadId" in input) {
      return this.sendToExistingThread(input.threadId, input.message);
    }
    if ("threadType" in input) {
      return this.sendToNewThread(input);
    }
    throw new ThreadValidationError("THREAD_NOT_FOUND");
  }

  private async sendToExistingThread(threadId: string, messageInput: SendMessageInput): Promise<Message> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);
    await this.assertNotBlockedInDirect(thread);
    this.assertCanWrite(thread);
    await this.assertNotBlockedInDirect(thread);
    await this.enforceSendRateLimit(thread.type);

    const normalized = this.validateAndNormalizeInput(messageInput);
    const replyTo = await this.resolveReply(threadId, messageInput.replyToId);
    const mentions = await this.resolveMentions(normalized.text, this.getEligibleMembers(thread));

    const threadUpdates = this.enforceThreadRulesBeforeSend(thread);
    // NOTE: Fanout unread count jest obsługiwany przez Cloud Function onMessageCreate
    // Nie przekazujemy unreadFanout - CF zrobi to automatycznie z sprawdzeniem muting

    const created = await this.firestore.addMessageAtomic(
      {
        threadId,
        senderId: this.currentUserId,
        clientMessageId: messageInput.clientMessageId,
        type: normalized.type,
        text: normalized.text,
        imageUrl: normalized.imageUrl,
        replyTo,
        mentions,
      },
      threadUpdates
    );
    if (replyTo) {
      created.replyTo = replyTo;
    }
    if (mentions.length) {
      created.mentions = mentions;
    }
    return created;
  }

  private async sendToNewThread(input: Extract<SendMessageRequest, { threadType: Thread["type"] }>): Promise<Thread> {
    this.assertNotGloballyBanned();
    await this.enforceCreateThreadRateLimit(input.threadType);
    await this.enforceSendRateLimit(input.threadType);
    // Pierwsza wiadomość w nowym wątku - limit 500 znaków
    const normalizedMessage = this.validateAndNormalizeInput(input.message, true);
    const members = this.uniqueMembers(input.members, this.currentUserId);

    if (input.threadType === "direct") {
      this.assertDirectMembers(members);
      this.assertNoNameForDirect(input.name);
      await this.assertNotBlockedByMember(members);
      const mentions = await this.resolveMentions(normalizedMessage.text, members);
      const existing = await this.firestore.findDirectThreadByMembers(members[0], members[1]);
      if (existing) {
        throw new ThreadValidationError("DIRECT_ALREADY_EXISTS");
      }
      // NOTE: Fanout unread count jest obsługiwany przez Cloud Function onMessageCreate
      const { thread, message } = await this.firestore.createThreadWithMessageAtomic({
        thread: {
          type: "direct",
          members,
          directUnlocked: false,
        },
        message: {
          threadId: "",
          senderId: this.currentUserId,
          clientMessageId: input.message.clientMessageId,
          type: normalizedMessage.type,
          text: normalizedMessage.text,
          imageUrl: normalizedMessage.imageUrl,
          mentions,
        },
      });
      return thread;
    }

    if (input.threadType === "group") {
      if (members.length < 2) {
        throw new ThreadValidationError("GROUP_MEMBERS_INVALID");
      }
      if (members.length > MAX_GROUP_MEMBERS) {
        throw new ThreadValidationError("GROUP_MEMBERS_INVALID");
      }
      const trimmedName = input.name?.trim();
      const mentions = await this.resolveMentions(normalizedMessage.text, members);
      // NOTE: Fanout unread count jest obsługiwany przez Cloud Function onMessageCreate
      const { thread, message } = await this.firestore.createThreadWithMessageAtomic({
        thread: {
          type: "group",
          members,
          name: trimmedName || undefined,
          acceptedBy: [this.currentUserId],
        },
        message: {
          threadId: "",
          senderId: this.currentUserId,
          clientMessageId: input.message.clientMessageId,
          type: normalizedMessage.type,
          text: normalizedMessage.text,
          imageUrl: normalizedMessage.imageUrl,
          mentions,
        },
      });
      return thread;
    }

    if (input.threadType === "community") {
      if (members.length < 2) {
        throw new ThreadValidationError("COMMUNITY_MEMBERS_INVALID");
      }
      if (members.length > MAX_GROUP_MEMBERS) {
        throw new ThreadValidationError("COMMUNITY_MEMBERS_INVALID");
      }
      const trimmedName = input.name?.trim();
      if (!trimmedName) {
        throw new ThreadValidationError("COMMUNITY_NAME_REQUIRED");
      }
      const roles: Thread["roles"] = members.reduce((acc, member) => {
        if (member === this.currentUserId) {
          acc[member] = "owner";
        } else {
          acc[member] = "member";
        }
        return acc;
      }, {} as Record<string, "owner" | "moderator" | "member">);
      const mentions = await this.resolveMentions(normalizedMessage.text, members);
      // NOTE: Fanout unread count jest obsługiwany przez Cloud Function onMessageCreate

      const { thread, message } = await this.firestore.createThreadWithMessageAtomic({
        thread: {
          type: "community",
          members,
          name: trimmedName,
          acceptedBy: members, // no consent needed
          roles,
          bannedMembers: [],
        },
        message: {
          threadId: "",
          senderId: this.currentUserId,
          clientMessageId: input.message.clientMessageId,
          type: normalizedMessage.type,
          text: normalizedMessage.text,
          imageUrl: normalizedMessage.imageUrl,
          mentions,
        },
      });
      return thread;
    }

    throw new ThreadValidationError("THREAD_NOT_FOUND");
  }

  async likeMessage(threadId: string, messageId: string): Promise<void> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);
    this.assertGroupConsent(thread);
    this.assertNotGloballyBanned();
    this.assertCommunityNotBanned(thread);
    await this.firestore.appendMessageLike(threadId, messageId, this.currentUserId);
  }

  async unlikeMessage(threadId: string, messageId: string): Promise<void> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);
    this.assertGroupConsent(thread);
    this.assertNotGloballyBanned();
    this.assertCommunityNotBanned(thread);
    await this.firestore.removeMessageLike(threadId, messageId, this.currentUserId);
  }

  async fetchMessages(
    threadId: string,
    options: { limit?: number; beforeMessageId?: string } = {}
  ): Promise<Message[]> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);
    const requestedLimit = options.limit ?? 30;
    const limit = Math.max(1, Math.min(requestedLimit, 100)); // bezpieczny zakres
    const isAccepted = this.isAccepted(thread);

    // Dla grup przed akceptacją pokaż tylko jedną (ostatnią) wiadomość
    if (thread.type === "group" && !isAccepted) {
      return this.firestore.listMessages(threadId, { limit: 1 });
    }

    return this.firestore.listMessages(threadId, { limit, beforeMessageId: options.beforeMessageId });
  }

  async markAsRead(threadId: string, messageId: string): Promise<void> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);
    this.assertGroupConsent(thread);

    const message = await this.firestore.getMessage(threadId, messageId);
    if (!message) {
      throw new MessageNotFoundError();
    }
    if (message.threadId !== threadId) {
      throw new MessageNotFoundError();
    }
    if (message.readBy.includes(this.currentUserId)) {
      return;
    }

    await this.firestore.appendMessageReadBy(threadId, messageId, this.currentUserId);
  }

  private async resolveReply(
    threadId: string,
    replyToMessageId?: string
  ): Promise<ReplyTo | undefined> {
    if (!replyToMessageId) {
      return undefined;
    }
    const referenced = await this.firestore.getMessage(threadId, replyToMessageId);
    if (!referenced) {
      throw new ReplyNotFoundError();
    }
    return {
      messageId: referenced.id,
      senderId: referenced.senderId,
      text: referenced.text,
      imageUrl: referenced.imageUrl,
    };
  }

  /**
   * Sanityzuje tekst wiadomości usuwając niebezpieczne znaki HTML
   */
  private sanitizeText(text: string): string {
    // Usuń wszystkie znaki HTML - zastąp < > & " ' ich encjami
    return text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#x27;")
      .replace(/\//g, "&#x2F;");
  }

  private validateAndNormalizeInput(
    input: SendMessageInput,
    isFirstMessage: boolean = false
  ): { type: MessageType; text?: string; imageUrl?: string } {
    const trimmedText = input.text?.trim() ?? "";
    const normalizedImageUrl = input.imageUrl?.trim() ?? "";

    const hasText = trimmedText.length > 0;
    const hasImage = normalizedImageUrl.length > 0;

    if (!hasText && !hasImage) {
      throw new MessageValidationError("EMPTY_MESSAGE");
    }
    if (hasImage && !hasText) {
      throw new MessageValidationError("IMAGE_ONLY_NOT_ALLOWED");
    }
    
    // Różne limity: pierwsza wiadomość 500 znaków, normalna 1000 znaków
    const maxLength = isFirstMessage ? 500 : 1000;
    if (hasText && trimmedText.length > maxLength) {
      const limitMessage = isFirstMessage
        ? "Wiadomość startowa może mieć maksymalnie 500 znaków"
        : "Wiadomość może mieć maksymalnie 1000 znaków";
      throw new MessageValidationError("TEXT_TOO_LONG", limitMessage);
    }
    
    // Sanityzuj tekst (zabezpieczenie przed XSS)
    const sanitizedText = hasText ? this.sanitizeText(trimmedText) : undefined;

    return {
      type: hasImage ? "image" : "text",
      text: sanitizedText,
      imageUrl: hasImage ? normalizedImageUrl : undefined,
    };
  }

  private async getThreadOrThrow(threadId: string): Promise<Thread> {
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    return thread;
  }

  private assertThreadMember(thread: Thread): void {
    if (!thread.members.includes(this.currentUserId)) {
      throw new ThreadValidationError("NOT_THREAD_MEMBER");
    }
  }

  private assertNotGloballyBanned(): void {
    if (this.chatBanned) {
      throw new ChatGloballyBannedError();
    }
  }

  private assertCommunityNotBanned(thread: Thread): void {
    if (thread.type !== "community") {
      return;
    }
    if ((thread.bannedMembers ?? []).includes(this.currentUserId)) {
      throw new UserBannedInCommunityError();
    }
  }

  private async assertNotBlockedInDirect(thread: Thread): Promise<void> {
    if (thread.type !== "direct") {
      return;
    }
    const recipient = thread.members.find((m) => m !== this.currentUserId);
    if (!recipient) return;
    // Check if I blocked the recipient (client-side check)
    // Note: Checking if recipient blocked me is done server-side by Cloud Functions
    const blocked = await this.firestore.isUserBlocked(this.currentUserId, recipient);
    if (blocked) {
      throw new UserBlockedError();
    }
  }

  private async assertNotBlockedByMember(members: string[]): Promise<void> {
    if (members.length !== 2) return;
    const recipient = members.find((m) => m !== this.currentUserId);
    if (!recipient) return;
    // Check if I blocked the recipient (client-side check)
    // Note: Checking if recipient blocked me is done server-side by Cloud Functions
    const blocked = await this.firestore.isUserBlocked(this.currentUserId, recipient);
    if (blocked) {
      throw new UserBlockedError();
    }
  }

  private assertCanWrite(thread: Thread): void {
    this.assertThreadMember(thread);
    this.assertCommunityNotBanned(thread);
    if (thread.type === "group") {
      this.assertGroupConsent(thread);
    }
    if (thread.type === "direct" && !thread.directUnlocked && thread.lastMessage?.senderId === this.currentUserId) {
      throw new ThreadValidationError("WAIT_FOR_REPLY");
    }
  }

  private enforceThreadRulesBeforeSend(thread: Thread): AddMessageOptions | undefined {
    if (thread.type === "direct") {
      if (!thread.directUnlocked && thread.lastMessage?.senderId === this.currentUserId) {
        throw new ThreadValidationError("WAIT_FOR_REPLY");
      }
      if (!thread.directUnlocked && thread.lastMessage && thread.lastMessage.senderId !== this.currentUserId) {
        return { threadUpdates: { directUnlocked: true } };
      }
      return undefined;
    }

    if (thread.type === "group") {
      this.assertGroupConsent(thread);
      return undefined;
    }

    if (thread.type === "community") {
      this.assertCommunityNotBanned(thread);
      return undefined;
    }

    return undefined;
  }

  private uniqueMembers(members: string[], currentUserId: string): string[] {
    return Array.from(new Set([...members, currentUserId]));
  }

  private assertDirectMembers(members: string[]): void {
    if (members.length !== 2) {
      throw new ThreadValidationError("DIRECT_MEMBERS_INVALID");
    }
  }

  private assertNoNameForDirect(name?: string): void {
    if (name !== undefined && name !== null) {
      throw new ThreadValidationError("DIRECT_NAME_NOT_ALLOWED");
    }
  }

  private isAccepted(thread: Thread): boolean {
    if (thread.type !== "group") {
      return true;
    }
    return (thread.acceptedBy ?? []).includes(this.currentUserId);
  }

  private assertGroupConsent(thread: Thread): void {
    if (thread.type === "group" && !this.isAccepted(thread)) {
      throw new ThreadValidationError("CONSENT_REQUIRED");
    }
  }

  async acceptThread(threadId: string): Promise<void> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);
    this.assertNotGloballyBanned();

    if (thread.type !== "group") {
      return;
    }

    if (this.isAccepted(thread)) {
      this.acceptedThreads.add(threadId);
      this.flushOpenThread(threadId, true);
      return;
    }

    await this.firestore.appendThreadAcceptedBy(threadId, this.currentUserId);
    this.acceptedThreads.add(threadId);
    this.flushOpenThread(threadId, true);
  }

  openThread(threadId: string, onMessage: (message: Message) => void): Promise<() => void> {
    return this.initializeThreadSubscription(threadId, onMessage);
  }

  private async initializeThreadSubscription(
    threadId: string,
    onMessage: (message: Message) => void
  ): Promise<() => void> {
    const thread = await this.getThreadOrThrow(threadId);
    this.assertThreadMember(thread);

    const accepted = this.isAccepted(thread);
    if (accepted) {
      this.acceptedThreads.add(threadId);
    }

    const buffer = new Map<string, Message>();
    const context = {
      buffer,
      accepted,
      onMessage,
      unsubscribe: () => {},
    };

    const emitAccordingToConsent = () => {
      const ctx = this.openThreadContexts.get(threadId);
      if (!ctx) return;

      const messages = Array.from(ctx.buffer.values()).sort((a, b) => {
        if (a.createdAt.seconds === b.createdAt.seconds) {
          return a.createdAt.nanoseconds - b.createdAt.nanoseconds;
        }
        return a.createdAt.seconds - b.createdAt.seconds;
      });

      if (!ctx.accepted) {
        const first = messages[0];
        if (!first) return;
        ctx.onMessage(first);
        return;
      }

      messages.forEach((message) => {
        ctx.onMessage(message);
      });
    };

    this.openThreadContexts.set(threadId, context);

    const unsubscribe = this.firestore.subscribeToMessages(threadId, (message: Message) => {
      const ctx = this.openThreadContexts.get(threadId);
      if (!ctx) {
        return;
      }
      ctx.buffer.set(message.id, message);
      emitAccordingToConsent();
    });

    context.unsubscribe = () => {
      unsubscribe();
      this.openThreadContexts.delete(threadId);
    };

    emitAccordingToConsent();

    return context.unsubscribe;
  }

  private flushOpenThread(threadId: string, accepted: boolean): void {
    const context = this.openThreadContexts.get(threadId);
    if (!context) return;
    context.accepted = accepted;

    const messages = Array.from(context.buffer.values()).sort((a, b) => {
      if (a.createdAt.seconds === b.createdAt.seconds) {
        return a.createdAt.nanoseconds - b.createdAt.nanoseconds;
      }
      return a.createdAt.seconds - b.createdAt.seconds;
    });

    messages.forEach((message) => {
      context.onMessage(message);
    });
  }

  private async buildUnreadFanout(thread: Thread, mentioned: Set<string>): Promise<AddMessageOptions["unreadFanout"] | undefined> {
    const eligibleMembers = this.getEligibleMembers(thread).filter((m) => m !== this.currentUserId);
    const recipients: string[] = [];
    for (const member of eligibleMembers) {
      const prefs = await this.firestore.getThreadUserPrefs(thread.id, member);
      const notify = this.shouldNotify(thread.type, prefs.muted, mentioned.has(member));
      if (notify) {
        recipients.push(member);
      }
    }
    if (recipients.length === 0) {
      return undefined;
    }
    return { recipients, senderId: this.currentUserId };
  }

  private buildUnreadFanoutForNewThread(
    threadType: Thread["type"],
    members: string[],
    mentioned: Set<string>
  ): AddMessageOptions["unreadFanout"] | undefined {
    const recipients = members.filter((m) => m !== this.currentUserId);
    const filtered = recipients.filter((member) => this.shouldNotify(threadType, false, mentioned.has(member)));
    if (filtered.length === 0) {
      return undefined;
    }
    return { recipients: filtered, senderId: this.currentUserId };
  }

  private extractUsernames(text?: string): string[] {
    if (!text) {
      return [];
    }
    const regex = /@([a-zA-Z0-9_-]+)/g;
    const found: string[] = [];
    let match: RegExpExecArray | null;
    while ((match = regex.exec(text)) !== null) {
      found.push(match[1].toLowerCase());
    }
    return Array.from(new Set(found));
  }

  private async resolveMentions(text: string | undefined, members: string[]): Promise<string[]> {
    const usernames = this.extractUsernames(text);
    if (usernames.length === 0) {
      return [];
    }
    const memberSet = new Set(members);
    const resolved = await this.firestore.resolveUsernamesToIds(usernames);
    const resolvedIds = Array.from(resolved.values()).filter((id) => memberSet.has(id));
    return Array.from(new Set(resolvedIds));
  }

  private getEligibleMembers(thread: Thread): string[] {
    if (thread.type !== "community") {
      return thread.members;
    }
    const banned = new Set(thread.bannedMembers ?? []);
    return thread.members.filter((member) => !banned.has(member));
  }

  private shouldNotify(threadType: ThreadType, isMuted: boolean, isMentioned: boolean): boolean {
    if (isMuted) {
      return false;
    }
    if (threadType === "community") {
      return isMentioned;
    }
    return true;
  }

  private async enforceSendRateLimit(threadType: ThreadType): Promise<void> {
    // NOTE: config nie jest już używany - rate limiting jest wymuszany przez Cloud Functions
    // Klient tylko sprawdza suspendedUntilMs dla UX feedback
    const result = await this.firestore.consumeRateLimit({
      userId: this.currentUserId,
      action: "send_message",
      threadType,
      nowMs: this.nowProvider(),
      // config: this.rateLimitConfig, // Nieużywane - CF wymusza limity
    });
    this.raiseOnRateLimit(result);
  }

  private async enforceCreateThreadRateLimit(threadType: ThreadType): Promise<void> {
    // NOTE: config nie jest już używany - rate limiting jest wymuszany przez Cloud Functions
    const result = await this.firestore.consumeRateLimit({
      userId: this.currentUserId,
      action: "create_thread",
      threadType,
      nowMs: this.nowProvider(),
      // config: this.rateLimitConfig, // Nieużywane - CF wymusza limity
    });
    this.raiseOnRateLimit(result);
  }

  private raiseOnRateLimit(result: RateLimitConsumeResult): void {
    if (result.allowed) {
      return;
    }
    if (result.code === "TEMP_CHAT_SUSPENDED") {
      throw new TempChatSuspendedError(result.suspendedUntilMs);
    }
    throw new RateLimitExceededError();
  }

}

