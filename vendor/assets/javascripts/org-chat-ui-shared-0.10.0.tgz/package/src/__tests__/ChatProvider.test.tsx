import { render, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import {
  ChatProvider,
  useChatContext,
  useChatClient,
  useCurrentUserId,
  useUserProfile,
  type UserProfile,
} from "../ChatProvider";
import type { ChatClient } from "@org/chat-core";

function createMockClient(overrides: Partial<ChatClient> = {}): ChatClient {
  return {
    init: vi.fn(),
    getThreads: vi.fn(),
    subscribeThreads: vi.fn(),
    openThread: vi.fn(),
    sendMessage: vi.fn(),
    fetchMessages: vi.fn(),
    likeMessage: vi.fn(),
    unlikeMessage: vi.fn(),
    markAsRead: vi.fn(),
    getUnreadCount: vi.fn(),
    acceptThread: vi.fn(),
    subscribeTotalUnread: vi.fn(),
    leaveThread: vi.fn(),
    isUserBlocked: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn(),
    subscribeTyping: vi.fn(),
    subscribeUserProfile: vi.fn().mockReturnValue(() => {}),
    uploadImage: vi.fn(),
    ...overrides,
  } as ChatClient;
}

describe("ChatProvider", () => {
  it("renderuje children", () => {
    const client = createMockClient();

    const { container } = render(
      <ChatProvider client={client} currentUserId="user-1">
        <div data-testid="child">Test Child</div>
      </ChatProvider>
    );

    expect(container.querySelector('[data-testid="child"]')).toBeInTheDocument();
  });

  it("dostarcza client przez context", () => {
    const client = createMockClient();
    let contextClient: ChatClient | null = null;

    function TestComponent() {
      contextClient = useChatClient();
      return null;
    }

    render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    expect(contextClient).toBe(client);
  });

  it("dostarcza currentUserId przez context", () => {
    const client = createMockClient();
    let userId: string | null = null;

    function TestComponent() {
      userId = useCurrentUserId();
      return null;
    }

    render(
      <ChatProvider client={client} currentUserId="test-user-123">
        <TestComponent />
      </ChatProvider>
    );

    expect(userId).toBe("test-user-123");
  });

  it("ensureProfileSubscription subskrybuje profil użytkownika", () => {
    const subscribeUserProfile = vi.fn().mockReturnValue(() => {});
    const client = createMockClient({ subscribeUserProfile });

    function TestComponent() {
      const { ensureProfileSubscription } = useChatContext();
      ensureProfileSubscription("user-2");
      return null;
    }

    render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    expect(subscribeUserProfile).toHaveBeenCalledWith("user-2", expect.any(Function));
  });

  it("ensureProfileSubscription nie subskrybuje dwa razy tego samego użytkownika", () => {
    const subscribeUserProfile = vi.fn().mockReturnValue(() => {});
    const client = createMockClient({ subscribeUserProfile });

    function TestComponent() {
      const { ensureProfileSubscription } = useChatContext();
      ensureProfileSubscription("user-2");
      ensureProfileSubscription("user-2"); // Second call should be ignored
      return null;
    }

    render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    expect(subscribeUserProfile).toHaveBeenCalledTimes(1);
  });

  it("getProfile zwraca profil użytkownika", async () => {
    let profileCallback: ((profile: UserProfile | undefined) => void) | null = null;
    const subscribeUserProfile = vi.fn().mockImplementation((_userId, callback) => {
      profileCallback = callback;
      return () => {};
    });
    const client = createMockClient({ subscribeUserProfile });

    let profile: UserProfile | undefined;

    function TestComponent() {
      const { ensureProfileSubscription, getProfile } = useChatContext();
      ensureProfileSubscription("user-2");
      profile = getProfile("user-2");
      return null;
    }

    const { rerender } = render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    // Initially no profile
    expect(profile).toBeUndefined();

    // Simulate profile update
    const mockProfile: UserProfile = {
      username: "testuser",
      displayName: "Test User",
      avatarUrl: "https://example.com/avatar.jpg",
    };

    profileCallback?.(mockProfile);

    // Re-render to get updated profile
    rerender(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(profile).toEqual(mockProfile);
    });
  });

  it("uploadImage wywołuje client.uploadImage", async () => {
    const uploadImage = vi.fn().mockResolvedValue("https://example.com/image.jpg");
    const client = createMockClient({ uploadImage });

    let result: string | null = null;

    function TestComponent() {
      const { uploadImage: upload } = useChatContext();
      const file = new File(["test"], "test.jpg", { type: "image/jpeg" });
      upload(file).then((url) => {
        result = url;
      });
      return null;
    }

    render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(uploadImage).toHaveBeenCalled();
      expect(result).toBe("https://example.com/image.jpg");
    });
  });

  it("useUserProfile subskrybuje i zwraca profil", async () => {
    let profileCallback: ((profile: UserProfile | undefined) => void) | null = null;
    const subscribeUserProfile = vi.fn().mockImplementation((_userId, callback) => {
      profileCallback = callback;
      // Immediately call with profile
      callback({
        username: "testuser",
        displayName: "Test User",
      });
      return () => {};
    });
    const client = createMockClient({ subscribeUserProfile });

    let profile: UserProfile | undefined;

    function TestComponent() {
      profile = useUserProfile("user-2");
      return null;
    }

    render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(subscribeUserProfile).toHaveBeenCalledWith("user-2", expect.any(Function));
      expect(profile).toEqual({
        username: "testuser",
        displayName: "Test User",
      });
    });
  });

  it("rzuca błąd gdy useChatContext jest użyte poza ChatProvider", () => {
    // Suppress console.error for this test
    const originalError = console.error;
    console.error = vi.fn();

    function TestComponent() {
      useChatContext();
      return null;
    }

    expect(() => {
      render(<TestComponent />);
    }).toThrow("ChatProvider is missing in the component tree.");

    console.error = originalError;
  });

  it("czyści subskrypcje przy unmount", () => {
    const unsubscribe = vi.fn();
    const subscribeUserProfile = vi.fn().mockReturnValue(unsubscribe);
    const client = createMockClient({ subscribeUserProfile });

    function TestComponent() {
      const { ensureProfileSubscription } = useChatContext();
      ensureProfileSubscription("user-2");
      ensureProfileSubscription("user-3");
      return null;
    }

    const { unmount } = render(
      <ChatProvider client={client} currentUserId="user-1">
        <TestComponent />
      </ChatProvider>
    );

    expect(subscribeUserProfile).toHaveBeenCalledTimes(2);

    unmount();

    expect(unsubscribe).toHaveBeenCalledTimes(2);
  });
});
