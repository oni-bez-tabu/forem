// Platform config
export { setPlatformConfig, getPlatformConfig, defaultPlatformConfig } from "./platform";
export type { PlatformConfig } from "./platform";

// Context
export {
  ChatProvider,
  ChatContext,
  useChatClient,
  useChatContext,
  useUserProfile,
  useCurrentUserId,
} from "./ChatProvider";
export type { UserProfile, ChatProviderProps } from "./ChatProvider";

// Hooks
export { useChat } from "./hooks/useChat";
export type { UseChatResult } from "./hooks/useChat";

export { useThread } from "./hooks/useThread";
export type { UseThreadResult, UiMessage, DeliveryStatus } from "./hooks/useThread";

export { useChatAppState } from "./hooks/useChatAppState";
export type { ChatAppState } from "./hooks/useChatAppState";

export { useThreadState } from "./hooks/useThreadState";
export type { UseThreadStateOptions, UseThreadStateResult } from "./hooks/useThreadState";
