import { render } from "@testing-library/react";
import { act } from "react";
import { describe, expect, it, vi } from "vitest";
import type { ChatClient, Message } from "@org/chat-core";
import { ChatProvider } from "../ChatProvider";
import { useThread } from "./useThread";

type HookValue = ReturnType<typeof useThread>;

function HookTester({
  onRender,
  threadId,
}: {
  onRender: (value: HookValue) => void;
  threadId: string;
}) {
  const value = useThread(threadId);
  onRender(value);
  return null;
}

function createMockClient(overrides: Partial<ChatClient> = {}): ChatClient {
  const base: ChatClient = {
    init: vi.fn(),
    getThreads: vi.fn(),
    openThread: vi.fn().mockResolvedValue(() => {}),
    sendMessage: vi.fn(),
    fetchMessages: vi.fn().mockResolvedValue([]),
    likeMessage: vi.fn(),
    unlikeMessage: vi.fn(),
    markAsRead: vi.fn(),
    getUnreadCount: vi.fn(),
    subscribeThreads: vi.fn(),
    acceptThread: vi.fn(),
    leaveThread: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    isUserBlocked: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn().mockResolvedValue(undefined),
    subscribeTyping: vi.fn().mockReturnValue(() => {}),
    subscribeTotalUnread: vi.fn().mockReturnValue(() => {}),
    subscribeUserProfile: vi.fn(),
    uploadImage: vi.fn(),
  };
  return { ...base, ...overrides };
}

describe("useThread", () => {
  const currentUserId = "user-1";

  it("subskrybuje openThread przy montowaniu i sprząta przy unmount", async () => {
    const unsubscribe = vi.fn();
    const openThread = vi.fn().mockResolvedValue(unsubscribe);
    const fetchMessages = vi.fn().mockResolvedValue([]);
    const client = createMockClient({ openThread, fetchMessages });
    const threadId = "thread-1";
    const renders: HookValue[] = [];

    const { unmount } = render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => renders.push(value)} />
      </ChatProvider>
    );

    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    expect(openThread).toHaveBeenCalledTimes(1);
    expect(openThread).toHaveBeenCalledWith(threadId, expect.any(Function));

    await act(async () => {
      unmount();
      await Promise.resolve();
    });
    expect(unsubscribe).toHaveBeenCalledTimes(1);
  });

  it("send tworzy wiadomość optymistyczną i woła chatClient.sendMessage", async () => {
    const sendMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({
      openThread: vi.fn().mockResolvedValue(() => {}),
      sendMessage,
    });
    const threadId = "thread-2";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await act(async () => {
      await latest?.send({ text: "hello world", replyToId: "reply-1" });
    });

    const call = sendMessage.mock.calls[0]?.[0];
    expect(call).toMatchObject({
      threadId,
      message: { text: "hello world", replyToId: "reply-1" },
    });
    expect(call.message.clientMessageId).toBeDefined();
    expect(latest?.messages[0].deliveryStatus).toBeDefined();
  });

  it("like wywołuje chatClient.likeMessage", async () => {
    const likeMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({
      openThread: vi.fn().mockResolvedValue(() => {}),
      likeMessage,
    });
    const threadId = "thread-3";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await act(async () => {
      await latest?.like("message-1");
    });

    expect(likeMessage).toHaveBeenCalledWith(threadId, "message-1");
  });

  it("unlike wywołuje chatClient.unlikeMessage", async () => {
    const unlikeMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({
      openThread: vi.fn().mockResolvedValue(() => {}),
      unlikeMessage,
    });
    const threadId = "thread-3";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await act(async () => {
      await latest?.unlike("message-1");
    });

    expect(unlikeMessage).toHaveBeenCalledWith(threadId, "message-1");
  });

  it("aktualizuje wiadomości po wywołaniu callbacka openThread", async () => {
    let onMessage: ((message: Message) => void) | null = null;
    const openThread = vi.fn().mockImplementation((_id: string, cb: (message: Message) => void) => {
      onMessage = cb;
      return Promise.resolve(() => {});
    });
    const fetchMessages = vi.fn().mockResolvedValue([]);
    const client = createMockClient({ openThread, fetchMessages });
    const threadId = "thread-4";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    // Wait for setup to complete
    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    const message: Message = {
      id: "m-1",
      threadId,
      senderId: "u1",
      type: "text",
      text: "hi",
      likes: [],
      readBy: [],
      createdAt: { seconds: 0, nanoseconds: 0 },
    };

    act(() => {
      onMessage?.(message);
    });

    expect(latest?.messages).toEqual([message]);
  });

  it("oznacza wiadomość jako failed przy błędzie i pozwala na retry", async () => {
    const sendMessage = vi
      .fn()
      .mockRejectedValueOnce(new Error("offline"))
      .mockResolvedValueOnce(undefined);
    const client = createMockClient({
      openThread: vi.fn().mockResolvedValue(() => {}),
      sendMessage,
    });
    const threadId = "thread-5";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await act(async () => {
      await expect(latest?.send({ text: "hello" })).rejects.toThrow();
    });

    const localId = latest?.messages[0].localId as string;
    expect(latest?.messages[0].deliveryStatus).toBe("failed");

    await act(async () => {
      await latest?.retry(localId);
    });

    expect(sendMessage).toHaveBeenCalledTimes(2);
    expect(latest?.messages[0].deliveryStatus).toBe("sent");
  });

  it("rekonsyliuje optymistyczną wiadomość gdy przyjdzie z serwera", async () => {
    let onMessage: ((message: Message) => void) | null = null;
    const openThread = vi.fn().mockImplementation((_id: string, cb: (message: Message) => void) => {
      onMessage = cb;
      return Promise.resolve(() => {});
    });
    const sendMessage = vi.fn().mockResolvedValue(undefined);
    const fetchMessages = vi.fn().mockResolvedValue([]);
    const client = createMockClient({ openThread, sendMessage, fetchMessages });
    const threadId = "thread-6";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    // Wait for setup to complete
    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    await act(async () => {
      await latest?.send({ text: "hello" });
    });

    const optimisticCount = latest?.messages.length ?? 0;
    expect(optimisticCount).toBe(1);
    const optimisticText = latest?.messages[0].text;

    const serverMessage: Message = {
      id: "srv-1",
      threadId,
      senderId: "local-user",
      clientMessageId: latest?.messages[0].clientMessageId,
      type: "text",
      text: optimisticText,
      likes: [],
      readBy: [],
      createdAt: { seconds: Math.floor(Date.now() / 1000), nanoseconds: 0 },
    };

    act(() => {
      onMessage?.(serverMessage);
    });

    expect(latest?.messages.some((m) => m.id.startsWith("local-"))).toBe(false);
    expect(latest?.messages[0].id).toBe("srv-1");
  });

  it("oznacza wysyłkę jako failed po upłynięciu timeoutu", async () => {
    vi.useFakeTimers();
    const sendMessage = vi.fn().mockImplementation(
      () =>
        new Promise<void>(() => {
          /* nigdy nie resolve/reject */
        })
    );
    const client = createMockClient({
      openThread: vi.fn().mockResolvedValue(() => {}),
      sendMessage,
    });
    const threadId = "thread-7";
    let latest: HookValue | null = null;

    render(
      <ChatProvider client={client}>
        <HookTester threadId={threadId} onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await act(async () => {
      const sendPromise = latest?.send({ text: "timeout" }) as Promise<unknown>;
      vi.advanceTimersByTime(9000);
      await expect(sendPromise).rejects.toThrow("Send timed out");
    });

    expect(latest?.messages[0].deliveryStatus).toBe("failed");
    vi.useRealTimers();
  });
});
