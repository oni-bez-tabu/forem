import { render, waitFor } from "@testing-library/react";
import { act } from "react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import type { ChatClient, Message, Thread } from "@org/chat-core";
import { ChatGloballyBannedError } from "@org/chat-core";
import { ChatProvider } from "../ChatProvider";
import { useThreadState, UseThreadStateResult } from "./useThreadState";

function HookTester({
  onRender,
  threadId,
  thread,
  currentUserId,
  isActive,
  onThreadActivity,
}: {
  onRender: (value: UseThreadStateResult) => void;
  threadId: string;
  thread?: Thread | null;
  currentUserId: string;
  isActive?: boolean;
  onThreadActivity?: () => Promise<void> | void;
}) {
  const value = useThreadState({ threadId, thread, currentUserId, isActive, onThreadActivity });
  onRender(value);
  return null;
}

function createMockClient(overrides: Partial<ChatClient> = {}): ChatClient {
  const base: ChatClient = {
    init: vi.fn(),
    getThreads: vi.fn(),
    openThread: vi.fn().mockResolvedValue(() => {}),
    sendMessage: vi.fn().mockResolvedValue(undefined),
    fetchMessages: vi.fn().mockResolvedValue([]),
    likeMessage: vi.fn().mockResolvedValue(undefined),
    unlikeMessage: vi.fn().mockResolvedValue(undefined),
    markAsRead: vi.fn().mockResolvedValue(undefined),
    getUnreadCount: vi.fn(),
    subscribeThreads: vi.fn(),
    acceptThread: vi.fn(),
    leaveThread: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    isUserBlocked: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn().mockResolvedValue(undefined),
    subscribeTyping: vi.fn().mockReturnValue(() => {}),
    subscribeTotalUnread: vi.fn().mockReturnValue(() => {}),
    subscribeUserProfile: vi.fn(),
    uploadImage: vi.fn(),
  };
  return { ...base, ...overrides };
}

function createMockThread(overrides: Partial<Thread> = {}): Thread {
  return {
    id: "thread-1",
    type: "direct",
    members: ["user-1", "user-2"],
    createdAt: { seconds: 0, nanoseconds: 0 },
    updatedAt: { seconds: 0, nanoseconds: 0 },
    ...overrides,
  } as Thread;
}

function createMockMessage(overrides: Partial<Message> = {}): Message {
  return {
    id: "msg-1",
    threadId: "thread-1",
    senderId: "user-2",
    type: "text",
    text: "Hello",
    likes: [],
    readBy: [],
    createdAt: { seconds: Date.now() / 1000, nanoseconds: 0 },
    ...overrides,
  };
}

describe("useThreadState", () => {
  const currentUserId = "user-1";
  const threadId = "thread-1";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("zwraca początkowy stan z pustą listą wiadomości", async () => {
    const client = createMockClient();
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    expect(latest?.messages).toEqual([]);
    expect(latest?.replyingTo).toBeNull();
    expect(latest?.sendError).toBeNull();
    expect(latest?.canSend).toBe(true);
  });

  it("wysyła wiadomość przez send i czyści błąd", async () => {
    const sendMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ sendMessage });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.send({ text: "Hello world" });
    });

    expect(sendMessage).toHaveBeenCalledTimes(1);
    expect(sendMessage.mock.calls[0][0]).toMatchObject({
      threadId,
      message: expect.objectContaining({ text: "Hello world" }),
    });
  });

  it("ustawia replyingTo i czyści po wysłaniu", async () => {
    const client = createMockClient();
    let latest: UseThreadStateResult | null = null;
    const replyMessage = createMockMessage({ id: "reply-target" });

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    act(() => {
      latest?.setReplyingTo(replyMessage);
    });

    expect(latest?.replyingTo).toEqual(replyMessage);

    await act(async () => {
      await latest?.send({ text: "Reply text" });
    });

    expect(latest?.replyingTo).toBeNull();
  });

  it("clearReply czyści replyingTo", async () => {
    const client = createMockClient();
    let latest: UseThreadStateResult | null = null;
    const replyMessage = createMockMessage({ id: "reply-target" });

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    act(() => {
      latest?.setReplyingTo(replyMessage);
    });

    expect(latest?.replyingTo).not.toBeNull();

    act(() => {
      latest?.clearReply();
    });

    expect(latest?.replyingTo).toBeNull();
  });

  it("canSend jest false gdy użytkownik zbanowany w community", async () => {
    const client = createMockClient();
    const thread = createMockThread({
      type: "community",
      bannedMembers: [currentUserId],
    });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          thread={thread}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    expect(latest?.canSend).toBe(false);
  });

  it("canSend jest false gdy wątek group wymaga akceptacji", async () => {
    const client = createMockClient();
    const thread = createMockThread({
      type: "group",
      acceptedBy: [], // user-1 nie zaakceptował
    });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          thread={thread}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    expect(latest?.canSend).toBe(false);
  });

  it("canSend jest false w direct gdy czeka na odpowiedź", async () => {
    const client = createMockClient();
    const thread = createMockThread({
      type: "direct",
      directUnlocked: false,
      lastMessage: createMockMessage({ senderId: currentUserId }),
    }) as Thread;
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          thread={thread}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    expect(latest?.canSend).toBe(false);
  });

  it("ustawia sendError przy ChatGloballyBannedError", async () => {
    const sendMessage = vi.fn().mockRejectedValue(new ChatGloballyBannedError());
    const client = createMockClient({ sendMessage });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.send({ text: "test" });
    });

    expect(latest?.sendError).toBe("User is globally banned from chat");
    expect(latest?.canSend).toBe(false);
  });

  it("clearError czyści sendError", async () => {
    const sendMessage = vi.fn().mockRejectedValue(new ChatGloballyBannedError());
    const client = createMockClient({ sendMessage });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.send({ text: "test" });
    });

    expect(latest?.sendError).not.toBeNull();

    act(() => {
      latest?.clearError();
    });

    expect(latest?.sendError).toBeNull();
  });

  it("onTyping wywołuje setTyping(true) gdy canSend", async () => {
    const setTyping = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ setTyping });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.onTyping();
    });

    expect(setTyping).toHaveBeenCalledWith(threadId, true);
  });

  it("onTyping nie wywołuje setTyping gdy canSend false", async () => {
    const setTyping = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ setTyping });
    const thread = createMockThread({
      type: "community",
      bannedMembers: [currentUserId],
    });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          thread={thread}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.onTyping();
    });

    expect(setTyping).not.toHaveBeenCalled();
  });

  it("onStopTyping wywołuje setTyping(false)", async () => {
    const setTyping = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ setTyping });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.onStopTyping();
    });

    expect(setTyping).toHaveBeenCalledWith(threadId, false);
  });

  it("wywołuje onThreadActivity po wysłaniu wiadomości", async () => {
    const client = createMockClient();
    const onThreadActivity = vi.fn().mockResolvedValue(undefined);
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onThreadActivity={onThreadActivity}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.send({ text: "test" });
    });

    expect(onThreadActivity).toHaveBeenCalled();
  });

  it("likeMessage wywołuje chatClient.likeMessage", async () => {
    const likeMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ likeMessage });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.likeMessage("msg-1");
    });

    expect(likeMessage).toHaveBeenCalledWith(threadId, "msg-1");
  });

  it("unlikeMessage wywołuje chatClient.unlikeMessage", async () => {
    const unlikeMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ unlikeMessage });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.unlikeMessage("msg-1");
    });

    expect(unlikeMessage).toHaveBeenCalledWith(threadId, "msg-1");
  });

  it("retry wywołuje retry z useThread", async () => {
    const sendMessage = vi
      .fn()
      .mockRejectedValueOnce(new Error("offline"))
      .mockResolvedValueOnce(undefined);
    const client = createMockClient({ sendMessage });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    // Wysyłamy wiadomość która failuje
    await act(async () => {
      try {
        await latest?.send({ text: "hello" });
      } catch {
        // expected
      }
    });

    const localId = latest?.messages[0]?.localId;
    expect(localId).toBeDefined();

    // Retry
    await act(async () => {
      await latest?.retry(localId!);
    });

    expect(sendMessage).toHaveBeenCalledTimes(2);
  });

  it("send nie wysyła gdy canSend jest false", async () => {
    const sendMessage = vi.fn().mockResolvedValue(undefined);
    const client = createMockClient({ sendMessage });
    const thread = createMockThread({
      type: "community",
      bannedMembers: [currentUserId],
    });
    let latest: UseThreadStateResult | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester
          threadId={threadId}
          thread={thread}
          currentUserId={currentUserId}
          onRender={(value) => (latest = value)}
        />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest).not.toBeNull();
    });

    await act(async () => {
      await latest?.send({ text: "test" });
    });

    expect(sendMessage).not.toHaveBeenCalled();
    expect(latest?.sendError).toBe("Brak uprawnień do wysyłania wiadomości.");
  });
});
