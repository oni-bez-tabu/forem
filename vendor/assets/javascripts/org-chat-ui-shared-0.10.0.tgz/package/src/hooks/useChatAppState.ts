import { useCallback, useEffect, useMemo, useState } from "react";
import type { Thread } from "@org/chat-core";
import { useChatClient } from "../ChatProvider";

export interface ChatAppState {
  threads: Thread[];
  loading: boolean;
  error: string | null;
  selectedThreadId: string | null;
  activeThread: Thread | null;
  selectThread: (threadId: string) => void;
  refreshThreads: () => Promise<void>;
  createConversation: (input: {
    type: Thread["type"];
    members: string[];
    name?: string;
    message: { text: string };
  }) => Promise<Thread | void>;
}

/**
 * Zarządza listą wątków oraz wyborem bieżącego wątku na bazie ChatClient.
 * Logika jest niezależna od platformy/renderingu.
 */
export function useChatAppState(): ChatAppState {
  const client = useChatClient();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const refreshThreads = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const fetched = await client.getThreads();
      setThreads(fetched);

      if (selectedThreadId && fetched.some((t) => t.id === selectedThreadId)) {
        return;
      }
      if (!selectedThreadId && fetched.length === 0) {
        return;
      }
      const nextSelected = selectedThreadId ?? fetched[0]?.id ?? null;
      setSelectedThreadId(nextSelected);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [client, selectedThreadId]);

  useEffect(() => {
    void refreshThreads();
  }, [refreshThreads]);

  // Subskrypcja zmian wątków (realtime)
  useEffect(() => {
    const unsubscribe = client.subscribeThreads((incomingThreads) => {
      setThreads(incomingThreads);
      if (!selectedThreadId && incomingThreads.length > 0) {
        setSelectedThreadId(incomingThreads[0].id);
      } else if (selectedThreadId && !incomingThreads.some((t) => t.id === selectedThreadId)) {
        setSelectedThreadId(incomingThreads[0]?.id ?? null);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [client, selectedThreadId]);

  const activeThread = useMemo(
    () => threads.find((thread: Thread) => thread.id === selectedThreadId) ?? null,
    [threads, selectedThreadId]
  );

  const selectThread = useCallback((threadId: string) => {
    setSelectedThreadId(threadId);
  }, []);

  const createConversation = useCallback(
    async (input: {
      type: Thread["type"];
      members: string[];
      name?: string;
      message: { text: string };
    }): Promise<Thread | void> => {
      setError(null);
      const result = await client.sendMessage({
        threadType: input.type,
        members: input.members,
        name: input.name,
        message: input.message,
      });

      // Po stworzeniu/aktualizacji – odśwież listę wątków; jeśli powstał nowy wątek, wybierz go.
      const refreshed = await client.getThreads();
      setThreads(refreshed);
      const createdThreadId =
        (result && typeof result === "object" && "id" in result ? (result as Thread).id : undefined) ?? refreshed[0]?.id ??
        null;
      if (createdThreadId) {
        setSelectedThreadId(createdThreadId);
      }
      return result as Thread | void;
    },
    [client]
  );

  return {
    threads,
    loading,
    error,
    selectedThreadId,
    activeThread,
    selectThread,
    refreshThreads,
    createConversation,
  };
}
