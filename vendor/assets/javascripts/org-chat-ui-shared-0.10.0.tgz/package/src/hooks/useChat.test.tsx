import { render, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { ChatClient, Thread } from "@org/chat-core";
import { ChatProvider } from "../ChatProvider";
import { useChat } from "./useChat";

type RenderProps = {
  onRender: (value: ReturnType<typeof useChat>) => void;
};

function createDeferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((res) => {
    resolve = res;
  });
  return { promise, resolve };
}

function HookTester({ onRender }: RenderProps) {
  const value = useChat();
  onRender(value);
  return null;
}

function createMockClient(subscribeImpl: (cb: (threads: Thread[]) => void) => () => void): ChatClient {
  return {
    init: vi.fn(),
    getThreads: vi.fn().mockResolvedValue([] as Thread[]),
    subscribeThreads: vi.fn().mockImplementation(subscribeImpl),
    openThread: vi.fn(),
    sendMessage: vi.fn(),
    fetchMessages: vi.fn(),
    likeMessage: vi.fn(),
    unlikeMessage: vi.fn(),
    markAsRead: vi.fn(),
    getUnreadCount: vi.fn(),
    acceptThread: vi.fn(),
    subscribeTotalUnread: vi.fn().mockReturnValue(() => {}),
    leaveThread: vi.fn(),
    isUserBlocked: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn(),
    subscribeTyping: vi.fn(),
    subscribeUserProfile: vi.fn().mockReturnValue(() => {}),
    uploadImage: vi.fn(),
  };
}

describe("useChat", () => {
  const currentUserId = "user-1";

  it("ustawia loading na true zanim nadejdą wątki z subskrypcji", async () => {
    const callbacks: Array<(threads: Thread[]) => void> = [];
    const client = createMockClient((cb) => {
      callbacks.push(cb);
      return () => {};
    });
    const renders: ReturnType<typeof useChat>[] = [];

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => renders.push(value)} />
      </ChatProvider>
    );

    expect(renders[0]?.loading).toBe(true);
    expect(client.subscribeThreads).toHaveBeenCalledTimes(1);

    callbacks[0]?.([]);
    await waitFor(() => expect(renders.at(-1)?.loading).toBe(false));
  });

  it("zwraca wątki z subscribeThreads po zakończeniu ładowania", async () => {
    const threads: Thread[] = [
      {
        id: "t-1",
        type: "direct",
        members: ["u1", "u2"],
        createdAt: { seconds: 0, nanoseconds: 0 },
        lastMessage: undefined,
        unreadCount: 0,
      },
    ];
    const client = createMockClient((cb) => {
      cb(threads);
      return () => {};
    });
    const renders: ReturnType<typeof useChat>[] = [];

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => renders.push(value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(renders.at(-1)?.loading).toBe(false);
      expect(renders.at(-1)?.threads).toEqual(threads);
    });
  });
});
