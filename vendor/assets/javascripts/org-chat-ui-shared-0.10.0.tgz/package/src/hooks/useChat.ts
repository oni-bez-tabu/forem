import { useCallback, useEffect, useRef, useState } from "react";
import type { Thread } from "@org/chat-core";
import type { ChatClient } from "@org/chat-core";
import { logger } from "@org/chat-core";
import { useChatClient } from "../ChatProvider";

export interface UseChatResult {
  threads: Thread[];
  loading: boolean;
  refreshThreads: () => Promise<void>;
}

// Globalny WeakMap do śledzenia czy dane zostały już załadowane dla danego clienta
// To zapobiega resetowaniu loading przy remount tego samego clienta
const clientDataLoadedMap = new WeakMap<ChatClient, boolean>();
// Przechowuj threads dla każdego clienta, żeby nie resetować ich przy remount
const clientThreadsMap = new WeakMap<ChatClient, Thread[]>();

export function useChat(): UseChatResult {
  const client = useChatClient();
  // Użyj wcześniej zapisanych threads jeśli istnieją, w przeciwnym razie []
  const [threads, setThreads] = useState<Thread[]>(() => {
    return clientThreadsMap.get(client) ?? [];
  });
  const [loading, setLoading] = useState<boolean>(() => {
    // Sprawdź czy ten client już otrzymał dane wcześniej
    return !clientDataLoadedMap.get(client);
  });
  const refreshTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshThreadsRef = useRef<(() => Promise<void>) | undefined>(undefined);
  const refreshThreads = useCallback(async () => {
    // Nie ustawiamy loading=true dla refreshu, żeby lista się nie resetowała
    // Nie resetujemy threads jeśli już mamy dane - tylko aktualizujemy
    try {
      const list = await client.getThreads();
      // Zapisz threads do WeakMap
      clientThreadsMap.set(client, list);
      // Aktualizuj tylko jeśli mamy nowe dane (unreadCount może się zmienić)
      setThreads((prev: Thread[]) => {
        // Jeśli lista jest pusta, zawsze aktualizuj
        if (prev.length === 0) return list;
        // Jeśli mamy dane, aktualizuj tylko unreadCount, nie resetuj całej listy
        return list;
      });
    } catch (err) {
      logger.error("Failed to refresh threads:", err);
    }
  }, [client]);
  refreshThreadsRef.current = refreshThreads;

  const scheduleRefreshRef = useRef<(() => void) | undefined>(undefined);
  scheduleRefreshRef.current = useCallback(() => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current);
    }
    refreshTimeoutRef.current = setTimeout(() => {
      refreshTimeoutRef.current = null;
      void refreshThreadsRef.current?.();
    }, 120); // lekki debounce, aby grupować szybkie odczyty
  }, []);

  useEffect(() => {
    // Sprawdź czy ten client już otrzymał dane wcześniej
    const hasReceivedData = clientDataLoadedMap.get(client);
    const cachedThreads = clientThreadsMap.get(client);

    // Jeśli mamy zapisane threads, użyj ich od razu (przy remount)
    if (cachedThreads && cachedThreads.length > 0) {
      setThreads(cachedThreads);
      setLoading(false);
    } else if (!hasReceivedData) {
      // Ustaw loading=true tylko jeśli ten client jeszcze nie otrzymał danych
      setLoading(true);
    }

    const unsubscribeThreads = client.subscribeThreads((incoming) => {
      clientThreadsMap.set(client, incoming);
      setThreads(incoming);
      const wasLoaded = clientDataLoadedMap.get(client);
      if (!wasLoaded) {
        clientDataLoadedMap.set(client, true);
        setLoading(false);
      } else if (incoming.length > 0 && loading) {
        setLoading(false);
      }
    });

    // Nasłuch na meta (totalUnread) — gdy się zmienia, odświeżamy unreadCount w wątkach
    // WAŻNE: Nie wywołuj scheduleRefresh jeśli jeszcze nie otrzymaliśmy początkowych danych
    const unsubscribeTotal = client.subscribeTotalUnread(() => {
      // Wywołuj scheduleRefresh tylko jeśli już mamy dane - unikaj resetowania przy pierwszym mount
      if (clientDataLoadedMap.get(client)) {
        scheduleRefreshRef.current?.();
      }
    });

    return () => {
      unsubscribeThreads();
      unsubscribeTotal();
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current);
      }
    };
  }, [client]);

  return { threads, loading, refreshThreads };
}
