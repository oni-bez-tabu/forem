import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Message, SendMessageInput, Timestamp, Thread } from "@org/chat-core";
import { logger } from "@org/chat-core";
import { useChatClient } from "../ChatProvider";
import { getPlatformConfig } from "../platform";

const SEND_TIMEOUT_MS = 8000; // UI-defined timeout (spec: reasonable 5–10s)
const PAGE_SIZE = 30;

export type DeliveryStatus = "sending" | "sent" | "failed";

export type UiMessage = Message & {
  localId?: string;
  deliveryStatus?: DeliveryStatus;
  errorMessage?: string;
  optimistic?: boolean;
};

export interface UseThreadResult {
  messages: UiMessage[];
  send: (input: SendMessageInput) => Promise<void | Thread>;
  retry: (localId: string) => Promise<void | Thread>;
  like: (messageId: string) => Promise<void>;
  unlike: (messageId: string) => Promise<void>;
  markAsRead: (messageId: string) => Promise<void>;
  typingUsers: string[];
  setTyping: (isTyping: boolean) => Promise<void>;
  loadOlder: () => Promise<void>;
  loadingOlder: boolean;
  hasMoreOlder: boolean;
}

function compareTimestamps(a: Timestamp, b: Timestamp): number {
  if (a.seconds === b.seconds) {
    return a.nanoseconds - b.nanoseconds;
  }
  return a.seconds - b.seconds;
}

function sortMessages(items: UiMessage[]): UiMessage[] {
  return [...items].sort((a, b) => compareTimestamps(a.createdAt, b.createdAt));
}

function nowTimestamp(): Timestamp {
  const now = Date.now();
  return {
    seconds: Math.floor(now / 1000),
    nanoseconds: (now % 1000) * 1_000_000,
  };
}

function matchOptimistic(remote: Message, optimistic: UiMessage): boolean {
  if (remote.clientMessageId && optimistic.clientMessageId) {
    return remote.clientMessageId === optimistic.clientMessageId;
  }
  return remote.id === optimistic.id;
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const handle = setTimeout(() => reject(new Error("Send timed out")), ms);
    promise
      .then((val) => {
        clearTimeout(handle);
        resolve(val);
      })
      .catch((err) => {
        clearTimeout(handle);
        reject(err);
      });
  });
}

function isDomainBlockedError(err: unknown): boolean {
  if (!(err instanceof Error)) {
    return false;
  }
  const code = (err as { code?: string }).code;
  const message = err.message || "";
  if (code === "WAIT_FOR_REPLY" || code === "CONSENT_REQUIRED") {
    return true;
  }
  const normalized = message.toUpperCase();
  return normalized.includes("WAIT FOR THE OTHER USER TO REPLY") || normalized.includes("CONSENT_REQUIRED");
}

export function useThread(threadId: string, currentUserId?: string): UseThreadResult {
  const client = useChatClient();
  const [remoteMessages, setRemoteMessages] = useState<UiMessage[]>([]);
  const [optimisticMessages, setOptimisticMessages] = useState<UiMessage[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [loadingOlder, setLoadingOlder] = useState<boolean>(false);
  const [hasMoreOlder, setHasMoreOlder] = useState<boolean>(true);
  const oldestMessageIdRef = useRef<string | null>(null);
  const oldestMessageTimestampRef = useRef<Timestamp | null>(null);
  const initialLoadedRef = useRef<boolean>(false);
  const payloadByLocalId = useRef<Map<string, SendMessageInput>>(new Map());
  const typingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setRemoteMessages([]);
    setOptimisticMessages([]);
    setTypingUsers([]);
    setHasMoreOlder(true);
    setLoadingOlder(false);
    oldestMessageIdRef.current = null;
    initialLoadedRef.current = false;
    payloadByLocalId.current = new Map();
    let active = true;
    let unsubscribe: (() => void) | null = null;

    const setup = async () => {
      try {
        // Najpierw załaduj ostatnią stronę historii
        const page = await client.fetchMessages(threadId, { limit: PAGE_SIZE });
        if (!active) {
          return;
        }
        initialLoadedRef.current = true;
        oldestMessageIdRef.current = page[0]?.id ?? null;
        oldestMessageTimestampRef.current = page[0]?.createdAt ?? null;
        setHasMoreOlder(page.length === PAGE_SIZE);
        setRemoteMessages(sortMessages(page));

        const handler = (message: Message) => {
          // Jeśli mamy jeszcze starsze strony do pobrania, pomijaj wiadomości starsze niż najstarsza w pamięci
          if (
            hasMoreOlder &&
            oldestMessageTimestampRef.current &&
            compareTimestamps(message.createdAt, oldestMessageTimestampRef.current) < 0
          ) {
            return;
          }

          setRemoteMessages((prev: UiMessage[]) => {
            const existingIndex = prev.findIndex((item: UiMessage) => item.id === message.id);
            if (existingIndex >= 0) {
              const next = [...prev];
              next[existingIndex] = message;
              return sortMessages(next);
            }
            return sortMessages([...prev, message]);
          });

          setOptimisticMessages((prev: UiMessage[]) => {
            const matchIndex = prev.findIndex((opt: UiMessage) => matchOptimistic(message, opt));
            if (matchIndex === -1) {
              return prev;
            }
            const next = [...prev];
            next.splice(matchIndex, 1);
            return next;
          });
        };

        const stop = await client.openThread(threadId, handler);
        if (!active) {
          stop();
          return;
        }
        unsubscribe = stop;
      } catch (err) {
        logger.error("Failed to open thread subscription", err);
      }
    };

    void setup();

    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [client, threadId]);

  useEffect(() => {
    let unsub: (() => void) | null = null;
    const start = () => {
      unsub = client.subscribeTyping(threadId, (userIds) => {
        const filtered = userIds.filter((id) => id !== currentUserId);
        setTypingUsers(filtered);
      });
    };
    start();
    return () => {
      unsub?.();
    };
  }, [client, threadId, currentUserId]);

  const send = useCallback(
    async (input: SendMessageInput) => {
      const platform = getPlatformConfig();
      const localId = platform.generateId();
      const clientMessageId = localId;
      const offline = !platform.isOnline();
      const optimistic: UiMessage = {
        id: `local-${localId}`,
        localId,
        clientMessageId,
        optimistic: true,
        deliveryStatus: offline ? "failed" : "sending",
        errorMessage: offline ? "Offline" : undefined,
        senderId: currentUserId ?? "local-user",
        threadId,
        type: input.imageUrl ? "image" : "text",
        text: input.text,
        imageUrl: input.imageUrl,
        replyTo: input.replyToId
          ? {
              messageId: input.replyToId,
              senderId: "",
            }
          : undefined,
        likes: [],
        readBy: [],
        createdAt: nowTimestamp(),
      };

      setOptimisticMessages((prev: UiMessage[]) => sortMessages([...prev, optimistic]));
      payloadByLocalId.current.set(localId, { ...input, clientMessageId });

      if (offline) {
        const error = new Error("Offline");
        throw error;
      }

      try {
        const result = await withTimeout(
          client.sendMessage({ threadId, message: { ...input, clientMessageId } }),
          SEND_TIMEOUT_MS
        );
        setOptimisticMessages((prev: UiMessage[]) =>
          prev.map((msg: UiMessage) => (msg.localId === localId ? { ...msg, deliveryStatus: "sent", errorMessage: undefined } : msg))
        );
        return result;
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : "Failed to send message";
        if (isDomainBlockedError(err)) {
          payloadByLocalId.current.delete(localId);
          setOptimisticMessages((prev: UiMessage[]) => prev.filter((msg: UiMessage) => msg.localId !== localId));
        } else {
          setOptimisticMessages((prev: UiMessage[]) =>
            prev.map((msg: UiMessage) =>
              msg.localId === localId ? { ...msg, deliveryStatus: "failed", errorMessage } : msg
            )
          );
        }
        throw err;
      }
    },
    [client, threadId, currentUserId]
  );

  const retry = useCallback(
    async (localId: string) => {
      const payload = payloadByLocalId.current.get(localId);
      if (!payload) {
        return;
      }
      const target = optimisticMessages.find((m: UiMessage) => m.localId === localId);
      if (target?.deliveryStatus === "sending") {
        return;
      }

      setOptimisticMessages((prev: UiMessage[]) =>
        prev.map((msg: UiMessage) =>
          msg.localId === localId
            ? { ...msg, deliveryStatus: "sending", errorMessage: undefined }
            : msg
        )
      );

      try {
        const platform = getPlatformConfig();
        const offline = !platform.isOnline();
        if (offline) {
          setOptimisticMessages((prev: UiMessage[]) =>
            prev.map((msg: UiMessage) =>
              msg.localId === localId ? { ...msg, deliveryStatus: "failed", errorMessage: "Offline" } : msg
            )
          );
          throw new Error("Offline");
        }
        const result = await withTimeout(
          client.sendMessage({ threadId, message: { ...payload, clientMessageId: payload.clientMessageId } }),
          SEND_TIMEOUT_MS
        );
        setOptimisticMessages((prev: UiMessage[]) =>
          prev.map((msg: UiMessage) => (msg.localId === localId ? { ...msg, deliveryStatus: "sent" } : msg))
        );
        return result;
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : "Failed to send message";
        if (isDomainBlockedError(err)) {
          payloadByLocalId.current.delete(localId);
          setOptimisticMessages((prev: UiMessage[]) => prev.filter((msg: UiMessage) => msg.localId !== localId));
        } else {
          setOptimisticMessages((prev: UiMessage[]) =>
            prev.map((msg: UiMessage) =>
              msg.localId === localId ? { ...msg, deliveryStatus: "failed", errorMessage } : msg
            )
          );
        }
        throw err;
      }
    },
    [client, threadId, optimisticMessages]
  );

  const like = useCallback(
    (messageId: string) => client.likeMessage(threadId, messageId),
    [client, threadId]
  );

  const unlike = useCallback(
    (messageId: string) => client.unlikeMessage(threadId, messageId),
    [client, threadId]
  );

  const loadOlder = useCallback(async () => {
    if (loadingOlder || !hasMoreOlder) {
      return;
    }
    if (!initialLoadedRef.current) {
      // Jeśli jeszcze nie załadowano initial page (race), poczekaj
      return;
    }
    setLoadingOlder(true);
    try {
      const cursor = oldestMessageIdRef.current ?? undefined;
      const page = await client.fetchMessages(threadId, {
        limit: PAGE_SIZE,
        beforeMessageId: cursor,
      });
      if (page.length > 0) {
        oldestMessageIdRef.current = page[0].id;
        oldestMessageTimestampRef.current = page[0].createdAt;
        setRemoteMessages((prev: UiMessage[]) => {
          const merged = [...page, ...prev];
          const unique = new Map<string, UiMessage>();
          merged.forEach((m) => {
            unique.set(m.id, m);
          });
          return sortMessages(Array.from(unique.values()));
        });
      }
      if (page.length < PAGE_SIZE) {
        setHasMoreOlder(false);
      }
    } finally {
      setLoadingOlder(false);
    }
  }, [client, threadId, hasMoreOlder, loadingOlder]);

  const markAsRead = useCallback(
    (messageId: string) => client.markAsRead(threadId, messageId),
    [client, threadId]
  );

  const setTyping = useCallback(
    async (isTyping: boolean) => {
      if (typingTimeout.current) {
        clearTimeout(typingTimeout.current);
        typingTimeout.current = null;
      }
      if (isTyping) {
        typingTimeout.current = setTimeout(() => {
          void client.setTyping(threadId, false);
        }, 3000);
      }
      await client.setTyping(threadId, isTyping);
    },
    [client, threadId]
  );

  useEffect(() => {
    return () => {
      if (typingTimeout.current) {
        clearTimeout(typingTimeout.current);
      }
    };
  }, []);

  const messages = useMemo(() => {
    const optimisticNotDuplicated = optimisticMessages.filter(
      (opt: UiMessage) => !remoteMessages.some((remote: UiMessage) => matchOptimistic(remote, opt))
    );
    // Nie pokazuj optymistycznej wersji, jeśli z serwera przyszła treściowo ta sama wiadomość
    return sortMessages([...remoteMessages, ...optimisticNotDuplicated]);
  }, [remoteMessages, optimisticMessages]);

  return {
    messages,
    send,
    retry,
    like,
    unlike,
    markAsRead,
    typingUsers,
    setTyping,
    loadOlder,
    loadingOlder,
    hasMoreOlder,
  };
}
