import { render, waitFor } from "@testing-library/react";
import { act } from "react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import type { ChatClient, Thread } from "@org/chat-core";
import { ChatProvider } from "../ChatProvider";
import { useChatAppState, ChatAppState } from "./useChatAppState";

function HookTester({ onRender }: { onRender: (value: ChatAppState) => void }) {
  const value = useChatAppState();
  onRender(value);
  return null;
}

function createMockThread(overrides: Partial<Thread> = {}): Thread {
  return {
    id: "thread-1",
    type: "direct",
    members: ["user-1", "user-2"],
    createdAt: { seconds: 0, nanoseconds: 0 },
    updatedAt: { seconds: 0, nanoseconds: 0 },
    ...overrides,
  } as Thread;
}

function createMockClient(overrides: Partial<ChatClient> = {}): ChatClient {
  const base: ChatClient = {
    init: vi.fn(),
    getThreads: vi.fn().mockResolvedValue([]),
    openThread: vi.fn().mockResolvedValue(() => {}),
    sendMessage: vi.fn().mockResolvedValue(undefined),
    fetchMessages: vi.fn().mockResolvedValue([]),
    likeMessage: vi.fn().mockResolvedValue(undefined),
    unlikeMessage: vi.fn().mockResolvedValue(undefined),
    markAsRead: vi.fn().mockResolvedValue(undefined),
    getUnreadCount: vi.fn(),
    subscribeThreads: vi.fn().mockReturnValue(() => {}),
    acceptThread: vi.fn(),
    leaveThread: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    isUserBlocked: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn().mockResolvedValue(undefined),
    subscribeTyping: vi.fn().mockReturnValue(() => {}),
    subscribeTotalUnread: vi.fn().mockReturnValue(() => {}),
    subscribeUserProfile: vi.fn().mockReturnValue(() => {}),
    uploadImage: vi.fn(),
  };
  return { ...base, ...overrides };
}

describe("useChatAppState", () => {
  const currentUserId = "user-1";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("zwraca początkowy stan z loading=true", async () => {
    const getThreads = vi.fn().mockResolvedValue([]);
    const client = createMockClient({ getThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    // Initially loading should be true
    expect(latest?.loading).toBe(true);
    expect(latest?.threads).toEqual([]);

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });
  });

  it("ładuje wątki z getThreads przy montowaniu", async () => {
    const threads = [createMockThread({ id: "t1" }), createMockThread({ id: "t2" })];
    const getThreads = vi.fn().mockResolvedValue(threads);
    const client = createMockClient({ getThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    expect(getThreads).toHaveBeenCalled();
    expect(latest?.threads).toHaveLength(2);
    expect(latest?.threads[0].id).toBe("t1");
  });

  it("ustawia selectedThreadId na pierwszy wątek po załadowaniu", async () => {
    const threads = [createMockThread({ id: "t1" }), createMockThread({ id: "t2" })];
    const getThreads = vi.fn().mockResolvedValue(threads);
    const client = createMockClient({ getThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    expect(latest?.selectedThreadId).toBe("t1");
    expect(latest?.activeThread?.id).toBe("t1");
  });

  it("selectThread zmienia selectedThreadId", async () => {
    const threads = [createMockThread({ id: "t1" }), createMockThread({ id: "t2" })];
    const getThreads = vi.fn().mockResolvedValue(threads);
    const client = createMockClient({ getThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    expect(latest?.selectedThreadId).toBe("t1");

    act(() => {
      latest?.selectThread("t2");
    });

    expect(latest?.selectedThreadId).toBe("t2");
    expect(latest?.activeThread?.id).toBe("t2");
  });

  it("subscribeThreads aktualizuje listę wątków", async () => {
    const threads = [createMockThread({ id: "t1" })];
    let subscribeCallback: ((threads: Thread[]) => void) | null = null;
    const subscribeThreads = vi.fn().mockImplementation((cb) => {
      subscribeCallback = cb;
      return () => {};
    });
    const getThreads = vi.fn().mockResolvedValue(threads);
    const client = createMockClient({ getThreads, subscribeThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    expect(subscribeThreads).toHaveBeenCalled();
    expect(latest?.threads).toHaveLength(1);

    // Simulate new threads from subscription
    const newThreads = [createMockThread({ id: "t1" }), createMockThread({ id: "t3" })];
    act(() => {
      subscribeCallback?.(newThreads);
    });

    expect(latest?.threads).toHaveLength(2);
    expect(latest?.threads[1].id).toBe("t3");
  });

  it("ustawia error gdy getThreads rzuci błąd", async () => {
    const getThreads = vi.fn().mockRejectedValue(new Error("Network error"));
    const client = createMockClient({ getThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    expect(latest?.error).toBe("Network error");
  });

  it("refreshThreads odświeża listę wątków", async () => {
    // Note: refreshThreads is called automatically when selectedThreadId changes,
    // so we return the same threads to avoid complications
    const threads = [createMockThread({ id: "t1" })];
    const getThreads = vi.fn().mockResolvedValue(threads);
    // Disable subscription to avoid interference
    const subscribeThreads = vi.fn().mockReturnValue(() => {});
    const client = createMockClient({ getThreads, subscribeThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    const initialCallCount = getThreads.mock.calls.length;

    await act(async () => {
      await latest?.refreshThreads();
    });

    // Verify refreshThreads was called (getThreads call count increased)
    expect(getThreads.mock.calls.length).toBeGreaterThan(initialCallCount);
    expect(latest?.threads).toEqual(threads);
  });

  it("createConversation wywołuje sendMessage i odświeża wątki", async () => {
    const newThread = createMockThread({ id: "new-thread" });
    let callCount = 0;
    const getThreads = vi.fn().mockImplementation(() => {
      callCount++;
      return Promise.resolve(callCount === 1 ? [] : [newThread]);
    });
    const sendMessage = vi.fn().mockResolvedValue(newThread);
    // Disable subscription to avoid interference
    const subscribeThreads = vi.fn().mockReturnValue(() => {});
    const client = createMockClient({ getThreads, sendMessage, subscribeThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    await act(async () => {
      await latest?.createConversation({
        type: "direct",
        members: ["user-1", "user-2"],
        message: { text: "Hello!" },
      });
    });

    expect(sendMessage).toHaveBeenCalledWith({
      threadType: "direct",
      members: ["user-1", "user-2"],
      message: { text: "Hello!" },
    });
    expect(latest?.selectedThreadId).toBe("new-thread");
  });

  it("resetuje selectedThreadId gdy aktualny wątek zniknie z listy", async () => {
    const threads = [createMockThread({ id: "t1" }), createMockThread({ id: "t2" })];
    let subscribeCallback: ((threads: Thread[]) => void) | null = null;
    const subscribeThreads = vi.fn().mockImplementation((cb) => {
      subscribeCallback = cb;
      return () => {};
    });
    const getThreads = vi.fn().mockResolvedValue(threads);
    const client = createMockClient({ getThreads, subscribeThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    act(() => {
      latest?.selectThread("t2");
    });

    expect(latest?.selectedThreadId).toBe("t2");

    // Simulate t2 being removed from the list
    act(() => {
      subscribeCallback?.([createMockThread({ id: "t1" })]);
    });

    expect(latest?.selectedThreadId).toBe("t1");
  });

  it("ustawia selectedThreadId gdy nowy wątek pojawi się a brak wybranego", async () => {
    let subscribeCallback: ((threads: Thread[]) => void) | null = null;
    const subscribeThreads = vi.fn().mockImplementation((cb) => {
      subscribeCallback = cb;
      return () => {};
    });
    const getThreads = vi.fn().mockResolvedValue([]);
    const client = createMockClient({ getThreads, subscribeThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    expect(latest?.selectedThreadId).toBeNull();

    // Simulate new thread appearing
    act(() => {
      subscribeCallback?.([createMockThread({ id: "new-thread" })]);
    });

    expect(latest?.selectedThreadId).toBe("new-thread");
  });

  it("nie zmienia selectedThreadId gdy wątek nadal istnieje", async () => {
    const threads = [createMockThread({ id: "t1" }), createMockThread({ id: "t2" })];
    let subscribeCallback: ((threads: Thread[]) => void) | null = null;
    const subscribeThreads = vi.fn().mockImplementation((cb) => {
      subscribeCallback = cb;
      return () => {};
    });
    const getThreads = vi.fn().mockResolvedValue(threads);
    const client = createMockClient({ getThreads, subscribeThreads });
    let latest: ChatAppState | null = null;

    render(
      <ChatProvider client={client} currentUserId={currentUserId}>
        <HookTester onRender={(value) => (latest = value)} />
      </ChatProvider>
    );

    await waitFor(() => {
      expect(latest?.loading).toBe(false);
    });

    act(() => {
      latest?.selectThread("t2");
    });

    expect(latest?.selectedThreadId).toBe("t2");

    // Update threads but keep t2
    act(() => {
      subscribeCallback?.([
        createMockThread({ id: "t1" }),
        createMockThread({ id: "t2" }),
        createMockThread({ id: "t3" }),
      ]);
    });

    expect(latest?.selectedThreadId).toBe("t2");
  });
});
