// Platform utilities - can be overridden by platform-specific packages

export interface PlatformConfig {
  isOnline: () => boolean;
  generateId: () => string;
}

// Default implementation (works in browser, fallbacks for other envs)
export const defaultPlatformConfig: PlatformConfig = {
  isOnline: () => {
    if (typeof navigator !== "undefined" && "onLine" in navigator) {
      return navigator.onLine;
    }
    return true; // Assume online if can't detect
  },
  generateId: () => {
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  },
};

let platformConfig = defaultPlatformConfig;

export function setPlatformConfig(config: Partial<PlatformConfig>): void {
  platformConfig = { ...platformConfig, ...config };
}

export function getPlatformConfig(): PlatformConfig {
  return platformConfig;
}
