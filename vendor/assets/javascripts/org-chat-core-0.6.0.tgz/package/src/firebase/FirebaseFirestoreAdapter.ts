import {
  arrayRemove,
  arrayUnion,
  collection,
  CollectionReference,
  deleteField,
  deleteDoc,
  doc,
  DocumentSnapshot,
  Firestore,
  getDoc,
  getDocs,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  startAfter,
  serverTimestamp,
  setDoc,
  Transaction,
  updateDoc,
  where,
  writeBatch,
  QueryConstraint,
} from "firebase/firestore";
import { FirestoreAdapter, RateLimitConsumeInput, RateLimitConsumeResult } from "../MessageService.js";
import { Message, MessageType, ReplyTo, Timestamp, Thread, ThreadType, UserProfile } from "../types.js";
import { ChatFirestoreAdapter } from "../ChatClient.js";
import { logger } from "../utils/logger.js";

type MessageDoc = {
  threadId: string;
  senderId: string;
  clientMessageId?: string;
  type: MessageType;
  text?: string;
  imageUrl?: string;
  replyTo?: ReplyTo;
  likes: string[];
  readBy: string[];
  createdAt: Timestamp;
  mentions?: string[];
};

type SendRateState = {
  dayCount: number;
  minuteBucket: number;
  minuteCount: number;
  burstStartMs: number;
  burstCount: number;
  suspendedUntilMs?: number;
};

type CreateThreadRateState = {
  dayCount: number;
  hourBucket: number;
  hourCount: number;
};

type RateLimitDoc = {
  day?: string;
  sendDirect?: SendRateState;
  sendGroupOrCommunity?: SendRateState;
  createThread?: CreateThreadRateState;
};

export class FirebaseFirestoreAdapter implements FirestoreAdapter, ChatFirestoreAdapter {
  private readonly db: Firestore;

  constructor(db: Firestore) {
    this.db = db;
  }

  /**
   * Centralne logowanie wszystkich operacji Firebase
   * @param firebaseOp - Szczegółowa operacja Firebase (getDoc, setDoc, updateDoc, deleteDoc, getDocs, writeBatch, runTransaction, onSnapshot)
   * @param path - Ścieżka do dokumentu/kolekcji (np. "threads/threadId", "messages/threadId/items")
   * @param data - Dane operacji (opcjonalne, dla setDoc/updateDoc). Może zawierać pole _operationType: "get" | "create" | "update" | "delete" do nadpisania domyślnego typu
   */
  private logFirebaseOperation(
    firebaseOp: string,
    path: string,
    data?: unknown
  ): void {
    // Mapowanie szczegółowych operacji Firebase na podstawowe typy dla debugowania
    const operationMap: Record<string, "get" | "create" | "update" | "delete"> = {
      getDoc: "get",
      getDocs: "get",
      onSnapshot: "get",
      setDoc: "update", // domyślnie update, bo wszystkie setDoc w kodzie używają merge: true
      updateDoc: "update",
      deleteDoc: "delete",
      writeBatch: "update", // batch może zawierać różne operacje, domyślnie "update"
      runTransaction: "update", // transakcja może zawierać różne operacje, domyślnie "update"
    };

    // Sprawdź czy w danych jest jawnie określony typ operacji
    let operation: "get" | "create" | "update" | "delete" = operationMap[firebaseOp] || "get";
    
    if (data && typeof data === "object" && "_operationType" in data) {
      const dataObj = data as { _operationType?: "get" | "create" | "update" | "delete" };
      if (dataObj._operationType) {
        operation = dataObj._operationType;
      }
    }
    
    // Dla writeBatch i runTransaction, określ typ na podstawie operacji w batchu
    if ((firebaseOp === "writeBatch" || firebaseOp === "runTransaction") && data && typeof data === "object") {
      const dataObj = data as { operations?: Array<{ type?: string }>; _operationType?: "get" | "create" | "update" | "delete" };
      
      // Jeśli nie ma jawnie określonego typu, sprawdź operacje w batchu
      if (!dataObj._operationType && dataObj.operations && Array.isArray(dataObj.operations)) {
        const hasDelete = dataObj.operations.some(op => op.type === "delete");
        const hasUpdate = dataObj.operations.some(op => op.type === "update");
        const hasSet = dataObj.operations.some(op => op.type === "set");
        
        // Priorytet: delete > update > create
        if (hasDelete) {
          operation = "delete";
        } else if (hasUpdate) {
          operation = "update";
        } else if (hasSet && !hasUpdate) {
          // Tylko operacje set bez update -> create
          operation = "create";
        }
      }
    }
    
    // Usuń _operationType z danych przed logowaniem (jeśli istnieje)
    let logData = data;
    if (data && typeof data === "object" && "_operationType" in data) {
      const { _operationType, ...rest } = data as { _operationType?: unknown; [key: string]: unknown };
      logData = Object.keys(rest).length > 0 ? rest : undefined;
    }

    const logEntry = {
      timestamp: new Date().toISOString(),
      operation,
      path,
      ...(logData !== undefined && { data: logData }),
    };
    logger.debug("[Firebase Operation]", JSON.stringify(logEntry, null, 2));
  }

  /**
   * Logowanie błędów z operacji Firebase (np. błędy z firestore.rules)
   * @param firebaseOp - Szczegółowa operacja Firebase
   * @param path - Ścieżka do dokumentu/kolekcji
   * @param error - Błąd który wystąpił
   * @param data - Dane operacji (opcjonalne)
   */
  private logFirebaseError(
    firebaseOp: string,
    path: string,
    error: unknown,
    data?: unknown
  ): void {
    // Mapowanie szczegółowych operacji Firebase na podstawowe typy
    const operationMap: Record<string, "get" | "create" | "update" | "delete"> = {
      getDoc: "get",
      getDocs: "get",
      onSnapshot: "get",
      setDoc: "update",
      updateDoc: "update",
      deleteDoc: "delete",
      writeBatch: "update",
      runTransaction: "update",
    };

    let operation: "get" | "create" | "update" | "delete" = operationMap[firebaseOp] || "get";
    
    // Dla writeBatch i runTransaction, sprawdź typ operacji
    if ((firebaseOp === "writeBatch" || firebaseOp === "runTransaction") && data && typeof data === "object") {
      const dataObj = data as { operations?: Array<{ type?: string }>; _operationType?: "get" | "create" | "update" | "delete" };
      if (dataObj._operationType) {
        operation = dataObj._operationType;
      } else if (dataObj.operations && Array.isArray(dataObj.operations)) {
        const hasDelete = dataObj.operations.some(op => op.type === "delete");
        const hasUpdate = dataObj.operations.some(op => op.type === "update");
        const hasSet = dataObj.operations.some(op => op.type === "set");
        
        if (hasDelete) {
          operation = "delete";
        } else if (hasUpdate) {
          operation = "update";
        } else if (hasSet && !hasUpdate) {
          operation = "create";
        }
      }
    }

    const errorMessage = error instanceof Error ? error.message : String(error);
    const errorCode = error instanceof Error && "code" in error ? (error as { code?: string }).code : undefined;
    
    // Sprawdź czy to błąd z reguł Firestore
    const isPermissionError = errorCode === "permission-denied" || 
                              errorMessage.includes("permission") || 
                              errorMessage.includes("Permission denied") ||
                              errorCode === "failed-precondition";

    const logEntry = {
      timestamp: new Date().toISOString(),
      operation,
      path,
      error: true,
      errorType: isPermissionError ? "PERMISSION_DENIED" : "OTHER",
      errorCode,
      errorMessage,
      ...(data !== undefined && { data }),
    };
    
    logger.error("[Firebase Operation ERROR]", JSON.stringify(logEntry, null, 2));
  }

  subscribeToUserProfile(userId: string, onChange: (profile: UserProfile | undefined) => void): () => void {
    const userDocRef = doc(this.db, "users", userId);
    this.logFirebaseOperation("onSnapshot", `users/${userId}`);
    const unsubscribe = onSnapshot(
      userDocRef,
      (snapshot) => {
        const data = snapshot.data() as Record<string, unknown> | undefined;
        if (!data) {
          onChange(undefined);
          return;
        }
        const username = typeof data.username === "string" ? data.username : undefined;
        const displayName =
          typeof data.displayName === "string"
            ? data.displayName
            : username ?? (typeof data.name === "string" ? data.name : undefined);
        const avatarUrl =
          typeof data.avatarUrl === "string"
            ? data.avatarUrl
            : typeof data.photoURL === "string"
            ? data.photoURL
            : undefined;
        onChange({ username, displayName, avatarUrl });
      },
      (error) => {
        this.logFirebaseError("onSnapshot", `users/${userId}`, error);
      }
    );
    return unsubscribe;
  }

  async getThreadUnreadMap(userId: string): Promise<Record<string, number>> {
    const metaRef = doc(this.db, "userChatMeta", userId);
    this.logFirebaseOperation("getDoc", `userChatMeta/${userId}`);
    try {
      const snap = await getDoc(metaRef);
      if (!snap.exists()) {
        return {};
      }
      const data = snap.data() as { threadUnreads?: Record<string, unknown> } | undefined;
      if (!data?.threadUnreads || typeof data.threadUnreads !== "object") {
        return {};
      }
      const result: Record<string, number> = {};
      for (const [threadId, value] of Object.entries(data.threadUnreads)) {
        if (typeof value === "number" && isFinite(value) && value > 0) {
          result[threadId] = value;
        }
      }
      return result;
    } catch (error) {
      this.logFirebaseError("getDoc", `userChatMeta/${userId}`, error);
      throw error;
    }
  }

  async getThreadsForUser(userId: string): Promise<Thread[]> {
    const threadsRef = collection(doc(this.db, "userThreads", userId), "threads");
    this.logFirebaseOperation("getDocs", `userThreads/${userId}/threads`);
    try {
      const snap = await getDocs(threadsRef);
      return snap.docs.map((d) => this.mapUserThreadSnapshot(d));
    } catch (error) {
      this.logFirebaseError("getDocs", `userThreads/${userId}/threads`, error);
      throw error;
    }
  }

  subscribeToThreads(
    userId: string,
    onChange: (threads: Thread[]) => void
  ): () => void {
    const threadsRef = collection(doc(this.db, "userThreads", userId), "threads");
    this.logFirebaseOperation("onSnapshot", `userThreads/${userId}/threads`);
    const unsubscribe = onSnapshot(
      threadsRef,
      (snapshot) => {
        const threads = snapshot.docs.map((doc) => this.mapUserThreadSnapshot(doc));
        onChange(threads);
      },
      (error) => {
        this.logFirebaseError("onSnapshot", `userThreads/${userId}/threads`, error);
      }
    );
    return unsubscribe;
  }

  subscribeToMessages(
    threadId: string,
    onMessage: (message: Message) => void
  ): () => void {
    const messagesRef = this.messagesCollection(threadId);
    const q = query(messagesRef, orderBy("createdAt", "asc"));
    this.logFirebaseOperation("onSnapshot", `messages/${threadId}/items`, { query: "orderBy createdAt asc" });
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type === "added" || change.type === "modified") {
            const message = this.mapMessageSnapshot(change.doc);
            if (message) {
              onMessage(message);
            }
          }
        });
      },
      (error) => {
        this.logFirebaseError("onSnapshot", `messages/${threadId}/items`, error, { query: "orderBy createdAt asc" });
      }
    );
    return unsubscribe;
  }

  async appendThreadAcceptedBy(threadId: string, userId: string): Promise<void> {
    const threadRef = doc(this.db, "threads", threadId);
    const updateData = { acceptedBy: arrayUnion(userId) };
    this.logFirebaseOperation("updateDoc", `threads/${threadId}`, updateData);
    try {
      await updateDoc(threadRef, updateData);
    } catch (error) {
      this.logFirebaseError("updateDoc", `threads/${threadId}`, error, updateData);
      throw error;
    }
  }

  async addMessageAtomic(
    input: {
      threadId: string;
      senderId: string;
      clientMessageId?: string;
      type: MessageType;
      text?: string;
      imageUrl?: string;
      replyTo?: ReplyTo;
      mentions?: string[];
    },
    options?: { threadUpdates?: { directUnlocked?: boolean; acceptedByAdd?: string[] }; unreadFanout?: { recipients: string[]; senderId: string } }
  ): Promise<Message> {
    const payload: Record<string, unknown> = {
      threadId: input.threadId,
      senderId: input.senderId,
      type: input.type,
      likes: [],
      readBy: [input.senderId],
      createdAt: serverTimestamp(),
    };
    if (input.clientMessageId !== undefined) {
      payload.clientMessageId = input.clientMessageId;
    }

    if (input.text !== undefined) {
      payload.text = input.text;
    }
    if (input.imageUrl !== undefined) {
      payload.imageUrl = input.imageUrl;
    }
    if (input.replyTo !== undefined) {
      const replyToPayload: Record<string, unknown> = {
        messageId: input.replyTo.messageId,
        senderId: input.replyTo.senderId,
      };
      if (input.replyTo.text !== undefined) {
        replyToPayload.text = input.replyTo.text;
      }
      if (input.replyTo.imageUrl !== undefined) {
        replyToPayload.imageUrl = input.replyTo.imageUrl;
      }
      payload.replyTo = replyToPayload;
    }
    if (input.mentions !== undefined) {
      payload.mentions = input.mentions;
    }

    const messagesCol = this.messagesCollection(input.threadId);
    const messageRef = input.clientMessageId ? doc(messagesCol, input.clientMessageId) : doc(messagesCol);
    if (input.clientMessageId) {
      this.logFirebaseOperation("getDoc", `messages/${input.threadId}/items/${input.clientMessageId}`);
      try {
        const existing = await getDoc(messageRef);
        if (existing.exists()) {
          const mapped = this.mapMessageSnapshot(existing);
          if (mapped) {
            return mapped;
          }
          this.logFirebaseOperation("getDoc", `messages/${input.threadId}/items/${input.clientMessageId}`);
          try {
            const fresh = await getDoc(messageRef);
            const remapped = this.mapMessageSnapshot(fresh);
            if (remapped) {
              return remapped;
            }
            throw new Error("MESSAGE_PENDING_TIMESTAMP");
          } catch (error) {
            this.logFirebaseError("getDoc", `messages/${input.threadId}/items/${input.clientMessageId}`, error);
            throw error;
          }
        }
      } catch (error) {
        this.logFirebaseError("getDoc", `messages/${input.threadId}/items/${input.clientMessageId}`, error);
        throw error;
      }
    }
    const threadRef = doc(this.db, "threads", input.threadId);
    const lastMessagePayload: Record<string, unknown> = {
      id: messageRef.id,
      senderId: input.senderId,
      clientMessageId: input.clientMessageId,
      createdAt: payload.createdAt,
    };
    if (lastMessagePayload.clientMessageId === undefined) {
      delete lastMessagePayload.clientMessageId;
    }
    if (payload.text !== undefined) {
      lastMessagePayload.text = payload.text;
    }
    if (payload.imageUrl !== undefined) {
      lastMessagePayload.imageUrl = payload.imageUrl;
    }

    const batch = writeBatch(this.db);
    batch.set(messageRef, payload);
    const threadUpdatePayload: Record<string, unknown> = { lastMessage: lastMessagePayload };
    if (options?.threadUpdates?.directUnlocked !== undefined) {
      threadUpdatePayload.directUnlocked = options.threadUpdates.directUnlocked;
    }
    if (options?.threadUpdates?.acceptedByAdd?.length) {
      threadUpdatePayload.acceptedBy = arrayUnion(...options.threadUpdates.acceptedByAdd);
    }
    batch.update(threadRef, threadUpdatePayload);
    // NOTE: Fanout unread count jest teraz obsługiwany przez Cloud Function onMessageCreate
    // Nie zapisujemy do userChatMeta innych użytkowników z klienta
    const batchData = {
      operations: [
        { type: "set", path: `messages/${input.threadId}/items/${messageRef.id}`, data: payload },
        { type: "update", path: `threads/${input.threadId}`, data: threadUpdatePayload },
      ]
    };
    this.logFirebaseOperation("writeBatch", "multiple", batchData);
    try {
      await batch.commit();
    } catch (error) {
      this.logFirebaseError("writeBatch", "multiple", error, batchData);
      throw error;
    }

    this.logFirebaseOperation("getDoc", `messages/${input.threadId}/items/${messageRef.id}`);
    try {
      const snapshot = await getDoc(messageRef);
      const mapped = this.mapMessageSnapshot(snapshot);
      if (!mapped) {
        throw new Error("MESSAGE_PENDING_TIMESTAMP");
      }
      return mapped;
    } catch (error) {
      this.logFirebaseError("getDoc", `messages/${input.threadId}/items/${messageRef.id}`, error);
      throw error;
    }
  }

  async createThreadWithMessageAtomic(input: {
    thread: {
      type: ThreadType;
      members: string[];
      name?: string;
      acceptedBy?: string[];
      directUnlocked?: boolean;
      roles?: Thread["roles"];
      bannedMembers?: string[];
    };
    message: {
      threadId: string;
      senderId: string;
      clientMessageId?: string;
      type: MessageType;
      text?: string;
      imageUrl?: string;
      replyTo?: ReplyTo;
      mentions?: string[];
    };
    unreadFanout?: { recipients: string[]; senderId: string };
  }): Promise<{ thread: Thread; message: Message }> {
    const threadsRef = collection(this.db, "threads");
    const threadRef = doc(threadsRef);
    const createdAt = serverTimestamp();
    const threadPayload: Record<string, unknown> = {
      type: input.thread.type,
      members: input.thread.members,
      createdAt,
      directUnlocked: input.thread.directUnlocked ?? false,
    };
    if (input.thread.name !== undefined) {
      threadPayload.name = input.thread.name;
    }
    if (input.thread.acceptedBy !== undefined) {
      threadPayload.acceptedBy = input.thread.acceptedBy;
    }
    if (input.thread.roles !== undefined) {
      threadPayload.roles = input.thread.roles;
    }
    if (input.thread.bannedMembers !== undefined) {
      threadPayload.bannedMembers = input.thread.bannedMembers;
    }

    const messageRef = input.message.clientMessageId
      ? doc(this.messagesCollection(threadRef.id), input.message.clientMessageId)
      : doc(this.messagesCollection(threadRef.id));
    if (input.message.clientMessageId) {
      this.logFirebaseOperation("getDoc", `messages/${threadRef.id}/items/${input.message.clientMessageId}`);
      try {
        const existing = await getDoc(messageRef);
        if (existing.exists()) {
          this.logFirebaseOperation("getDoc", `threads/${threadRef.id}`);
          this.logFirebaseOperation("getDoc", `messages/${threadRef.id}/items/${input.message.clientMessageId}`);
          try {
            const [threadSnap, messageSnap] = await Promise.all([getDoc(threadRef), getDoc(messageRef)]);
            const mapped = this.mapMessageSnapshot(messageSnap);
            if (!mapped) {
              throw new Error("MESSAGE_PENDING_TIMESTAMP");
            }
            return { thread: this.mapThreadSnapshot(threadSnap), message: mapped };
          } catch (error) {
            this.logFirebaseError("getDoc", `threads/${threadRef.id} or messages/${threadRef.id}/items/${input.message.clientMessageId}`, error);
            throw error;
          }
        }
      } catch (error) {
        this.logFirebaseError("getDoc", `messages/${threadRef.id}/items/${input.message.clientMessageId}`, error);
        throw error;
      }
    }
    const messagePayload: Record<string, unknown> = {
      threadId: threadRef.id,
      senderId: input.message.senderId,
      type: input.message.type,
      likes: [],
      readBy: [input.message.senderId],
      createdAt,
    };
    if (input.message.clientMessageId !== undefined) {
      messagePayload.clientMessageId = input.message.clientMessageId;
    }
    if (input.message.text !== undefined) {
      messagePayload.text = input.message.text;
    }
    if (input.message.imageUrl !== undefined) {
      messagePayload.imageUrl = input.message.imageUrl;
    }
    if (input.message.replyTo !== undefined) {
      messagePayload.replyTo = input.message.replyTo;
    }
    if (input.message.mentions !== undefined) {
      messagePayload.mentions = input.message.mentions;
    }

    const lastMessagePayload: Record<string, unknown> = {
      id: messageRef.id,
      senderId: input.message.senderId,
      createdAt,
    };
    if (input.message.clientMessageId !== undefined) {
      lastMessagePayload.clientMessageId = input.message.clientMessageId;
    }
    if (input.message.text !== undefined) {
      lastMessagePayload.text = input.message.text;
    }
    if (input.message.imageUrl !== undefined) {
      lastMessagePayload.imageUrl = input.message.imageUrl;
    }

    const batch = writeBatch(this.db);
    const threadDataWithLast = { ...threadPayload, lastMessage: lastMessagePayload };
    batch.set(threadRef, threadDataWithLast);
    batch.set(messageRef, messagePayload);
    // NOTE: Fanout unread count jest teraz obsługiwany przez Cloud Function onMessageCreate
    // Nie zapisujemy do userChatMeta innych użytkowników z klienta
    const batchData = {
      _operationType: "create" as const,
      operations: [
        { type: "set", path: `threads/${threadRef.id}`, data: threadDataWithLast },
        { type: "set", path: `messages/${threadRef.id}/items/${messageRef.id}`, data: messagePayload },
      ]
    };
    this.logFirebaseOperation("writeBatch", "multiple", batchData);
    try {
      await batch.commit();
    } catch (error) {
      this.logFirebaseError("writeBatch", "multiple", error, batchData);
      throw error;
    }

    // NOTE: Fanout do userThreads jest teraz obsługiwany przez Cloud Function onThreadCreate
    // Nie robimy tego z klienta, bo firestore.rules mają write: if false dla userThreads

    this.logFirebaseOperation("getDoc", `threads/${threadRef.id}`);
    this.logFirebaseOperation("getDoc", `messages/${threadRef.id}/items/${messageRef.id}`);
    try {
      const [threadSnap, messageSnap] = await Promise.all([getDoc(threadRef), getDoc(messageRef)]);
      const mapped = this.mapMessageSnapshot(messageSnap);
      if (!mapped) {
        throw new Error("MESSAGE_PENDING_TIMESTAMP");
      }
      return { thread: this.mapThreadSnapshot(threadSnap), message: mapped };
    } catch (error) {
      this.logFirebaseError("getDoc", `threads/${threadRef.id} or messages/${threadRef.id}/items/${messageRef.id}`, error);
      throw error;
    }
  }

  async getThread(threadId: string): Promise<Thread | null> {
    const threadRef = doc(this.db, "threads", threadId);
    this.logFirebaseOperation("getDoc", `threads/${threadId}`);
    try {
      const snapshot = await getDoc(threadRef);
      if (!snapshot.exists()) {
        return null;
      }
      return this.mapThreadSnapshot(snapshot);
    } catch (error) {
      this.logFirebaseError("getDoc", `threads/${threadId}`, error);
      throw error;
    }
  }

  async findDirectThreadByMembers(memberA: string, memberB: string): Promise<Thread | null> {
    const threadsRef = collection(this.db, "threads");
    const q = query(threadsRef, where("members", "array-contains", memberA), where("type", "==", "direct"));
    this.logFirebaseOperation("getDocs", "threads", { query: "members array-contains " + memberA + " AND type == direct" });
    try {
      const snap = await getDocs(q);
      const match = snap.docs
        .map((docSnap) => this.mapThreadSnapshot(docSnap))
        .find((thread) => thread.members.includes(memberB));
      return match ?? null;
    } catch (error) {
      this.logFirebaseError("getDocs", "threads", error, { query: "members array-contains " + memberA + " AND type == direct" });
      throw error;
    }
  }

  async getMessage(threadId: string, messageId: string): Promise<Message | null> {
    const messageRef = doc(this.messagesCollection(threadId), messageId);
    this.logFirebaseOperation("getDoc", `messages/${threadId}/items/${messageId}`);
    try {
      const snapshot = await getDoc(messageRef);
      if (!snapshot.exists()) {
        return null;
      }
      return this.mapMessageSnapshot(snapshot);
    } catch (error) {
      this.logFirebaseError("getDoc", `messages/${threadId}/items/${messageId}`, error);
      throw error;
    }
  }

  async listMessages(
    threadId: string,
    options: { limit: number; beforeMessageId?: string }
  ): Promise<Message[]> {
    const messagesRef = this.messagesCollection(threadId);
    const constraints: QueryConstraint[] = [orderBy("createdAt", "desc"), limit(options.limit)];

    if (options.beforeMessageId) {
      const cursorRef = doc(messagesRef, options.beforeMessageId);
      this.logFirebaseOperation("getDoc", `messages/${threadId}/items/${options.beforeMessageId}`);
      const cursorSnap = await getDoc(cursorRef);
      if (cursorSnap.exists()) {
        constraints.push(startAfter(cursorSnap));
      }
    }

    const q = query(messagesRef, ...constraints);
    this.logFirebaseOperation("getDocs", `messages/${threadId}/items`, { query: "paged" });
    try {
      const snap = await getDocs(q);
      const items = snap.docs.map((docSnap) => this.mapMessageSnapshot(docSnap)).filter(Boolean) as Message[];
      return items.reverse(); // zwróć w kolejności rosnącej w paczce
    } catch (error) {
      this.logFirebaseError("getDocs", `messages/${threadId}/items`, error, { query: "paged" });
      throw error;
    }
  }

  async getUnreadCountForUser(threadId: string, userId: string): Promise<number> {
    // 1) Spróbuj odczytać licznik z userChatMeta.threadUnreads
    const metaRef = doc(this.db, "userChatMeta", userId);
    this.logFirebaseOperation("getDoc", `userChatMeta/${userId}`, { threadId });
    try {
      const metaSnap = await getDoc(metaRef);
      const threadUnreads = (metaSnap.data() as { threadUnreads?: Record<string, unknown> } | undefined)?.threadUnreads;
      const fromMap = threadUnreads && typeof threadUnreads === "object" ? threadUnreads[threadId] : undefined;
      if (typeof fromMap === "number" && isFinite(fromMap) && fromMap >= 0) {
        return Math.max(0, fromMap);
      }
    } catch (error) {
      // log i fallback do wolniejszego trybu
      this.logFirebaseError("getDoc", `userChatMeta/${userId}`, error, { threadId });
    }

    // 2) Fallback: policz na podstawie wszystkich wiadomości (droższe)
    const messagesRef = this.messagesCollection(threadId);
    this.logFirebaseOperation("getDocs", `messages/${threadId}/items`);
    try {
      const snap = await getDocs(messagesRef);
      let unread = 0;
      snap.forEach((messageDoc) => {
        const data = messageDoc.data() as Partial<MessageDoc>;
        const senderId = data.senderId;
        const readBy = data.readBy ?? [];
        if (senderId && senderId !== userId && !readBy.includes(userId)) {
          unread += 1;
        }
      });
      return unread;
    } catch (error) {
      this.logFirebaseError("getDocs", `messages/${threadId}/items`, error);
      throw error;
    }
  }

  private mapUserThreadSnapshot(snapshot: DocumentSnapshot): Thread {
    const data = snapshot.data() as Partial<Thread> & {
      lastMessageAt?: Timestamp;
    };
    const createdAt = this.normalizeTimestamp((data as any).createdAt) ?? { seconds: 0, nanoseconds: 0 };
    const lastMessage = data.lastMessage
      ? {
          ...data.lastMessage,
          createdAt: this.normalizeTimestamp((data.lastMessage as any).createdAt) ?? createdAt,
        }
      : undefined;
    return {
      id: snapshot.id,
      type: data.type as Thread["type"],
      members: data.members ?? [],
      createdAt,
      name: typeof data.name === "string" ? data.name : undefined,
      directUnlocked: typeof (data as any).directUnlocked === "boolean" ? (data as any).directUnlocked : undefined,
      acceptedBy: Array.isArray(data.acceptedBy) ? data.acceptedBy : undefined,
      roles: data.roles as Thread["roles"],
      bannedMembers: Array.isArray(data.bannedMembers) ? data.bannedMembers : undefined,
      unreadCount: typeof data.unreadCount === "number" ? data.unreadCount : 0,
      lastMessage,
    };
  }

  async appendMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const messageRef = doc(this.messagesCollection(threadId), messageId);
    const updateData = { likes: arrayUnion(userId) };
    this.logFirebaseOperation("updateDoc", `messages/${threadId}/items/${messageId}`, updateData);
    try {
      await updateDoc(messageRef, updateData);
    } catch (error) {
      this.logFirebaseError("updateDoc", `messages/${threadId}/items/${messageId}`, error, updateData);
      throw error;
    }
  }

  async removeMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const messageRef = doc(this.messagesCollection(threadId), messageId);
    const updateData = { likes: arrayRemove(userId) };
    this.logFirebaseOperation("updateDoc", `messages/${threadId}/items/${messageId}`, updateData);
    try {
      await updateDoc(messageRef, updateData);
    } catch (error) {
      this.logFirebaseError("updateDoc", `messages/${threadId}/items/${messageId}`, error, updateData);
      throw error;
    }
  }

  async appendMessageReadBy(threadId: string, messageId: string, userId: string): Promise<void> {
    const messageRef = doc(this.messagesCollection(threadId), messageId);
    
    // Sprawdź czy wiadomość została właśnie utworzona (race condition protection)
    // Jeśli wiadomość ma createdAt < 3 sekundy temu, nie zmniejszaj licznika
    // bo CF onMessageCreate może jeszcze nie zwiększyć licznika
    this.logFirebaseOperation("getDoc", `messages/${threadId}/items/${messageId}`);
    let shouldDecrement = true;
    try {
      const messageSnap = await getDoc(messageRef);
      if (messageSnap.exists()) {
        const messageData = messageSnap.data() as MessageDoc;

        // KRYTYCZNE: Sprawdź czy użytkownik już oznaczył wiadomość jako przeczytaną
        // To zapobiega podwójnym dekrementom gdy useEffect uruchamia się wielokrotnie
        if (messageData.readBy?.includes(userId)) {
          logger.debug(`[appendMessageReadBy] User ${userId} already read message ${messageId}, skipping`);
          return; // Już przeczytane - nie rób nic
        }

        const createdAt = messageData.createdAt;
        if (createdAt && typeof createdAt.seconds === "number") {
          const messageTimeMs = createdAt.seconds * 1000 + (createdAt.nanoseconds || 0) / 1000000;
          const nowMs = Date.now();
          const ageMs = nowMs - messageTimeMs;
          // Jeśli wiadomość ma < 3 sekundy, nie zmniejszaj licznika (CF może jeszcze nie zwiększyć)
          if (ageMs < 3000) {
            shouldDecrement = false;
            logger.debug(`[appendMessageReadBy] Message ${messageId} is too fresh (${ageMs}ms old), skipping decrement to avoid race condition`);
          }
        }
      }
    } catch (error) {
      this.logFirebaseError("getDoc", `messages/${threadId}/items/${messageId}`, error);
      // W przypadku błędu, kontynuuj normalnie (bezpieczniej)
    }
    
    const batch = writeBatch(this.db);
    batch.update(messageRef, {
      readBy: arrayUnion(userId),
    });
    
    const metaRef = doc(this.db, "userChatMeta", userId);
    
    // Zmniejsz licznik tylko jeśli wiadomość nie jest świeża (race condition protection)
    if (shouldDecrement) {
      batch.set(
        metaRef,
        {
          totalUnreadCount: increment(-1),
          [`threadUnreads.${threadId}`]: increment(-1),
        },
        { merge: true }
      );
    }
    
    const batchData = {
      operations: [
        { type: "update", path: `messages/${threadId}/items/${messageId}`, data: { readBy: "arrayUnion(" + userId + ")" } },
        ...(shouldDecrement ? [{ type: "set", path: `userChatMeta/${userId}`, data: { totalUnreadCount: "increment(-1)" } }] : [])
      ]
    };
    this.logFirebaseOperation("writeBatch", "multiple", batchData);
    try {
      await batch.commit();
    } catch (error) {
      this.logFirebaseError("writeBatch", "multiple", error, batchData);
      throw error;
    }
    
    // Jeśli nie zmniejszyliśmy licznika (wiadomość świeża), sprawdź czy CF już zwiększył
    // i jeśli tak, zmniejsz teraz
    if (!shouldDecrement) {
      // Poczekaj chwilę i sprawdź czy CF już zwiększył licznik
      // Jeśli tak, zmniejsz go teraz
      setTimeout(async () => {
        try {
          // Użyj transakcji, żeby po dekrementacji poprawnie ustawić notificationGate=OPEN
          // gdy licznik dojdzie do zera (to naprawia przypadek: odczytano -> gate zostaje CLOSED).
          await runTransaction(this.db, async (txn: Transaction) => {
            const snap = await txn.get(metaRef);
            const data = snap.data() as { totalUnreadCount?: number; notificationGate?: string } | undefined;
            const currentCount = data?.totalUnreadCount ?? 0;
            if (currentCount <= 0) {
              return;
            }
            const next = Math.max(0, currentCount - 1);
            const patch: Record<string, unknown> = { totalUnreadCount: next };
            if (next <= 0) {
              patch.notificationGate = "OPEN";
            }
            txn.set(metaRef, patch, { merge: true });
          });
          logger.debug(
            `[appendMessageReadBy] Decremented unread after race condition delay (and opened gate if needed) for message ${messageId}`
          );
        } catch (error) {
          // Ignoruj błędy w setTimeout
        }
      }, 3500); // Poczekaj 3.5 sekundy (CF powinien już zwiększyć)
    }
    
    // Sprawdź czy licznik nie spadł poniżej 0 (tylko jeśli zmniejszyliśmy)
    if (shouldDecrement) {
      this.logFirebaseOperation("getDoc", `userChatMeta/${userId}`);
      try {
        const snap = await getDoc(metaRef);
        const data = snap.data() as { totalUnreadCount?: number } | undefined;
        const next = data?.totalUnreadCount ?? 0;
        if (next <= 0) {
          const setData = { totalUnreadCount: 0, notificationGate: "OPEN" };
          this.logFirebaseOperation("setDoc", `userChatMeta/${userId}`, setData);
          try {
            await setDoc(metaRef, setData, { merge: true });
          } catch (error) {
            this.logFirebaseError("setDoc", `userChatMeta/${userId}`, error, setData);
            throw error;
          }
        }
      } catch (error) {
        this.logFirebaseError("getDoc", `userChatMeta/${userId}`, error);
        throw error;
      }
    }
  }

  private messagesCollection(threadId: string): CollectionReference {
    // Firestore path (collection): messages/{threadId}/items
    return collection(doc(this.db, "messages", threadId), "items");
  }

  private mapMessageSnapshot(snapshot: DocumentSnapshot): Message | null {
    const data = snapshot.data() as MessageDoc;
    const createdAt = this.normalizeTimestamp(data.createdAt);
    if (!createdAt) {
      return null;
    }
    return {
      id: snapshot.id,
      threadId: data.threadId,
      senderId: data.senderId,
      clientMessageId: data.clientMessageId,
      type: data.type,
      text: data.text,
      imageUrl: data.imageUrl,
      replyTo: data.replyTo,
      likes: data.likes ?? [],
      readBy: data.readBy ?? [],
      mentions: Array.isArray(data.mentions) ? data.mentions : undefined,
      createdAt,
    };
  }

  private mapThreadSnapshot(snapshot: DocumentSnapshot): Thread {
    const data = snapshot.data() as Thread & {
      name?: string;
      directUnlocked?: boolean;
      acceptedBy?: string[];
      unreadCount?: number;
      roles?: Thread["roles"];
      bannedMembers?: string[];
    };
    const createdAt = this.normalizeTimestamp((data as any).createdAt) ?? { seconds: 0, nanoseconds: 0 };
    return {
      id: snapshot.id,
      type: data.type,
      members: data.members,
      createdAt,
      name: typeof data.name === "string" ? data.name : undefined,
      directUnlocked: typeof data.directUnlocked === "boolean" ? data.directUnlocked : undefined,
      acceptedBy: Array.isArray(data.acceptedBy) ? data.acceptedBy : undefined,
      roles: data.roles,
      bannedMembers: Array.isArray(data.bannedMembers) ? data.bannedMembers : undefined,
      // unreadCount is per-user; default to 0, ChatClient will enrich
      unreadCount: typeof data.unreadCount === "number" ? data.unreadCount : 0,
      lastMessage: data.lastMessage
        ? {
            ...data.lastMessage,
            createdAt: this.normalizeTimestamp((data.lastMessage as any).createdAt) ?? { seconds: 0, nanoseconds: 0 },
          }
        : undefined,
    };
  }

  async setTyping(threadId: string, userId: string, isTyping: boolean): Promise<void> {
    const typingRef = doc(this.db, "threads", threadId, "typing", userId);
    if (isTyping) {
      const data = { updatedAt: serverTimestamp() };
      this.logFirebaseOperation("setDoc", `threads/${threadId}/typing/${userId}`, data);
      try {
        await setDoc(typingRef, data, { merge: true });
      } catch (error) {
        this.logFirebaseError("setDoc", `threads/${threadId}/typing/${userId}`, error, data);
        throw error;
      }
    } else {
      this.logFirebaseOperation("deleteDoc", `threads/${threadId}/typing/${userId}`);
      try {
        await deleteDoc(typingRef);
      } catch (error) {
        this.logFirebaseError("deleteDoc", `threads/${threadId}/typing/${userId}`, error);
        throw error;
      }
    }
  }

  subscribeToTyping(threadId: string, onChange: (userIds: string[]) => void): () => void {
    const typingCol = collection(this.db, "threads", threadId, "typing");
    this.logFirebaseOperation("onSnapshot", `threads/${threadId}/typing`);
    return onSnapshot(
      typingCol,
      (snapshot) => {
        const userIds = snapshot.docs.map((docSnap) => docSnap.id);
        onChange(userIds);
      },
      (error) => {
        this.logFirebaseError("onSnapshot", `threads/${threadId}/typing`, error);
      }
    );
  }

  subscribeToTotalUnread(userId: string, onChange: (count: number) => void): () => void {
    const metaRef = doc(this.db, "userChatMeta", userId);
    this.logFirebaseOperation("onSnapshot", `userChatMeta/${userId}`);
    return onSnapshot(
      metaRef,
      (snap) => {
        const data = snap.data() as { totalUnreadCount?: number } | undefined;
        onChange(data?.totalUnreadCount ?? 0);
      },
      (error) => {
        this.logFirebaseError("onSnapshot", `userChatMeta/${userId}`, error);
      }
    );
  }

  async decrementTotalUnread(userId: string, count: number, threadId?: string): Promise<void> {
    if (count <= 0) {
      return;
    }
    const metaRef = doc(this.db, "userChatMeta", userId);
    const setData: Record<string, unknown> = { totalUnreadCount: increment(-count) };
    if (threadId) {
      setData[`threadUnreads.${threadId}`] = increment(-count);
    }
    this.logFirebaseOperation("setDoc", `userChatMeta/${userId}`, setData);
    try {
      await setDoc(metaRef, setData, { merge: true });
    } catch (error) {
      this.logFirebaseError("setDoc", `userChatMeta/${userId}`, error, setData);
      throw error;
    }
    this.logFirebaseOperation("getDoc", `userChatMeta/${userId}`);
    try {
      const snap = await getDoc(metaRef);
      const data = snap.data() as { totalUnreadCount?: number } | undefined;
      const next = data?.totalUnreadCount ?? 0;
      if (next <= 0) {
        const finalData: Record<string, unknown> = { totalUnreadCount: 0, notificationGate: "OPEN" };
        if (threadId) {
          finalData[`threadUnreads.${threadId}`] = deleteField();
        }
        this.logFirebaseOperation("setDoc", `userChatMeta/${userId}`, finalData);
        try {
          await setDoc(metaRef, finalData, { merge: true });
        } catch (error) {
          this.logFirebaseError("setDoc", `userChatMeta/${userId}`, error, finalData);
          throw error;
        }
      }
    } catch (error) {
      this.logFirebaseError("getDoc", `userChatMeta/${userId}`, error);
      throw error;
    }
  }

  async updateUserBlockList(userId: string, targetUserId: string, block: boolean): Promise<void> {
    const docRef = doc(this.db, "userBlocks", userId);
    if (block) {
      const data = { blockedUserIds: arrayUnion(targetUserId) };
      this.logFirebaseOperation("setDoc", `userBlocks/${userId}`, data);
      try {
        await setDoc(docRef, data, { merge: true });
      } catch (error) {
        this.logFirebaseError("setDoc", `userBlocks/${userId}`, error, data);
        throw error;
      }
    } else {
      const data = { blockedUserIds: arrayRemove(targetUserId) };
      this.logFirebaseOperation("setDoc", `userBlocks/${userId}`, data);
      try {
        await setDoc(docRef, data, { merge: true });
      } catch (error) {
        this.logFirebaseError("setDoc", `userBlocks/${userId}`, error, data);
        throw error;
      }
    }
  }

  async isUserBlocked(blockingUserId: string, blockedUserId: string): Promise<boolean> {
    // Sprawdzamy czy blockingUserId zablokował blockedUserId
    // 
    // Strategia:
    // 1. Jeśli blockingUserId == currentUserId (sprawdzamy własne blokady):
    //    - Używamy userBlocks/{blockingUserId} - użytkownik może odczytać swoje własne blokady
    // 
    // 2. Jeśli blockedUserId == currentUserId (sprawdzamy czy ktoś nas zablokował):
    //    - Używamy userBlockedBy/{blockedUserId} - użytkownik może odczytać kto go zablokował
    //    - Sprawdzamy czy blockingUserId jest w blockedByUserIds
    // 
    // 3. W przeciwnym razie (sprawdzamy cudze blokady) - nie mamy dostępu
    //    - Próbujemy userBlocks/{blockingUserId}, jeśli permission denied -> false
    
    // Najpierw próbujemy userBlocks (dla własnych blokad)
    const blocksRef = doc(this.db, "userBlocks", blockingUserId);
    this.logFirebaseOperation("getDoc", `userBlocks/${blockingUserId}`);
    try {
      const snap = await getDoc(blocksRef);
      const data = snap.data() as { blockedUserIds?: string[] } | undefined;
      return (data?.blockedUserIds ?? []).includes(blockedUserId);
    } catch (error) {
      // Jeśli permission denied, może to być przypadek gdy blockedUserId == currentUserId
      // Wtedy próbujemy userBlockedBy
      const isPermissionError = (err: unknown): boolean => {
        if (err instanceof Error) {
          // Check for Firebase error code
          if ((err as any).code === 'permission-denied') return true;
          // Check for error message patterns
          if (err.message.includes("permission")) return true;
          if (err.message.includes("false for")) return true; // Firestore emulator format
        }
        return false;
      };

      if (isPermissionError(error)) {
        const blockedByRef = doc(this.db, "userBlockedBy", blockedUserId);
        this.logFirebaseOperation("getDoc", `userBlockedBy/${blockedUserId}`);
        try {
          const snap = await getDoc(blockedByRef);
          const data = snap.data() as { blockedByUserIds?: string[] } | undefined;
          return (data?.blockedByUserIds ?? []).includes(blockingUserId);
        } catch (error2) {
          this.logFirebaseError("getDoc", `userBlockedBy/${blockedUserId}`, error2);
          // Jeśli też permission denied, zwracamy false (nie mamy dostępu)
          if (isPermissionError(error2)) {
            return false;
          }
          throw error2;
        }
      }
      this.logFirebaseError("getDoc", `userBlocks/${blockingUserId}`, error);
      throw error;
    }
  }

  async updateCommunityBan(threadId: string, userId: string, banned: boolean): Promise<void> {
    const threadRef = doc(this.db, "threads", threadId);
    if (banned) {
      const updateData = { bannedMembers: arrayUnion(userId) };
      this.logFirebaseOperation("updateDoc", `threads/${threadId}`, updateData);
      try {
        await updateDoc(threadRef, updateData);
      } catch (error) {
        this.logFirebaseError("updateDoc", `threads/${threadId}`, error, updateData);
        throw error;
      }
    } else {
      const updateData = { bannedMembers: arrayRemove(userId) };
      this.logFirebaseOperation("updateDoc", `threads/${threadId}`, updateData);
      try {
        await updateDoc(threadRef, updateData);
      } catch (error) {
        this.logFirebaseError("updateDoc", `threads/${threadId}`, error, updateData);
        throw error;
      }
    }
  }

  async updateThreadMembership(input: {
    threadId: string;
    members: string[];
    acceptedBy?: string[];
    roles?: Record<string, string> | undefined;
    bannedMembers?: string[];
  }): Promise<void> {
    const { threadId, members, acceptedBy, roles, bannedMembers } = input;
    const threadRef = doc(this.db, "threads", threadId);
    let previousMembers: string[] = [];
    let threadSnapshotData: Record<string, unknown> | null = null;
    try {
      const prevSnap = await getDoc(threadRef);
      if (prevSnap.exists()) {
        const prevData = prevSnap.data() as Record<string, unknown>;
        previousMembers = Array.isArray(prevData.members) ? (prevData.members as string[]) : [];
        threadSnapshotData = prevData;
      }
    } catch (error) {
      this.logFirebaseError("getDoc", `threads/${threadId}`, error);
    }

    const payload: Record<string, unknown> = {
      members,
    };
    if (acceptedBy !== undefined) {
      payload.acceptedBy = acceptedBy;
    }
    if (roles !== undefined) {
      payload.roles = roles;
    }
    if (bannedMembers !== undefined) {
      payload.bannedMembers = bannedMembers;
    }
    this.logFirebaseOperation("updateDoc", `threads/${threadId}`, payload);
    try {
      await updateDoc(threadRef, payload);
    } catch (error) {
      this.logFirebaseError("updateDoc", `threads/${threadId}`, error, payload);
      throw error;
    }

    // fanout userThreads przeniesiony do Cloud Functions (bezpieczniejsze)
  }

  async getThreadUserPrefs(
    threadId: string,
    userId: string
  ): Promise<{ threadId: string; userId: string; muted: boolean; mutedAt?: Timestamp }> {
    const prefRef = doc(this.db, "threadUserPrefs", `${threadId}_${userId}`);
    this.logFirebaseOperation("getDoc", `threadUserPrefs/${threadId}_${userId}`);
    try {
      const snap = await getDoc(prefRef);
      if (!snap.exists()) {
        return { threadId, userId, muted: false };
      }
      const data = snap.data() as { muted?: boolean; mutedAt?: Timestamp };
      const mutedAt = this.normalizeTimestamp((data as any).mutedAt);
      return {
        threadId,
        userId,
        muted: Boolean(data?.muted),
        mutedAt: mutedAt ?? undefined,
      };
    } catch (error) {
      this.logFirebaseError("getDoc", `threadUserPrefs/${threadId}_${userId}`, error);
      throw error;
    }
  }

  async setThreadMuted(threadId: string, userId: string, muted: boolean): Promise<void> {
    const prefRef = doc(this.db, "threadUserPrefs", `${threadId}_${userId}`);
    const payload: Record<string, unknown> = {
      threadId,
      userId,
      muted,
      mutedAt: muted ? serverTimestamp() : deleteField(),
    };
    this.logFirebaseOperation("setDoc", `threadUserPrefs/${threadId}_${userId}`, payload);
    try {
      await setDoc(prefRef, payload, { merge: true });
    } catch (error) {
      this.logFirebaseError("setDoc", `threadUserPrefs/${threadId}_${userId}`, error, payload);
      throw error;
    }
  }

  async resolveUsernamesToIds(usernames: string[]): Promise<Map<string, string>> {
    const result = new Map<string, string>();
    for (const username of usernames) {
      const normalized = username.toLowerCase();
      if (result.has(username)) continue;
      const usersCol = collection(this.db, "users");
      const q = query(usersCol, where("usernameLower", "==", normalized));
      this.logFirebaseOperation("getDocs", "users", { query: "usernameLower == " + normalized });
      try {
        const snap = await getDocs(q);
        const matched = snap.docs[0];
        if (matched) {
          result.set(username, matched.id);
          continue;
        }
      } catch (error) {
        this.logFirebaseError("getDocs", "users", error, { query: "usernameLower == " + normalized });
        // Nie rzucamy błędu, tylko próbujemy fallback
      }
      // Fallback: try docId match for backward compatibility
      const exactRef = doc(this.db, "users", username);
      this.logFirebaseOperation("getDoc", `users/${username}`);
      try {
        const exactSnap = await getDoc(exactRef);
        if (exactSnap.exists()) {
          result.set(username, exactSnap.id);
        }
      } catch (error) {
        this.logFirebaseError("getDoc", `users/${username}`, error);
        // Nie rzucamy błędu, tylko pomijamy tego użytkownika
      }
    }
    return result;
  }
  private normalizeTimestamp(value: any): Timestamp | null {
    if (value && typeof value.seconds === "number" && typeof value.nanoseconds === "number") {
      return { seconds: value.seconds, nanoseconds: value.nanoseconds };
    }
    return null;
  }

  async consumeRateLimit(input: RateLimitConsumeInput): Promise<RateLimitConsumeResult> {
    // NOTE: Rate limiting jest teraz wymuszany przez Cloud Function onMessageCreate
    // Klient tylko sprawdza istniejący stan (read-only) dla UX feedback
    // Jeśli użytkownik jest zawieszony, pokazujemy mu to
    const ref = doc(this.db, "userRateLimits", input.userId);
    const nowMs = input.nowMs;

    this.logFirebaseOperation("getDoc", `userRateLimits/${input.userId}`);
    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        return { allowed: true };
      }
      
      const data = snap.data() as RateLimitDoc;
      
      // Sprawdź czy użytkownik jest zawieszony
      const stateKey = input.threadType === "direct" ? "sendDirect" : "sendGroupOrCommunity";
      const state = data[stateKey];
      
      if (state?.suspendedUntilMs && nowMs < state.suspendedUntilMs) {
  return {
          allowed: false, 
          code: "TEMP_CHAT_SUSPENDED", 
          suspendedUntilMs: state.suspendedUntilMs 
        };
}

      // Dla innych limitów - pozwól (CF będzie wymuszać)
      return { allowed: true };
    } catch (error) {
      this.logFirebaseError("getDoc", `userRateLimits/${input.userId}`, error);
      // W przypadku błędu - pozwól (CF będzie wymuszać)
      return { allowed: true };
  }
  }
}

// NOTE: Funkcje rate limitingu zostały przeniesione do Cloud Functions
// Klient tylko sprawdza istniejący stan (suspendedUntilMs) dla UX feedback

