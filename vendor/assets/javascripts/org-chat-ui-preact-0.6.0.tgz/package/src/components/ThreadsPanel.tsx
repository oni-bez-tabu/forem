import { useEffect, useMemo } from "preact/hooks";
import type { JSX } from "preact";
import type { Thread } from "@org/chat-core";
import { useChat, useChatContext } from "@org/chat-ui-shared";
import { useChatStyles } from "../hooks/useChatStyles";

const decodeTextarea = typeof document !== "undefined" ? document.createElement("textarea") : null;
function decodeEntities(text: string): string {
  if (!text || !decodeTextarea) return text;
  let current = text;
  for (let i = 0; i < 3; i += 1) {
    decodeTextarea.innerHTML = current;
    const next = decodeTextarea.value;
    if (next === current) break;
    current = next;
  }
  return current;
}

export interface ThreadsListProps {
  currentUserId: string;
  onSelectThread: (threadId: string) => void;
  selectedThreadId?: string | null;
  onNewThread?: () => void;
  extraThreads?: Thread[];
  /** Optional footer content (e.g. promotional banner, code of conduct reminder) */
  footerSlot?: JSX.Element | null;
}

function formatLastMessagePreview(thread: Thread): string {
  const lastMessage = thread.lastMessage;
  if (!lastMessage) {
    return "Brak wiadomości";
  }
  if (lastMessage.text) {
    return decodeEntities(lastMessage.text);
  }
  if (lastMessage.imageUrl) {
    return "Obraz";
  }
  return "Nowa wiadomość";
}

function formatTime(thread: Thread): string {
  const ts = thread.lastMessage?.createdAt?.seconds ?? null;
  if (!ts) return "";
  return new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function sortThreads(threads: Thread[]): Thread[] {
  return [...threads].sort((a, b) => {
    const aTime = a.lastMessage?.createdAt ?? a.createdAt;
    const bTime = b.lastMessage?.createdAt ?? b.createdAt;

    if (aTime.seconds === bTime.seconds) {
      if (aTime.nanoseconds === bTime.nanoseconds) {
        return a.id.localeCompare(b.id);
      }
      return bTime.nanoseconds - aTime.nanoseconds;
    }
    return bTime.seconds - aTime.seconds;
  });
}

function formatDateLabel(thread: Thread): string {
  const ts = thread.lastMessage?.createdAt;
  if (!ts) return "";
  const date = new Date(ts.seconds * 1000 + Math.floor((ts.nanoseconds ?? 0) / 1_000_000));
  const now = new Date();

  const isSameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getFullYear() === yesterday.getFullYear() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getDate() === yesterday.getDate();

  const timePart = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  if (isSameDay) return timePart;
  if (isYesterday) return `Wczoraj, ${timePart}`;

  const datePart = date.toLocaleDateString([], {
    day: "2-digit",
    month: "short",
    year: date.getFullYear() === now.getFullYear() ? undefined : "numeric",
  });
  return `${datePart}, ${timePart}`;
}

function getInitials(text: string): string {
  const parts = text.split(/\s+/).filter(Boolean);
  if (parts.length === 0) return text.slice(0, 2).toUpperCase();
  return parts
    .map((p) => p[0] ?? "")
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function ThreadsList({ currentUserId, onSelectThread, selectedThreadId, onNewThread, extraThreads = [], footerSlot }: ThreadsListProps): JSX.Element {
  useChatStyles();
  const { threads, loading } = useChat();
  const { ensureProfileSubscription, getProfile } = useChatContext();
  const mergedThreads = useMemo(() => {
    const map = new Map<string, Thread>();
    [...threads, ...extraThreads].forEach((t) => {
      map.set(t.id, t);
    });
    return Array.from(map.values());
  }, [threads, extraThreads]);
  const sortedThreads = useMemo(() => sortThreads(mergedThreads), [mergedThreads]);

  const displayNameFor = (userId: string): string => {
    const profile = getProfile(userId);
    if (profile) {
      return profile.displayName ?? profile.username ?? userId;
    }
    // Jeśli profil nie jest jeszcze załadowany, zwróć placeholder zamiast ID
    return "Ładowanie...";
  };

  const formatThreadTitle = (thread: Thread): string => {
    if (thread.name && thread.name.trim().length > 0) {
      return thread.name;
    }
    const otherMembers = thread.members.filter((member) => member !== currentUserId);
    const names = otherMembers.length > 0 ? otherMembers : thread.members;
    return names.map(displayNameFor).join(", ");
  };

  useEffect(() => {
    const unique = new Set<string>();
    mergedThreads.forEach((thread) => {
      thread.members.forEach((m) => {
        if (m !== currentUserId) {
          unique.add(m);
        }
      });
    });
    unique.forEach((id) => ensureProfileSubscription(id));
  }, [mergedThreads, currentUserId, ensureProfileSubscription]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between border-b border-light-border px-3 py-3 dark:border-dark-border">
        <h3 className="text-lg font-bold">Wiadomości</h3>
        <div className="flex items-center gap-2">
          {loading ? (
            <span className="text-sm leading-none text-light-text-tertiary dark:text-dark-text-tertiary">Ładowanie...</span>
          ) : null}
          {onNewThread ? (
            <button
              type="button"
              onClick={onNewThread}
              className="rounded-full bg-light-bg-tertiary p-2 text-light-text-secondary transition-colors hover:bg-light-border dark:bg-dark-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-border"
              aria-label="Nowa wiadomość"
            >
              <i className="fa-solid fa-pen-to-square" />
            </button>
          ) : null}
        </div>
      </div>

      {sortedThreads.length === 0 && !loading ? (
        <div className="p-4 text-sm text-light-text-secondary dark:text-dark-text-secondary">Brak dostępnych wątków.</div>
      ) : null}

      <div className="flex-1 overflow-y-auto flex flex-col">
        {sortedThreads.map((thread) => {
          const isSelected = selectedThreadId === thread.id;
          const title = formatThreadTitle(thread);
          const initials = getInitials(title);
          const primaryMember = thread.members.find((m) => m !== currentUserId) ?? thread.members[0];
          const primaryProfile = primaryMember ? getProfile(primaryMember) : undefined;
          const avatarUrl = (thread as Partial<Thread> & { avatarUrl?: string }).avatarUrl ?? primaryProfile?.avatarUrl;
          // Jeśli profil nie jest jeszcze załadowany, nie wyświetlaj placeholder zdjęcia
          const showAvatar = avatarUrl || primaryProfile;
          const hasUnread = typeof thread.unreadCount === "number" && thread.unreadCount > 0;
          const isGroup = thread.type === "group" || thread.type === "community";
          return (
            <button
              key={thread.id}
              type="button"
              onClick={() => onSelectThread(thread.id)}
              aria-pressed={isSelected}
              className={`flex w-full items-center px-4 py-3 transition-colors cursor-pointer ${
                isSelected
                  ? "bg-light-primary/10 dark:bg-dark-primary/20"
                  : "hover:bg-light-bg-tertiary dark:hover:bg-dark-bg-tertiary"
              }`}
            >
              <div className="relative mr-3 shrink-0">
                {showAvatar && avatarUrl ? (
                  <img src={avatarUrl} alt={title} className="h-12 w-12 rounded-full object-cover" />
                ) : showAvatar ? (
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-sky-500 text-white font-semibold">
                    {initials}
                  </div>
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-light-bg-tertiary dark:bg-dark-bg-tertiary">
                    <i className="fa-solid fa-spinner fa-spin text-light-text-tertiary dark:text-dark-text-tertiary" />
                  </div>
                )}
                {isGroup ? (
                  <span className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-light-bg dark:bg-dark-bg">
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-light-primary text-[10px] text-white dark:bg-dark-primary">
                      <i className="fa-solid fa-users" />
                    </span>
                  </span>
                ) : null}
              </div>
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex items-center justify-between">
                  <p className="truncate text-sm font-semibold text-light-text-primary dark:text-dark-text-primary">{title}</p>
                  <span className="ml-2 shrink-0 text-xs text-light-text-tertiary dark:text-dark-text-tertiary">{formatDateLabel(thread)}</span>
                </div>
                <div className="flex items-start gap-2">
                  <p
                    className={`truncate text-xs ${
                      hasUnread
                        ? "font-semibold text-light-primary dark:text-dark-primary"
                        : "text-light-text-secondary dark:text-dark-text-secondary"
                    }`}
                  >
                    {formatLastMessagePreview(thread)}
                  </p>
                  {typeof thread.unreadCount === "number" && thread.unreadCount > 0 ? (
                    <span className="ml-auto shrink-0 rounded-full bg-light-primary px-2 py-0.5 text-[11px] font-bold text-white dark:bg-dark-primary">
                      {thread.unreadCount}
                    </span>
                  ) : null}
                </div>
              </div>
            </button>
          );
        })}
        {!loading && footerSlot}
      </div>
    </div>
  );
}

