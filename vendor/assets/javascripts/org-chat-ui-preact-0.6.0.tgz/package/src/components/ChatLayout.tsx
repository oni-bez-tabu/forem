import type { JSX } from "preact";
import { useCallback, useEffect, useMemo, useRef, useState } from "preact/hooks";
import type { ChatClient, Thread } from "@org/chat-core";
import { useChat, useChatContext } from "@org/chat-ui-shared";
import { ThreadsList } from "./ThreadsPanel";
import { ThreadView } from "./ThreadScreen";
import { NewThreadModal } from "./NewThreadModal";
import { usePageVisibility } from "../hooks/usePageVisibility";
import { useChatStyles } from "../hooks/useChatStyles";

export interface ChatLayoutProps {
  /** Current user ID */
  currentUserId: string;
  /** Chat client instance */
  client: ChatClient;
  /** API base URL for user search in NewThreadModal */
  apiBaseUrl: string;
  /** Optional footer slot for threads panel (e.g. promotional banner) */
  footerSlot?: JSX.Element | null;
  /** Controlled mode: selected thread ID */
  selectedThreadId?: string | null;
  /** Controlled mode: callback when thread selection changes */
  onThreadSelect?: (threadId: string | null, thread: Thread | null) => void;
  /** Callback when a new thread is created */
  onThreadCreated?: (thread: Thread) => void;
  /** Optional: preselected member username for new thread modal (opens modal automatically) */
  preselectedMember?: string | null;
  /** Callback when user closes the new thread modal (e.g. to clear parent preselectedMember) */
  onNewThreadModalClose?: () => void;
  /** Callback when user wants to navigate back from thread view (mobile) */
  onBack?: () => void;
}

interface ChatLayoutInnerProps extends Omit<ChatLayoutProps, "selectedThreadId" | "onThreadSelect"> {
  selectedThreadId: string | null;
  onSelectThread: (threadId: string | null) => void;
}

function ChatLayoutInner({
  currentUserId,
  client,
  apiBaseUrl,
  footerSlot,
  selectedThreadId,
  onSelectThread,
  onThreadCreated,
  preselectedMember: externalPreselectedMember,
  onNewThreadModalClose,
  onBack,
}: ChatLayoutInnerProps): JSX.Element {
  useChatStyles();

  const { threads, loading: threadsLoading, refreshThreads } = useChat();
  const { getProfile } = useChatContext();
  const isVisible = usePageVisibility();

  const [showNewThread, setShowNewThread] = useState(false);
  const [preselectedMember, setPreselectedMember] = useState<string | null>(externalPreselectedMember ?? null);
  const [optimisticThreads, setOptimisticThreads] = useState<Thread[]>([]);

  // Handle external preselectedMember changes
  useEffect(() => {
    if (externalPreselectedMember) {
      setPreselectedMember(externalPreselectedMember);
      setShowNewThread(true);
    }
  }, [externalPreselectedMember]);

  const mergedThreads = useMemo(() => {
    const map = new Map<string, Thread>();
    [...threads, ...optimisticThreads].forEach((t) => map.set(t.id, t));
    return Array.from(map.values());
  }, [threads, optimisticThreads]);

  const activeThread = useMemo(() => {
    if (!selectedThreadId) return null;
    return mergedThreads.find((thread) => thread.id === selectedThreadId) ?? null;
  }, [mergedThreads, selectedThreadId]);

  // Remove optimistic threads when real ones arrive
  useEffect(() => {
    const timer = setTimeout(() => {
      setOptimisticThreads((prev) =>
        prev.filter((opt) => !threads.some((t) => t.id === opt.id))
      );
    }, 300);
    return () => clearTimeout(timer);
  }, [threads]);

  const handleCreateThread = useCallback(async (input: {
    type: Thread["type"];
    members: string[];
    name?: string;
    message: { text: string };
  }) => {
    const result = await client.sendMessage({
      threadType: input.type,
      members: input.members,
      name: input.name,
      message: input.message,
    });

    const directResult = result && typeof result === "object" && "id" in result ? (result as Thread) : null;

    // `sendMessage` może zwrócić `void` nawet jeśli utworzył nowy wątek (szczególnie przy pierwszym wątku).
    // Wtedy dociągnij wątki i spróbuj znaleźć nowoutworzony.
    const membersMatch = (t: Thread) =>
      t.members.length === input.members.length && input.members.every((m) => t.members.includes(m));
    const candidateScore = (t: Thread) => (t.createdAt?.seconds ?? 0) * 1_000_000_000 + (t.createdAt?.nanoseconds ?? 0);

    const findCreatedThread = (list: Thread[]): Thread | null => {
      const candidates = list.filter((t) => t.type === input.type && membersMatch(t));
      if (candidates.length === 0) return null;

      // Jeśli mamy name (group/community) - to najlepszy identyfikator.
      if (input.name) {
        const byName = candidates.find((t) => t.name === input.name);
        if (byName) return byName;
      }

      // Heurystyka: wybierz najnowszy wątek z pasującymi członkami (i opcjonalnie ostatnią wiadomością).
      const withMatchingLastMessage = candidates.filter((t) => t.lastMessage?.text === input.message.text);
      const pool = withMatchingLastMessage.length > 0 ? withMatchingLastMessage : candidates;
      return pool.sort((a, b) => candidateScore(b) - candidateScore(a))[0] ?? null;
    };

    let thread: Thread | null = directResult;
    if (!thread) {
      // Krótki polling – poczekaj aż backend/subskrypcja zmaterializuje wątek w getThreads().
      for (let i = 0; i < 5 && !thread; i++) {
        const list = await client.getThreads();
        thread = findCreatedThread(list);
        if (!thread) {
          await new Promise<void>((resolve) => setTimeout(resolve, 200));
        }
      }
    }

    if (thread) {
      // Add optimistic thread
      const nowSec = Math.floor(Date.now() / 1000);
      const lastMessage = thread.lastMessage ?? {
        id: `local-${thread.id}`,
        senderId: currentUserId,
        text: input.message.text,
        createdAt: { seconds: nowSec, nanoseconds: 0 },
      } as Thread["lastMessage"];

      const optimistic: Thread = {
        id: thread.id,
        type: thread.type,
        members: input.members,
        createdAt: thread.createdAt ?? { seconds: nowSec, nanoseconds: 0 },
        name: thread.name,
        acceptedBy: thread.acceptedBy ?? [currentUserId],
        roles: thread.roles,
        bannedMembers: thread.bannedMembers,
        lastMessage,
        unreadCount: 0,
      };

      setOptimisticThreads((prev) => {
        if (prev.some((t) => t.id === optimistic.id)) return prev;
        return [...prev, optimistic];
      });

      // Select the new thread
      onSelectThread(thread.id);

      // Notify parent
      onThreadCreated?.(thread);
    }

    setPreselectedMember(null);
    setShowNewThread(false);
  }, [client, currentUserId, onSelectThread, onThreadCreated]);

  const handleSelectThread = useCallback((threadId: string) => {
    onSelectThread(threadId);
  }, [onSelectThread]);

  const handleBack = useCallback(() => {
    if (onBack) {
      onBack();
    } else {
      onSelectThread(null);
    }
  }, [onBack, onSelectThread]);

  return (
    <div className="chat-sdk-root flex h-full min-h-0 flex-col bg-light-bg text-light-text-primary dark:bg-dark-bg dark:text-dark-text-primary">
      <div className="flex h-full min-h-0 w-full overflow-hidden">
        {/* Threads panel - on mobile visible when NO thread selected, on desktop always visible */}
        <div className={`min-h-0 shrink-0 border-r border-light-border bg-light-bg-secondary dark:border-dark-border dark:bg-dark-bg-secondary lg:block lg:w-[360px] ${selectedThreadId ? 'hidden' : 'block w-full'}`}>
          <ThreadsList
            currentUserId={currentUserId}
            onSelectThread={handleSelectThread}
            selectedThreadId={selectedThreadId}
            onNewThread={() => setShowNewThread(true)}
            extraThreads={optimisticThreads}
            footerSlot={footerSlot}
          />
        </div>

        {/* Thread view - on mobile visible when thread IS selected, on desktop always visible */}
        <div className={`flex min-h-0 flex-1 flex-col ${selectedThreadId ? 'block' : 'hidden lg:flex'}`}>
          {selectedThreadId ? (
            <ThreadView
              threadId={selectedThreadId}
              thread={activeThread}
              currentUserId={currentUserId}
              isActive={isVisible}
              onThreadActivity={refreshThreads}
              onThreadLeft={handleBack}
              onBack={handleBack}
            />
          ) : (
            <div className="hidden lg:flex flex-1 items-center justify-center text-sm text-light-text-secondary dark:text-dark-text-secondary">
              Wybierz wątek, aby zobaczyć wiadomości.
            </div>
          )}
        </div>
      </div>

      <NewThreadModal
        open={showNewThread}
        onClose={() => {
          setShowNewThread(false);
          setPreselectedMember(null);
          onNewThreadModalClose?.();
        }}
        onCreate={handleCreateThread}
        preselectedMember={preselectedMember}
        apiBaseUrl={apiBaseUrl}
        currentUserId={currentUserId}
      />
    </div>
  );
}

/** Skeleton loading state for ChatLayout */
export function ChatLayoutSkeleton({ footerSlot }: { footerSlot?: JSX.Element | null }): JSX.Element {
  useChatStyles();

  const skeletonItems = Array.from({ length: 3 });

  return (
    <div className="chat-sdk-root flex h-full min-h-0 flex-col bg-light-bg text-light-text-primary dark:bg-dark-bg dark:text-dark-text-primary">
      <div className="flex h-full min-h-0 w-full overflow-hidden">
        {/* Threads panel skeleton */}
        <div className="min-h-0 w-full border-r border-light-border bg-light-bg-secondary dark:border-dark-border dark:bg-dark-bg-secondary lg:w-[360px] lg:shrink-0">
          <div className="flex h-full min-h-0 flex-col">
            <div className="flex items-center justify-between border-b border-light-border px-3 py-3 dark:border-dark-border">
              <h3 className="text-lg font-bold">Wiadomości</h3>
              <div className="flex items-center gap-2">
                <span className="text-sm leading-none text-light-text-tertiary dark:text-dark-text-tertiary">Ładowanie...</span>
                {/* Rezerwuj miejsce na przycisk „nowy wątek”, aby uniknąć przeskoku layoutu po załadowaniu */}
                <div
                  aria-hidden="true"
                  className="h-9 w-9 rounded-full bg-light-bg-tertiary dark:bg-dark-bg-tertiary"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto flex flex-col">
              {skeletonItems.map((_, idx) => (
                <div key={idx} className="flex w-full items-center px-4 py-3 gap-3">
                  <div className="h-12 w-12 shrink-0 rounded-full bg-light-bg-tertiary dark:bg-dark-bg-tertiary" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 w-1/2 rounded bg-light-bg-tertiary dark:bg-dark-bg-tertiary" />
                    <div className="h-2.5 w-3/4 rounded bg-light-bg-tertiary dark:bg-dark-bg-tertiary" />
                  </div>
                  <div className="h-3 w-10 rounded bg-light-bg-tertiary dark:bg-dark-bg-tertiary" />
                </div>
              ))}
              {footerSlot}
            </div>
          </div>
        </div>

        {/* Right column placeholder */}
        <div className="hidden min-h-0 flex-1 flex-col lg:flex">
          <div className="flex flex-1 items-center justify-center text-sm text-light-text-secondary dark:text-dark-text-secondary">
            Wybierz wątek, aby zobaczyć wiadomości.
          </div>
        </div>
      </div>
    </div>
  );
}

/** Error state for ChatLayout */
export function ChatLayoutError({
  error,
  onRetry,
  footerSlot,
}: {
  error: string;
  onRetry?: () => void;
  footerSlot?: JSX.Element | null;
}): JSX.Element {
  useChatStyles();

  return (
    <div className="chat-sdk-root flex h-full min-h-0 flex-col bg-light-bg text-light-text-primary dark:bg-dark-bg dark:text-dark-text-primary">
      <div className="flex h-full min-h-0 w-full overflow-hidden">
        {/* Threads panel with error */}
        <div className="min-h-0 w-full border-r border-light-border bg-light-bg-secondary dark:border-dark-border dark:bg-dark-bg-secondary lg:w-[360px] lg:shrink-0">
          <div className="flex h-full min-h-0 flex-col">
            <div className="flex items-center justify-between border-b border-light-border px-3 py-3 dark:border-dark-border">
              <h3 className="text-lg font-bold">Wiadomości</h3>
            </div>

            <div className="mx-4 mt-4 rounded-lg border border-light-border bg-light-bg px-3 py-2 text-sm text-light-text-primary dark:border-dark-border dark:bg-dark-bg-secondary dark:text-dark-text-primary">
              Nie udało się uruchomić czatu.
              <div className="mt-1 text-xs text-light-text-secondary dark:text-dark-text-secondary">Błąd: {error}</div>
              {onRetry ? (
                <button
                  type="button"
                  onClick={onRetry}
                  className="mt-3 inline-flex items-center gap-2 rounded-full bg-light-primary px-3 py-1 text-xs font-semibold text-white transition-colors hover:bg-light-primary-hover dark:bg-dark-primary dark:hover:bg-dark-primary-hover"
                >
                  <i className="fa-solid fa-rotate-right" />
                  Spróbuj ponownie
                </button>
              ) : null}
            </div>

            <div className="flex-1 overflow-y-auto flex flex-col">
              {footerSlot}
            </div>
          </div>
        </div>

        {/* Right column placeholder */}
        <div className="hidden min-h-0 flex-1 flex-col lg:flex">
          <div className="flex flex-1 items-center justify-center text-sm text-light-text-secondary dark:text-dark-text-secondary">
            Wybierz wątek, aby zobaczyć wiadomości.
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Complete chat layout component with two-panel responsive design.
 *
 * @example
 * // Uncontrolled mode (internal state)
 * <ChatLayout
 *   currentUserId={userId}
 *   client={chatClient}
 *   apiBaseUrl="https://api.example.com"
 * />
 *
 * @example
 * // Controlled mode (external routing)
 * <ChatLayout
 *   currentUserId={userId}
 *   client={chatClient}
 *   apiBaseUrl="https://api.example.com"
 *   selectedThreadId={threadId}
 *   onThreadSelect={(id) => navigate(id ? `/chat/${id}` : '/chat')}
 * />
 */
export function ChatLayout(props: ChatLayoutProps): JSX.Element {
  const { selectedThreadId: controlledSelectedId, onThreadSelect, ...rest } = props;

  // Internal state for uncontrolled mode
  const [internalSelectedId, setInternalSelectedId] = useState<string | null>(null);

  // Determine if controlled
  const isControlled = controlledSelectedId !== undefined;
  const selectedThreadId = isControlled ? controlledSelectedId : internalSelectedId;

  const handleSelectThread = useCallback((threadId: string | null) => {
    if (isControlled && onThreadSelect) {
      // In controlled mode, find the thread and pass it to callback
      onThreadSelect(threadId, null); // Thread will be resolved inside
    } else {
      setInternalSelectedId(threadId);
    }
  }, [isControlled, onThreadSelect]);

  return (
    <ChatLayoutInner
      {...rest}
      selectedThreadId={selectedThreadId}
      onSelectThread={handleSelectThread}
    />
  );
}
