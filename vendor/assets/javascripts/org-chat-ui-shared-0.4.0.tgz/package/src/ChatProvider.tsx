import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, ReactNode } from "react";
import type { ChatClient } from "@org/chat-core";

export type UserProfile = {
  username?: string;
  displayName?: string;
  avatarUrl?: string;
};

type ChatContextValue = {
  client: ChatClient;
  currentUserId: string;
  getProfile: (userId: string) => UserProfile | undefined;
  ensureProfileSubscription: (userId: string) => void;
  uploadImage: (file: File) => Promise<string>;
};

export const ChatContext = createContext<ChatContextValue | null>(null);

export interface ChatProviderProps {
  client: ChatClient;
  currentUserId: string;
  children: ReactNode;
}

export function ChatProvider({ client, currentUserId, children }: ChatProviderProps): React.JSX.Element {
  const profilesRef = useRef<Map<string, UserProfile>>(new Map());
  const subscriptionsRef = useRef<Map<string, () => void>>(new Map());
  const [profilesVersion, setProfilesVersion] = useState(0);

  const setProfile = useCallback((userId: string, profile: UserProfile | undefined) => {
    if (profile) {
      profilesRef.current.set(userId, profile);
    } else {
      profilesRef.current.delete(userId);
    }
    setProfilesVersion((value: number) => value + 1);
  }, []);

  const ensureProfileSubscription = useCallback(
    (userId: string) => {
      if (!userId) {
        return;
      }
      if (subscriptionsRef.current.has(userId)) {
        return;
      }
      const unsubscribe = client.subscribeUserProfile(userId, (profile) => setProfile(userId, profile));
      subscriptionsRef.current.set(userId, unsubscribe);
    },
    [client, setProfile]
  );

  useEffect(() => {
    return () => {
      subscriptionsRef.current.forEach((unsubscribe: () => void) => unsubscribe());
      subscriptionsRef.current.clear();
    };
  }, []);

  const getProfile = useCallback((userId: string) => profilesRef.current.get(userId), []);

  const uploadImage = useCallback(async (file: File): Promise<string> => {
    return client.uploadImage(file);
  }, [client]);

  const value = useMemo(
    () => ({
      client,
      currentUserId,
      getProfile,
      ensureProfileSubscription,
      uploadImage,
    }),
    [client, currentUserId, getProfile, ensureProfileSubscription, uploadImage, profilesVersion]
  );

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export function useChatContext(): ChatContextValue {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("ChatProvider is missing in the component tree.");
  }
  return context;
}

export function useChatClient(): ChatClient {
  return useChatContext().client;
}

export function useCurrentUserId(): string {
  return useChatContext().currentUserId;
}

export function useUserProfile(userId?: string | null): UserProfile | undefined {
  const context = useChatContext();

  useEffect(() => {
    if (userId) {
      context.ensureProfileSubscription(userId);
    }
  }, [context, userId]);

  if (!userId) {
    return undefined;
  }

  return context.getProfile(userId);
}
