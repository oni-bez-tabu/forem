declare module "@org/chat-core" {
  export type ThreadType = "direct" | "group" | "community";
  export type MessageType = "text" | "image";
  export type MessageValidationErrorCode = "EMPTY_MESSAGE" | "IMAGE_ONLY_NOT_ALLOWED" | "TEXT_TOO_LONG";
  export type MessageDomainErrorCode =
    | MessageValidationErrorCode
    | "REPLY_NOT_FOUND"
    | "CHAT_GLOBALLY_BANNED"
    | "NOT_AUTHORIZED"
    | "USER_BANNED_IN_COMMUNITY"
    | "USER_BLOCKED";
  export type CommunityRole = "owner" | "moderator" | "member";

  export type SendMessageInput = {
    clientMessageId?: string;
    text?: string;
    imageUrl?: string;
    replyToId?: string;
  };

  export type SendMessageRequest =
    | { threadId: string; message: SendMessageInput }
    | { threadType: ThreadType; members: string[]; name?: string; message: SendMessageInput };

  export interface Timestamp {
    seconds: number;
    nanoseconds: number;
  }

  export interface ReplyTo {
    messageId: string;
    senderId: string;
    text?: string;
    imageUrl?: string;
  }

  export interface LastMessage {
    id: string;
    senderId: string;
    text?: string;
    imageUrl?: string;
    createdAt: Timestamp;
  }

  export interface Thread {
    id: string;
    type: ThreadType;
    members: string[];
    createdAt: Timestamp;
    lastMessage?: LastMessage;
    name?: string;
    acceptedBy?: string[];
    roles?: Record<string, CommunityRole>;
    bannedMembers?: string[];
    unreadCount: number;
  }

  export interface Message {
    id: string;
    clientMessageId?: string;
    threadId: string;
    senderId: string;
    type: MessageType;
    text?: string;
    imageUrl?: string;
    replyTo?: ReplyTo;
    likes: string[];
    readBy: string[];
    mentions?: string[];
    createdAt: Timestamp;
  }

  export interface UserProfile {
    username?: string;
    displayName?: string;
    avatarUrl?: string;
  }

  export interface ThreadUserPreferences {
    threadId: string;
    userId: string;
    muted: boolean;
    mutedAt?: Timestamp;
  }

  export interface NotificationFanout {
    messageId: string;
    threadId: string;
    recipients: string[];
    createdAt: Timestamp;
  }

  export class MessageValidationError extends Error {
    readonly code: MessageValidationErrorCode;
    constructor(code: MessageValidationErrorCode);
  }

  export class ReplyNotFoundError extends Error {
    readonly code: "REPLY_NOT_FOUND";
    constructor();
  }

  export class ChatGloballyBannedError extends Error {
    readonly code: "CHAT_GLOBALLY_BANNED";
    constructor();
  }

  export class NotAuthorizedError extends Error {
    readonly code: "NOT_AUTHORIZED";
    constructor();
  }

  export class UserBannedInCommunityError extends Error {
    readonly code: "USER_BANNED_IN_COMMUNITY";
    constructor();
  }

  export class UserBlockedError extends Error {
    readonly code: "USER_BLOCKED";
    constructor();
  }

  export interface ChatClient {
    init(): Promise<void>;
    getThreads(): Promise<Thread[]>;
    subscribeThreads(onChange: (threads: Thread[]) => void): () => void;
    openThread(threadId: string, onMessage: (message: Message) => void): Promise<() => void>;
    getUnreadCount(threadId: string): Promise<number>;
    sendMessage(input: SendMessageRequest): Promise<Thread | void>;
    likeMessage(threadId: string, messageId: string): Promise<void>;
    unlikeMessage(threadId: string, messageId: string): Promise<void>;
    markAsRead(threadId: string, messageId: string): Promise<void>;
    fetchMessages(
      threadId: string,
      options?: { limit?: number; beforeMessageId?: string }
    ): Promise<Message[]>;
    acceptThread(threadId: string): Promise<void>;
    leaveThread(threadId: string): Promise<void>;
    banUserFromCommunity(threadId: string, userId: string): Promise<void>;
    unbanUserFromCommunity(threadId: string, userId: string): Promise<void>;
    blockUser(userId: string): Promise<void>;
    unblockUser(userId: string): Promise<void>;
    isUserBlocked(userId: string): Promise<boolean>;
    setTyping(threadId: string, isTyping: boolean): Promise<void>;
    subscribeTyping(threadId: string, onChange: (userIds: string[]) => void): () => void;
    subscribeTotalUnread(onChange: (count: number) => void): () => void;
    muteThread(threadId: string): Promise<void>;
    unmuteThread(threadId: string): Promise<void>;
    getThreadUserPrefs(threadId: string): Promise<ThreadUserPreferences>;
    subscribeUserProfile(userId: string, onChange: (profile: UserProfile | undefined) => void): () => void;
    uploadImage(file: File): Promise<string>;
  }

  export const logger: {
    debug: (...args: unknown[]) => void;
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
    error: (...args: unknown[]) => void;
  };
}

