/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class", ".dark-theme"],
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        // Light
        "light-bg": "#FFFFFF",
        "light-bg-secondary": "#F7F7F8",
        "light-bg-tertiary": "#EFF0F1",
        "light-border": "#E4E5E7",
        "light-text-primary": "#111827",
        "light-text-secondary": "#6B7280",
        "light-text-tertiary": "#9CA3AF",
        "light-primary": "#3B82F6",
        "light-primary-hover": "#2563EB",
        // Dark
        "dark-bg": "#18191A",
        "dark-bg-secondary": "#242526",
        "dark-bg-tertiary": "#3A3B3C",
        "dark-border": "#4B4C4D",
        "dark-text-primary": "#E4E6EB",
        "dark-text-secondary": "#B0B3B8",
        "dark-text-tertiary": "#8A8D91",
        "dark-primary": "#4B8DEE",
        "dark-primary-hover": "#63A2F3",
      },
    },
  },
  plugins: [],
};
