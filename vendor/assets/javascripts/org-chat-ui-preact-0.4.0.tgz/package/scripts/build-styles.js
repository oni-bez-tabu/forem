import { execSync } from 'child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'fs';

// Build CSS
execSync('npx tailwindcss -i ./src/styles/source.css -o ./src/styles/output.css --minify', {
  stdio: 'inherit'
});

// Convert to TypeScript module
const css = readFileSync('./src/styles/output.css', 'utf8');
const tsContent = `// Auto-generated - do not edit\nexport const chatStyles = ${JSON.stringify(css)};\n`;

mkdirSync('./src/generated', { recursive: true });
writeFileSync('./src/generated/styles.ts', tsContent);

console.log('✓ Styles built successfully');
