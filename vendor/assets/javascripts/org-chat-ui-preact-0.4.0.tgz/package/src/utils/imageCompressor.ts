/**
 * Modul do kompresji obrazow z obsluga HEIC i Web Worker.
 *
 * Flow:
 * 1. HEIC -> JPEG (heic2any w glownym watku - wymaga DOM)
 * 2. Kompresja w Web Worker (OffscreenCanvas) lub fallback do glownego watku
 */

import { logger } from "@org/chat-core";

export interface CompressOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  maxSizeBytes?: number;
}

export interface CompressImageRequest {
  type: "compress";
  imageBitmap: ImageBitmap;
  options: {
    maxWidth: number;
    maxHeight: number;
    quality: number;
  };
  originalName: string;
}

export interface CompressImageResponse {
  type: "success";
  blob: Blob;
  width: number;
  height: number;
  originalWidth: number;
  originalHeight: number;
}

export interface CompressImageError {
  type: "error";
  message: string;
}

export type WorkerResponse = CompressImageResponse | CompressImageError;

// Lazy-load heic2any tylko gdy potrzebne (duza biblioteka)
let heic2anyModule: typeof import("heic2any") | null = null;

async function loadHeic2Any(): Promise<typeof import("heic2any")> {
  if (!heic2anyModule) {
    heic2anyModule = await import("heic2any");
  }
  return heic2anyModule;
}

/**
 * Sprawdza czy plik jest w formacie HEIC/HEIF
 */
function isHeicFile(file: File): boolean {
  const type = file.type.toLowerCase();
  const name = file.name.toLowerCase();
  return (
    type === "image/heic" ||
    type === "image/heif" ||
    name.endsWith(".heic") ||
    name.endsWith(".heif")
  );
}

/**
 * Probuje natywna konwersje HEIC przez przegladarke (Safari wspiera)
 */
async function tryNativeHeicConversion(file: File): Promise<File | null> {
  try {
    // Sprawdz czy przegladarka moze utworzyc ImageBitmap z HEIC
    const bitmap = await createImageBitmap(file);

    // Jesli sie udalo, konwertuj do JPEG przez canvas
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;

    const ctx = canvas.getContext("2d");
    if (!ctx) {
      bitmap.close();
      return null;
    }

    ctx.drawImage(bitmap, 0, 0);
    bitmap.close();

    return new Promise((resolve) => {
      canvas.toBlob(
        (blob) => {
          if (!blob) {
            resolve(null);
            return;
          }
          const newName = file.name.replace(/\.(heic|heif)$/i, ".jpg");
          resolve(new File([blob], newName, {
            type: "image/jpeg",
            lastModified: Date.now(),
          }));
        },
        "image/jpeg",
        0.92
      );
    });
  } catch {
    // Przegladarka nie wspiera HEIC natywnie
    return null;
  }
}

/**
 * Konwertuje HEIC do JPEG przez heic2any (fallback)
 */
async function convertHeicWithLibrary(file: File): Promise<File> {
  logger.debug("[imageCompressor] Laduje heic2any...");
  const heic2anyModule = await loadHeic2Any();

  const heic2anyFn = heic2anyModule.default;
  if (typeof heic2anyFn !== "function") {
    throw new Error(`heic2any.default nie jest funkcja: ${typeof heic2anyFn}`);
  }

  logger.debug("[imageCompressor] Konwertuje blob przez heic2any:", file.size, "bytes");
  const convertedBlob = await heic2anyFn({
    blob: file,
    toType: "image/jpeg",
    quality: 0.92,
  });

  const blob = Array.isArray(convertedBlob) ? convertedBlob[0] : convertedBlob;

  if (!blob) {
    throw new Error("Konwersja HEIC nie zwrocila danych");
  }

  const newName = file.name.replace(/\.(heic|heif)$/i, ".jpg");
  return new File([blob], newName, {
    type: "image/jpeg",
    lastModified: Date.now(),
  });
}

/**
 * Konwertuje HEIC do JPEG - najpierw natywnie, potem heic2any
 */
async function convertHeicToJpeg(file: File): Promise<File> {
  // 1. Probuj natywna konwersje (Safari, iOS)
  logger.debug("[imageCompressor] Probuje natywna konwersje HEIC...");
  const nativeResult = await tryNativeHeicConversion(file);
  if (nativeResult) {
    logger.debug("[imageCompressor] Natywna konwersja HEIC udana");
    return nativeResult;
  }

  // 2. Fallback do heic2any
  logger.debug("[imageCompressor] Natywna konwersja niedostepna, probuje heic2any...");
  return convertHeicWithLibrary(file);
}

/**
 * Sprawdza czy OffscreenCanvas jest dostepny
 */
function supportsOffscreenCanvas(): boolean {
  return typeof OffscreenCanvas !== "undefined";
}

/**
 * Kod Web Workera jako string (inline blob URL)
 */
const workerCode = `
self.onmessage = async (event) => {
  const { imageBitmap, options } = event.data;
  const { maxWidth, maxHeight, quality } = options;

  try {
    const originalWidth = imageBitmap.width;
    const originalHeight = imageBitmap.height;

    let width = originalWidth;
    let height = originalHeight;

    if (width > maxWidth) {
      height = (height * maxWidth) / width;
      width = maxWidth;
    }
    if (height > maxHeight) {
      width = (width * maxHeight) / height;
      height = maxHeight;
    }

    width = Math.round(width);
    height = Math.round(height);

    const canvas = new OffscreenCanvas(width, height);
    const ctx = canvas.getContext("2d");

    if (!ctx) {
      throw new Error("Nie mozna utworzyc kontekstu 2D w OffscreenCanvas");
    }

    ctx.drawImage(imageBitmap, 0, 0, width, height);

    const blob = await canvas.convertToBlob({
      type: "image/jpeg",
      quality,
    });

    imageBitmap.close();

    self.postMessage({
      type: "success",
      blob,
      width,
      height,
      originalWidth,
      originalHeight,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Nieznany blad kompresji";
    self.postMessage({ type: "error", message });
  }
};
`;

/**
 * Tworzy Web Worker dla kompresji (singleton)
 */
let workerInstance: Worker | null = null;
let workerSupported: boolean | null = null;
let workerBlobUrl: string | null = null;

function getWorker(): Worker | null {
  if (workerSupported === false) {
    return null;
  }

  if (workerInstance) {
    return workerInstance;
  }

  try {
    // Inline worker jako blob URL
    const blob = new Blob([workerCode], { type: "application/javascript" });
    workerBlobUrl = URL.createObjectURL(blob);
    workerInstance = new Worker(workerBlobUrl);
    workerSupported = true;
    return workerInstance;
  } catch {
    logger.warn("[imageCompressor] Web Worker nie jest wspierany, uzywam fallbacku");
    workerSupported = false;
    return null;
  }
}

/**
 * Kompresja w Web Worker (OffscreenCanvas)
 */
async function compressInWorker(
  file: File,
  options: Required<Omit<CompressOptions, "maxSizeBytes">>
): Promise<File> {
  const worker = getWorker();

  if (!worker || !supportsOffscreenCanvas()) {
    // Fallback do glownego watku
    return compressInMainThread(file, options);
  }

  // Utworz ImageBitmap (transferable)
  const imageBitmap = await createImageBitmap(file);

  return new Promise((resolve, reject) => {
    const handleMessage = (event: MessageEvent<WorkerResponse>) => {
      worker.removeEventListener("message", handleMessage);
      worker.removeEventListener("error", handleError);

      if (event.data.type === "error") {
        reject(new Error(event.data.message));
        return;
      }

      const { blob, width, height, originalWidth, originalHeight } = event.data;

      const originalName = file.name.replace(/\.[^/.]+$/, "");
      const compressedFile = new File([blob], `${originalName}.jpg`, {
        type: "image/jpeg",
        lastModified: Date.now(),
      });

      logger.debug(
        `[imageCompressor:worker] ${file.name}: ${(file.size / 1024).toFixed(0)}KB -> ${(compressedFile.size / 1024).toFixed(0)}KB ` +
          `(${originalWidth}x${originalHeight} -> ${width}x${height})`
      );

      resolve(compressedFile);
    };

    const handleError = (error: ErrorEvent) => {
      worker.removeEventListener("message", handleMessage);
      worker.removeEventListener("error", handleError);
      reject(new Error(error.message || "Blad Web Workera"));
    };

    worker.addEventListener("message", handleMessage);
    worker.addEventListener("error", handleError);

    const request: CompressImageRequest = {
      type: "compress",
      imageBitmap,
      options: {
        maxWidth: options.maxWidth,
        maxHeight: options.maxHeight,
        quality: options.quality,
      },
      originalName: file.name,
    };

    // Transfer ImageBitmap do workera (zero-copy)
    worker.postMessage(request, [imageBitmap]);
  });
}

/**
 * Fallback: kompresja w glownym watku (Canvas)
 */
async function compressInMainThread(
  file: File,
  options: Required<Omit<CompressOptions, "maxSizeBytes">>
): Promise<File> {
  const { maxWidth, maxHeight, quality } = options;

  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(url);

      let { width, height } = img;

      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      if (height > maxHeight) {
        width = (width * maxHeight) / height;
        height = maxHeight;
      }

      width = Math.round(width);
      height = Math.round(height);

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("Nie mozna utworzyc kontekstu canvas"));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error("Nie udalo sie skompresowac obrazu"));
            return;
          }

          const originalName = file.name.replace(/\.[^/.]+$/, "");
          const compressedFile = new File([blob], `${originalName}.jpg`, {
            type: "image/jpeg",
            lastModified: Date.now(),
          });

          logger.debug(
            `[imageCompressor:main] ${file.name}: ${(file.size / 1024).toFixed(0)}KB -> ${(compressedFile.size / 1024).toFixed(0)}KB ` +
              `(${img.width}x${img.height} -> ${width}x${height})`
          );

          resolve(compressedFile);
        },
        "image/jpeg",
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Nie udalo sie zaladowac obrazu"));
    };

    img.src = url;
  });
}

/**
 * Glowna funkcja kompresji obrazu.
 *
 * - Obsluguje HEIC/HEIF (automatyczna konwersja do JPEG)
 * - Uzywa Web Worker dla nieblokujacego przetwarzania
 * - Fallback do glownego watku jesli Worker niedostepny
 */
export async function compressImage(
  file: File,
  options: CompressOptions = {}
): Promise<File> {
  const {
    maxWidth = 1920,
    maxHeight = 1920,
    quality = 0.85,
    maxSizeBytes = 1024 * 1024,
  } = options;

  // 1. Jesli plik jest maly, nie kompresuj (chyba ze HEIC)
  if (file.size <= maxSizeBytes && !isHeicFile(file)) {
    return file;
  }

  let processedFile = file;

  // 2. Konwertuj HEIC do JPEG
  if (isHeicFile(file)) {
    logger.debug(`[imageCompressor] Konwertuje HEIC: ${file.name}`);
    try {
      processedFile = await convertHeicToJpeg(file);
      logger.debug(
        `[imageCompressor] HEIC -> JPEG: ${(file.size / 1024).toFixed(0)}KB -> ${(processedFile.size / 1024).toFixed(0)}KB`
      );

      // Po konwersji HEIC sprawdz czy jeszcze trzeba kompresowac
      if (processedFile.size <= maxSizeBytes) {
        return processedFile;
      }
    } catch (err) {
      logger.error("[imageCompressor] Blad konwersji HEIC:", err);
      throw new Error(
        "Nie udalo sie przekonwertowac zdjecia HEIC. Wyeksportuj zdjecie jako JPEG z aplikacji Zdjecia lub uzyj Safari."
      );
    }
  }

  // 3. Kompresuj (Worker lub fallback)
  return compressInWorker(processedFile, { maxWidth, maxHeight, quality });
}

/**
 * Zwalnia zasoby workera (opcjonalne, przy unmount aplikacji)
 */
export function terminateWorker(): void {
  if (workerInstance) {
    workerInstance.terminate();
    workerInstance = null;
  }
  if (workerBlobUrl) {
    URL.revokeObjectURL(workerBlobUrl);
    workerBlobUrl = null;
  }
}
