import { render, screen, fireEvent, waitFor } from "@testing-library/preact";
import { describe, expect, it, vi } from "vitest";
import { Composer, type ComposerProps } from "../Composer";
import { ChatProvider } from "@org/chat-ui-shared";
import type { ChatClient, Thread, Message } from "@org/chat-core";

function createMockClient(): ChatClient {
  return {
    init: vi.fn(),
    getThreads: vi.fn(),
    subscribeThreads: vi.fn(),
    openThread: vi.fn(),
    sendMessage: vi.fn(),
    fetchMessages: vi.fn(),
    likeMessage: vi.fn(),
    unlikeMessage: vi.fn(),
    markAsRead: vi.fn(),
    getUnreadCount: vi.fn(),
    acceptThread: vi.fn(),
    subscribeTotalUnread: vi.fn(),
    leaveThread: vi.fn(),
    isUserBlocked: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn(),
    subscribeTyping: vi.fn(),
    subscribeUserProfile: vi.fn(),
    uploadImage: vi.fn(),
  } as ChatClient;
}

function renderComposer(props: Partial<ComposerProps> = {}) {
  const defaultProps: ComposerProps = {
    onSend: vi.fn(),
    replyingTo: null,
    disabled: false,
    threadId: "thread-1",
    draft: "",
    currentUserId: "user-1",
    ...props,
  };

  const client = createMockClient();

  return {
    ...render(
      <ChatProvider client={client} currentUserId="user-1">
        <Composer {...defaultProps} />
      </ChatProvider>
    ),
    props: defaultProps,
  };
}

describe("Composer", () => {
  it("renderuje textarea i przycisk wysyłania", () => {
    const { container } = renderComposer();

    const textarea = screen.getByPlaceholderText("Napisz wiadomość...");
    expect(textarea).toBeInTheDocument();

    const sendButton = container.querySelector('button[type="submit"]');
    expect(sendButton).toBeInTheDocument();
  });

  it("przycisk wysyłania jest zablokowany gdy tekst jest pusty", () => {
    const { container } = renderComposer();

    // Find submit button by type="submit"
    const sendButton = container.querySelector('button[type="submit"]');
    expect(sendButton).toBeDisabled();
  });

  it("wywołuje onSend z tekstem po naciśnięciu przycisku", async () => {
    const onSend = vi.fn();
    const { container } = renderComposer({ onSend });

    const textarea = screen.getByPlaceholderText("Napisz wiadomość...");
    const sendButton = container.querySelector('button[type="submit"]');

    // Wpisz tekst
    fireEvent.input(textarea, { target: { value: "Hello world!" } });

    // Kliknij wyślij
    fireEvent.click(sendButton!);

    await waitFor(() => {
      expect(onSend).toHaveBeenCalledWith({
        text: "Hello world!",
        imageUrl: undefined,
      });
    });
  });

  it("nie wysyła pustej wiadomości", async () => {
    const onSend = vi.fn();
    const { container } = renderComposer({ onSend });

    const textarea = screen.getByPlaceholderText("Napisz wiadomość...");
    const sendButton = container.querySelector('button[type="submit"]');

    // Wpisz tylko spacje
    fireEvent.input(textarea, { target: { value: "   " } });

    // Kliknij wyślij
    fireEvent.click(sendButton!);

    await waitFor(() => {
      expect(onSend).not.toHaveBeenCalled();
    });
  });

  it("wyświetla reply preview gdy replyingTo jest ustawione", () => {
    const replyingTo: Message = {
      id: "msg-1",
      threadId: "thread-1",
      senderId: "user-2",
      type: "text",
      text: "Original message",
      likes: [],
      readBy: [],
      createdAt: { seconds: 0, nanoseconds: 0 },
    };

    renderComposer({ replyingTo });

    expect(screen.getByText("Odpowiadasz na wiadomość")).toBeInTheDocument();
    expect(screen.getByText("Original message")).toBeInTheDocument();
  });

  it("wywołuje onCancelReply po kliknięciu Anuluj", async () => {
    const onCancelReply = vi.fn();
    const replyingTo: Message = {
      id: "msg-1",
      threadId: "thread-1",
      senderId: "user-2",
      type: "text",
      text: "Original message",
      likes: [],
      readBy: [],
      createdAt: { seconds: 0, nanoseconds: 0 },
    };

    renderComposer({ replyingTo, onCancelReply });

    const cancelButton = screen.getByText("Anuluj");
    fireEvent.click(cancelButton);

    expect(onCancelReply).toHaveBeenCalled();
  });

  it("wyświetla komunikat disabled gdy disabled=true", () => {
    renderComposer({ disabled: true });

    expect(
      screen.getByText(/Pisanie jest zablokowane do momentu/)
    ).toBeInTheDocument();

    const textarea = screen.getByPlaceholderText("Napisz wiadomość...");
    expect(textarea).toBeDisabled();
  });

  it("wyświetla błąd gdy error jest ustawiony", () => {
    renderComposer({ error: "Test error message" });

    expect(screen.getByText("Test error message")).toBeInTheDocument();
  });

  it("czyści tekst po wysłaniu", async () => {
    const onSend = vi.fn().mockResolvedValue(undefined);
    const { container } = renderComposer({ onSend });

    const textarea = screen.getByPlaceholderText(
      "Napisz wiadomość..."
    ) as HTMLTextAreaElement;
    const sendButton = container.querySelector('button[type="submit"]');

    // Wpisz tekst
    fireEvent.input(textarea, { target: { value: "Test message" } });
    expect(textarea.value).toBe("Test message");

    // Wyślij
    fireEvent.click(sendButton!);

    await waitFor(() => {
      expect(onSend).toHaveBeenCalled();
    });

    // Sprawdź czy textarea została wyczyszczona
    await waitFor(() => {
      expect(textarea.value).toBe("");
    });
  });
});
