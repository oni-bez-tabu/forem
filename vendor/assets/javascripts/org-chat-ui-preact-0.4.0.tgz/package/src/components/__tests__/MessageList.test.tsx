import { render, screen } from "@testing-library/preact";
import { describe, expect, it, vi } from "vitest";
import { MessageList, type MessageListProps } from "../MessageList";
import type { UiMessage } from "../../hooks/useThread";

// Mock MessageItem component
vi.mock("../MessageItem", () => ({
  MessageItem: ({ message }: { message: UiMessage }) => (
    <div data-testid={`message-${message.id}`}>{message.text}</div>
  ),
}));

function renderMessageList(props: Partial<MessageListProps> = {}) {
  const defaultProps: MessageListProps = {
    messages: [],
    currentUserId: "user-1",
    ...props,
  };

  return render(<MessageList {...defaultProps} />);
}

describe("MessageList", () => {
  it("renderuje pustą listę gdy messages jest puste", () => {
    const { container } = renderMessageList({ messages: [] });
    expect(container.querySelector("div")?.children.length).toBe(0);
  });

  it("renderuje wszystkie wiadomości", () => {
    const messages: UiMessage[] = [
      {
        id: "msg-1",
        threadId: "thread-1",
        senderId: "user-1",
        type: "text",
        text: "First message",
        likes: [],
        readBy: [],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        status: "sent",
        isMine: true,
      },
      {
        id: "msg-2",
        threadId: "thread-1",
        senderId: "user-2",
        type: "text",
        text: "Second message",
        likes: [],
        readBy: [],
        createdAt: { seconds: 2000, nanoseconds: 0 },
        status: "sent",
        isMine: false,
      },
      {
        id: "msg-3",
        threadId: "thread-1",
        senderId: "user-1",
        type: "text",
        text: "Third message",
        likes: [],
        readBy: [],
        createdAt: { seconds: 3000, nanoseconds: 0 },
        status: "sent",
        isMine: true,
      },
    ];

    renderMessageList({ messages });

    expect(screen.getByTestId("message-msg-1")).toBeInTheDocument();
    expect(screen.getByTestId("message-msg-2")).toBeInTheDocument();
    expect(screen.getByTestId("message-msg-3")).toBeInTheDocument();

    expect(screen.getByText("First message")).toBeInTheDocument();
    expect(screen.getByText("Second message")).toBeInTheDocument();
    expect(screen.getByText("Third message")).toBeInTheDocument();
  });

  it("renderuje wiadomości w kolejności", () => {
    const messages: UiMessage[] = [
      {
        id: "msg-1",
        threadId: "thread-1",
        senderId: "user-1",
        type: "text",
        text: "Message 1",
        likes: [],
        readBy: [],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        status: "sent",
        isMine: true,
      },
      {
        id: "msg-2",
        threadId: "thread-1",
        senderId: "user-2",
        type: "text",
        text: "Message 2",
        likes: [],
        readBy: [],
        createdAt: { seconds: 2000, nanoseconds: 0 },
        status: "sent",
        isMine: false,
      },
    ];

    const { container } = renderMessageList({ messages });

    const messageElements = container.querySelectorAll("[data-testid^='message-']");
    expect(messageElements).toHaveLength(2);
    expect(messageElements[0]).toHaveAttribute("data-testid", "message-msg-1");
    expect(messageElements[1]).toHaveAttribute("data-testid", "message-msg-2");
  });

  it("przekazuje currentUserId do MessageItem", () => {
    const messages: UiMessage[] = [
      {
        id: "msg-1",
        threadId: "thread-1",
        senderId: "user-1",
        type: "text",
        text: "Test message",
        likes: [],
        readBy: [],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        status: "sent",
        isMine: true,
      },
    ];

    renderMessageList({ messages, currentUserId: "user-123" });

    // MessageItem will receive currentUserId through props
    // This is verified by the component rendering successfully
    expect(screen.getByTestId("message-msg-1")).toBeInTheDocument();
  });
});
