import { render, screen, fireEvent, waitFor } from "@testing-library/preact";
import { describe, expect, it, vi } from "vitest";
import { ThreadsList, type ThreadsListProps } from "../ThreadsPanel";
import { ChatProvider } from "@org/chat-ui-shared";
import type { ChatClient, Thread } from "@org/chat-core";

function createMockClient(
  subscribeImpl?: (cb: (threads: Thread[]) => void) => () => void
): ChatClient {
  return {
    init: vi.fn(),
    getThreads: vi.fn().mockResolvedValue([]),
    subscribeThreads: vi
      .fn()
      .mockImplementation(subscribeImpl ?? (() => () => {})),
    openThread: vi.fn(),
    sendMessage: vi.fn(),
    fetchMessages: vi.fn(),
    likeMessage: vi.fn(),
    unlikeMessage: vi.fn(),
    markAsRead: vi.fn(),
    getUnreadCount: vi.fn(),
    acceptThread: vi.fn(),
    subscribeTotalUnread: vi.fn().mockReturnValue(() => {}),
    leaveThread: vi.fn(),
    isUserBlocked: vi.fn(),
    blockUser: vi.fn(),
    unblockUser: vi.fn(),
    banUserFromCommunity: vi.fn(),
    unbanUserFromCommunity: vi.fn(),
    muteThread: vi.fn(),
    unmuteThread: vi.fn(),
    getThreadUserPrefs: vi.fn(),
    setTyping: vi.fn(),
    subscribeTyping: vi.fn(),
    subscribeUserProfile: vi.fn().mockReturnValue(() => {}),
    uploadImage: vi.fn(),
  } as ChatClient;
}

function renderThreadsList(
  props: Partial<ThreadsListProps> = {},
  threads: Thread[] = []
) {
  const defaultProps: ThreadsListProps = {
    currentUserId: "user-1",
    onSelectThread: vi.fn(),
    selectedThreadId: null,
    ...props,
  };

  const client = createMockClient((cb) => {
    cb(threads);
    return () => {};
  });

  return {
    ...render(
      <ChatProvider client={client} currentUserId="user-1">
        <ThreadsList {...defaultProps} />
      </ChatProvider>
    ),
    props: defaultProps,
  };
}

describe("ThreadsPanel / ThreadsList", () => {
  it("wyświetla 'Brak dostępnych wątków' gdy lista jest pusta", async () => {
    renderThreadsList({}, []);

    await waitFor(() => {
      expect(screen.getByText("Brak dostępnych wątków.")).toBeInTheDocument();
    });
  });

  it("wyświetla loading state podczas ładowania", () => {
    const client = createMockClient((cb) => {
      // Don't call cb immediately to simulate loading
      return () => {};
    });

    render(
      <ChatProvider client={client} currentUserId="user-1">
        <ThreadsList currentUserId="user-1" onSelectThread={vi.fn()} />
      </ChatProvider>
    );

    expect(screen.getByText("Ładowanie...")).toBeInTheDocument();
  });

  it("renderuje listę wątków", async () => {
    const threads: Thread[] = [
      {
        id: "thread-1",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Hello!",
          createdAt: { seconds: 1000, nanoseconds: 0 },
        },
        unreadCount: 0,
      },
      {
        id: "thread-2",
        type: "group",
        members: ["user-1", "user-2", "user-3"],
        name: "Group Chat",
        createdAt: { seconds: 2000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-2",
          senderId: "user-3",
          text: "How are you?",
          createdAt: { seconds: 2000, nanoseconds: 0 },
        },
        unreadCount: 2,
      },
    ];

    renderThreadsList({}, threads);

    await waitFor(() => {
      // Threads should be rendered (check for last messages)
      expect(screen.getByText("Hello!")).toBeInTheDocument();
      expect(screen.getByText("How are you?")).toBeInTheDocument();
    });
  });

  it("sortuje wątki po ostatniej wiadomości (najnowsze pierwsze)", async () => {
    const threads: Thread[] = [
      {
        id: "thread-old",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Old message",
          createdAt: { seconds: 1000, nanoseconds: 0 },
        },
        unreadCount: 0,
      },
      {
        id: "thread-new",
        type: "direct",
        members: ["user-1", "user-3"],
        createdAt: { seconds: 3000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-2",
          senderId: "user-3",
          text: "New message",
          createdAt: { seconds: 3000, nanoseconds: 0 },
        },
        unreadCount: 0,
      },
    ];

    const { container } = renderThreadsList({}, threads);

    await waitFor(() => {
      const buttons = container.querySelectorAll("button[aria-pressed]");
      expect(buttons).toHaveLength(2);
      // Newest first
      expect(buttons[0]?.textContent).toContain("New message");
      expect(buttons[1]?.textContent).toContain("Old message");
    });
  });

  it("wyświetla unread count gdy wątek ma nieprzeczytane wiadomości", async () => {
    const threads: Thread[] = [
      {
        id: "thread-1",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Unread message",
          createdAt: { seconds: 1000, nanoseconds: 0 },
        },
        unreadCount: 5,
      },
    ];

    const { container } = renderThreadsList({}, threads);

    await waitFor(() => {
      // Check for unread count badge (looking for "5")
      const text = container.textContent;
      expect(text).toContain("5");
    });
  });

  it("wywołuje onSelectThread po kliknięciu wątku", async () => {
    const onSelectThread = vi.fn();
    const threads: Thread[] = [
      {
        id: "thread-1",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Click me",
          createdAt: { seconds: 1000, nanoseconds: 0 },
        },
        unreadCount: 0,
      },
    ];

    renderThreadsList({ onSelectThread }, threads);

    await waitFor(() => {
      const button = screen.getByText("Click me").closest("button");
      expect(button).toBeInTheDocument();

      if (button) {
        fireEvent.click(button);
        expect(onSelectThread).toHaveBeenCalledWith("thread-1");
      }
    });
  });

  it("wyróżnia wybrany wątek", async () => {
    const threads: Thread[] = [
      {
        id: "thread-1",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: { seconds: 1000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Selected thread",
          createdAt: { seconds: 1000, nanoseconds: 0 },
        },
        unreadCount: 0,
      },
    ];

    renderThreadsList({ selectedThreadId: "thread-1" }, threads);

    await waitFor(() => {
      const button = screen.getByText("Selected thread").closest("button");
      expect(button).toHaveAttribute("aria-pressed", "true");
    });
  });

  it("wyświetla przycisk nowej wiadomości gdy onNewThread jest przekazane", async () => {
    const onNewThread = vi.fn();
    renderThreadsList({ onNewThread }, []);

    await waitFor(() => {
      const newMessageButton = screen.getByLabelText("Nowa wiadomość");
      expect(newMessageButton).toBeInTheDocument();

      fireEvent.click(newMessageButton);
      expect(onNewThread).toHaveBeenCalled();
    });
  });

  it("formatuje tytuł wątku z nazwą dla group/community", async () => {
    const threads: Thread[] = [
      {
        id: "thread-1",
        type: "community",
        members: ["user-1", "user-2", "user-3"],
        name: "Test Community",
        createdAt: { seconds: 1000, nanoseconds: 0 },
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Community message",
          createdAt: { seconds: 1000, nanoseconds: 0 },
        },
        unreadCount: 0,
      },
    ];

    const { container } = renderThreadsList({}, threads);

    await waitFor(() => {
      // Title should show community name
      expect(container.textContent).toContain("Test Community");
    });
  });
});
