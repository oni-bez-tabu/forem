import { useState } from "preact/hooks";
import type { JSX } from "preact";
import type { Thread } from "@org/chat-core";
import { useChatClient } from "@org/chat-ui-shared";

export interface AcceptConversationProps {
  thread: Thread;
  currentUserId: string;
}

export function AcceptConversation({ thread, currentUserId }: AcceptConversationProps): JSX.Element | null {
  const client = useChatClient();
  const [submitting, setSubmitting] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const alreadyAccepted = (thread.acceptedBy ?? []).includes(currentUserId);
  if (thread.type !== "group" || alreadyAccepted) {
    return null;
  }

  const handleAccept = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await client.acceptThread(thread.id);
      // UI zaktualizuje się automatycznie przez subscribeThreads gdy CF zrobi fanout
    } catch (err) {
      const message = err instanceof Error ? err.message : "Nie udało się zaakceptować rozmowy";
      setError(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleLeave = async () => {
    setLeaving(true);
    setError(null);
    try {
      await client.leaveThread(thread.id);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Nie udało się opuścić grupy";
      setError(message);
    } finally {
      setLeaving(false);
    }
  };

  return (
    <div className="mb-4 rounded-none border border-light-border bg-light-bg-secondary px-5 py-4 shadow-sm dark:border-dark-border dark:bg-dark-bg-tertiary">
      <div className="flex items-start gap-3">
        <div className="mt-1 flex h-10 w-10 items-center justify-center rounded-full bg-light-primary/10 text-light-primary dark:bg-dark-primary/20 dark:text-dark-primary">
          <i className="fa-solid fa-circle-info" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-light-text-primary dark:text-dark-text-primary">Ta rozmowa wymaga Twojej akceptacji.</p>
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Dołącz, aby wysyłać i odbierać wiadomości.</p>
          {error ? (
            <div role="alert" className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600 dark:bg-red-900/20 dark:text-red-200">
              {error}
            </div>
          ) : null}
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => void handleAccept()}
              disabled={submitting}
              className="rounded-lg bg-light-primary px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-light-primary-hover disabled:opacity-60 dark:bg-dark-primary dark:hover:bg-dark-primary-hover"
            >
              {submitting ? "Akceptuję..." : "Akceptuj"}
            </button>
            <button
              type="button"
              onClick={() => void handleLeave()}
              disabled={leaving}
              className="rounded-lg border border-light-border px-4 py-2 text-sm font-semibold text-light-text-secondary transition-colors hover:bg-light-bg dark:border-dark-border dark:text-dark-text-secondary dark:hover:bg-dark-bg-secondary disabled:opacity-60"
            >
              {leaving ? "Wychodzę..." : "Wyjdź z grupy"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

