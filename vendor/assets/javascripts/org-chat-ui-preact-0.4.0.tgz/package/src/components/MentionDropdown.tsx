import type { JSX } from "preact";

export type MentionCandidate = {
  userId: string;
  username: string;
  displayName?: string;
  avatarUrl?: string;
};

interface MentionDropdownProps {
  candidates: MentionCandidate[];
  highlightedIndex: number;
  onHover: (index: number) => void;
  onSelect: (candidate: MentionCandidate) => void;
}

export function MentionDropdown({ candidates, highlightedIndex, onHover, onSelect }: MentionDropdownProps): JSX.Element | null {
  if (candidates.length === 0) {
    return null;
  }

  const visible = candidates.slice(0, 8);

  return (
    <div className="w-full overflow-hidden rounded-xl border border-light-border bg-light-bg shadow-2xl dark:border-dark-border dark:bg-dark-bg-secondary">
      {visible.map((candidate, index) => {
        const active = index === highlightedIndex;
        const initials = candidate.username?.[0]?.toUpperCase() ?? "@";
        return (
          <button
            key={candidate.userId}
            type="button"
            onMouseEnter={() => onHover(index)}
            onClick={() => onSelect(candidate)}
            className={`flex w-full items-center gap-3 px-3 py-3 text-left transition-colors ${
              active ? "bg-light-bg-tertiary dark:bg-dark-bg-tertiary" : "bg-transparent"
            } ${index !== visible.length - 1 ? "border-b border-light-border dark:border-dark-border" : ""}`}
          >
            {candidate.avatarUrl ? (
              <img
                src={candidate.avatarUrl}
                alt={candidate.displayName ?? candidate.username}
                className="h-8 w-8 rounded-full object-cover"
              />
            ) : (
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-light-bg-tertiary text-sm font-semibold text-light-text-primary dark:bg-dark-bg-tertiary dark:text-dark-text-primary">
                {initials}
              </div>
            )}
            <div className="flex flex-col gap-0.5">
              <span className="text-sm font-semibold">@{candidate.username}</span>
              {candidate.displayName && candidate.displayName !== candidate.username ? (
                <span className="text-xs text-light-text-secondary dark:text-dark-text-secondary">{candidate.displayName}</span>
              ) : null}
            </div>
          </button>
        );
      })}
    </div>
  );
}

