import type { JSX } from "preact";
import { useCallback, useEffect, useMemo, useRef, useState } from "preact/hooks";
import type { Message, Thread } from "@org/chat-core";
import { MentionDropdown, type MentionCandidate } from "./MentionDropdown";
import { useChatContext } from "@org/chat-ui-shared";
import { compressImage } from "../utils/imageCompressor";
import { useChatStyles } from "../hooks/useChatStyles";

const decodeTextarea = typeof document !== "undefined" ? document.createElement("textarea") : null;
function decodeEntities(text: string): string {
  if (!text || !decodeTextarea) return text;
  let current = text;
  for (let i = 0; i < 3; i += 1) {
    decodeTextarea.innerHTML = current;
    const next = decodeTextarea.value;
    if (next === current) break;
    current = next;
  }
  return current;
}

export interface ComposerProps {
  onSend: (payload: { text?: string; imageUrl?: string }) => Promise<void> | void;
  replyingTo: Message | null;
  error?: string | null;
  onClearError?: () => void;
  onCancelReply?: () => void;
  disabled?: boolean;
  onTyping?: () => void;
  onStopTyping?: () => Promise<void> | void;
  autoFocus?: boolean;
  thread?: Thread | null;
  threadId: string;
  draft: string;
  onDraftChange?: (value: string) => void;
  currentUserId: string;
}

export function Composer({
  onSend,
  replyingTo,
  error,
  onClearError,
  onCancelReply,
  disabled = false,
  onTyping,
  onStopTyping,
  autoFocus = false,
  thread,
  threadId,
  draft,
  onDraftChange,
  currentUserId,
}: ComposerProps): JSX.Element {
  useChatStyles();
  const { ensureProfileSubscription, getProfile, uploadImage } = useChatContext();
  const [text, setText] = useState<string>(draft ?? "");
  
  // Stan dla uploadu pliku
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  
  const [mentionActive, setMentionActive] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const [mentionStart, setMentionStart] = useState<number | null>(null);
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const sendingRef = useRef(false);
  const [sending, setSending] = useState(false);

  const focusInput = useCallback(() => {
    const input = inputRef.current;
    if (!input) return;
    requestAnimationFrame(() => {
      input.focus();
      const pos = input.value.length;
      input.setSelectionRange(pos, pos);
    });
  }, []);

  useEffect(() => {
    if (autoFocus && !disabled) {
      focusInput();
    }
  }, [autoFocus, disabled, threadId, focusInput]);

  // Sprawdź czy można wysłać
  // WAŻNE: Zdjęcie bez tekstu jest zabronione (IMAGE_ONLY_NOT_ALLOWED)
  // Więc: wymagany tekst, zdjęcie jest opcjonalne
  const isSendDisabled = useMemo(
    () => text.trim().length === 0,
    [text]
  );
  const mentionEnabled = thread?.type === "group" || thread?.type === "community";
  const visibleError = error === "User is blocked" ? "Zostałeś/aś zablokowany/a" : error;
  const replyPreviewText = useMemo(() => decodeEntities(replyingTo?.text ?? ""), [replyingTo?.text]);

  // Cleanup preview URL przy odmontowaniu lub zmianie pliku
  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  useEffect(() => {
    setText(draft ?? "");
    const input = inputRef.current;
    if (input) {
      input.style.height = "auto";
      requestAnimationFrame(() => {
        input.style.height = `${Math.min(input.scrollHeight, 96)}px`;
      });
    }
  }, [draft, threadId]);

  useEffect(() => {
    if (!mentionEnabled || !thread?.members) {
      return;
    }
    thread.members
      .filter((member) => member !== currentUserId)
      .forEach((member) => ensureProfileSubscription(member));
  }, [thread, mentionEnabled, ensureProfileSubscription, currentUserId]);

  const mentionCandidates = useMemo<MentionCandidate[]>(() => {
    if (!mentionEnabled || !thread?.members) {
      return [];
    }
    const normalizedQuery = mentionQuery.toLowerCase();
    return thread.members
      .filter((member) => member !== currentUserId)
      .map((member) => {
        const profile = getProfile(member);
        const username = profile?.username ?? member;
        return {
          userId: member,
          username,
          displayName: profile?.displayName ?? username,
          avatarUrl: profile?.avatarUrl,
        };
      })
      .filter((candidate) => candidate.username.toLowerCase().startsWith(normalizedQuery));
  }, [mentionEnabled, thread, currentUserId, getProfile, mentionQuery]);

  const visibleMentionCandidates = useMemo(() => mentionCandidates.slice(0, 8), [mentionCandidates]);

  const resetMentions = () => {
    setMentionActive(false);
    setMentionQuery("");
    setMentionStart(null);
    setHighlightedIndex(0);
  };

  const [compressing, setCompressing] = useState(false);

  // Sprawdza czy plik jest obrazem (włącznie z HEIC/HEIF)
  const isImageFile = useCallback((file: File): boolean => {
    if (file.type.startsWith("image/")) {
      return true;
    }
    // HEIC/HEIF może nie mieć poprawnego MIME type na niektórych systemach
    const name = file.name.toLowerCase();
    return name.endsWith(".heic") || name.endsWith(".heif");
  }, []);

  // Obsługa wyboru pliku z automatyczną kompresją i obsługą HEIC
  const handleFileSelect = useCallback(async (event: Event) => {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];

    if (!file) {
      return;
    }

    // Walidacja typu pliku (z obsługą HEIC)
    if (!isImageFile(file)) {
      setUploadError("Tylko pliki graficzne są dozwolone");
      return;
    }

    setUploadError(null);
    setCompressing(true);

    try {
      // Automatyczna kompresja dużych zdjęć + konwersja HEIC
      // Max 1920px, jakość 85%, cel: poniżej 1MB
      // HEIC jest automatycznie konwertowany do JPEG
      const processedFile = await compressImage(file, {
        maxWidth: 1920,
        maxHeight: 1920,
        quality: 0.85,
        maxSizeBytes: 1024 * 1024, // 1MB
      });

      // Dodatkowa walidacja po kompresji (failsafe)
      if (processedFile.size > 5 * 1024 * 1024) {
        setUploadError("Zdjęcie jest za duże nawet po kompresji. Spróbuj mniejszego zdjęcia.");
        setCompressing(false);
        return;
      }

      // Wyczyść poprzedni preview
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }

      // Ustaw skompresowany plik i podgląd
      setSelectedFile(processedFile);
      setPreviewUrl(URL.createObjectURL(processedFile));
      setCompressing(false);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Nie udało się przetworzyć zdjęcia";
      setUploadError(message);
      setCompressing(false);
    }
  }, [previewUrl, isImageFile]);

  // Usunięcie wybranego pliku
  const handleRemoveFile = useCallback(() => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    setUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, [previewUrl]);

  const handleSubmit = async (event: Event) => {
    event.preventDefault();
    if (sendingRef.current || disabled || uploading || compressing) {
      return;
    }
    const trimmedText = text.trim();
    
    // Tekst jest wymagany (zdjęcie jest opcjonalne)
    // IMAGE_ONLY_NOT_ALLOWED - zdjęcie bez tekstu jest zabronione
    if (!trimmedText) {
      return;
    }

    sendingRef.current = true;
    setSending(true);
    const stopTypingPromise = onStopTyping ? onStopTyping() : undefined;

    try {
      let finalImageUrl: string | undefined;

      // Jeśli jest wybrany plik, najpierw go uploaduj
      if (selectedFile) {
        setUploading(true);
        setUploadError(null);
        try {
          finalImageUrl = await uploadImage(selectedFile);
        } catch (err) {
          const message = err instanceof Error ? err.message : "Nie udało się przesłać zdjęcia";
          setUploadError(message);
          return;
        } finally {
          setUploading(false);
        }
      }

      // Zachowaj kopie wartości do wysłania
      const textToSend = trimmedText || undefined;
      const imageUrlToSend = finalImageUrl;

      // Wyczyść formularz natychmiast przed wysłaniem (dla lepszego UX)
      setText("");
      onDraftChange?.("");
      handleRemoveFile();
      onClearError?.();
      resetInput();

      // Wyślij wiadomość z zachowanymi wartościami
      await onSend({ text: textToSend, imageUrl: imageUrlToSend });
      void stopTypingPromise;
    } finally {
      sendingRef.current = false;
      setSending(false);
      focusInput();
    }
  };

  const handleTextChange = (event: Event) => {
    const value = (event.currentTarget as HTMLTextAreaElement).value;
    const cursor = (event.currentTarget as HTMLTextAreaElement).selectionStart ?? value.length;
    const beforeCursor = value.slice(0, cursor);
    const match = mentionEnabled ? beforeCursor.match(/@([a-zA-Z0-9_-]{0,20})$/) : null;
    if (match) {
      setMentionActive(true);
      setMentionQuery(match[1] ?? "");
      setMentionStart(match.index ?? cursor - (match[1]?.length ?? 0) - 1);
      setHighlightedIndex(0);
    } else {
      resetMentions();
    }
    setText(value);
    onDraftChange?.(value);
    autoResize(event.currentTarget as HTMLTextAreaElement);
    onTyping?.();
    onClearError?.();
  };

  const handleMentionSelect = (candidate: MentionCandidate) => {
    if (!mentionActive || mentionStart === null) {
      return;
    }
    const before = text.slice(0, mentionStart);
    const after = text.slice(mentionStart + 1 + mentionQuery.length);
    const insertion = `@${candidate.username} `;
    const nextText = `${before}${insertion}${after}`;
    setText(nextText);
    resetMentions();
    requestAnimationFrame(() => {
      const input = inputRef.current;
      if (!input) {
        return;
      }
      const cursor = before.length + insertion.length;
      input.focus();
      input.setSelectionRange(cursor, cursor);
      autoResize(input);
    });
  };

  const handleKeyDown = (event: KeyboardEvent) => {
    if (sendingRef.current) {
      event.preventDefault();
      return;
    }

    const mentionListOpen = mentionActive && visibleMentionCandidates.length > 0;

    // Obsługa nawigacji/wyboru w dropdownie mention zanim dopuścimy do wysłania
    if (mentionListOpen) {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setHighlightedIndex((prev) => (prev + 1) % visibleMentionCandidates.length);
        return;
      }
      if (event.key === "ArrowUp") {
        event.preventDefault();
        setHighlightedIndex((prev) => (prev - 1 + visibleMentionCandidates.length) % visibleMentionCandidates.length);
        return;
      }
      if (event.key === "Enter" && event.shiftKey) {
        // Shift+Enter pozwala na nową linię, nie wybiera z listy
        return;
      }
      if (event.key === "Enter") {
        event.preventDefault();
        handleMentionSelect(visibleMentionCandidates[highlightedIndex] ?? visibleMentionCandidates[0]);
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        resetMentions();
        return;
      }
    }

    // Standardowe wysłanie Enterem
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void handleSubmit(event);
    }
  };

  const autoResize = (el: HTMLTextAreaElement) => {
    const maxHeight = 96; // ~2 linie
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, maxHeight)}px`;
  };

  const resetInput = () => {
    setText("");
    onDraftChange?.("");
    resetMentions();
    const input = inputRef.current;
    if (input) {
      input.style.height = "auto";
    }
  };

  return (
    <div className="space-y-3">
      {visibleError ? <div className="text-sm text-red-500">{visibleError}</div> : null}
      {uploadError ? <div className="text-sm text-red-500">{uploadError}</div> : null}

      {compressing ? (
        <div className="flex items-center gap-2 rounded-xl bg-light-bg-tertiary px-3 py-2 text-sm text-light-text-secondary dark:bg-dark-bg-tertiary dark:text-dark-text-secondary">
          <span>⏳</span>
          <span>Optymalizowanie zdjęcia...</span>
        </div>
      ) : null}

      {previewUrl && !compressing ? (
        <div className="flex items-start gap-2">
          <div className="relative">
            <img src={previewUrl} alt="Podgląd zdjęcia" className="max-h-36 max-w-[220px] rounded-lg object-cover" />
            <button
              type="button"
              onClick={handleRemoveFile}
              disabled={uploading}
              className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white shadow"
              aria-label="Usuń zdjęcie"
            >
              ×
            </button>
            {uploading ? (
              <div className="absolute inset-0 flex items-center justify-center rounded-lg bg-white/70 text-xs text-light-text-secondary">
                Przesyłanie...
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      <form onSubmit={handleSubmit} className="space-y-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.heic,.heif"
          onChange={handleFileSelect}
          disabled={disabled || uploading || compressing}
          className="hidden"
        />
        {replyingTo ? (
          <div className="flex items-center justify-between gap-3 rounded-xl bg-light-bg-secondary px-3 py-2 text-xs text-light-text-secondary dark:bg-dark-bg-tertiary dark:text-dark-text-secondary">
            <div className="flex min-w-0 items-center gap-2">
              <i className="fa-solid fa-reply text-light-text-tertiary dark:text-dark-text-tertiary" />
              <div className="min-w-0">
                <div className="text-[11px] font-semibold text-light-text-primary dark:text-dark-text-primary">Odpowiadasz na wiadomość</div>
                <div className="text-[12px] text-light-text-secondary dark:text-dark-text-secondary break-words break-all whitespace-pre-wrap">
                  {replyPreviewText || (replyingTo.imageUrl ? "Załączone zdjęcie" : "Wiadomość")}
                </div>
              </div>
            </div>
            {onCancelReply ? (
              <button
                type="button"
                onClick={onCancelReply}
                className="shrink-0 rounded-full bg-light-bg-tertiary px-3 py-1 text-[11px] font-semibold text-light-text-secondary hover:bg-light-border dark:bg-dark-bg dark:text-dark-text-secondary dark:hover:bg-dark-border"
              >
                Anuluj
              </button>
            ) : null}
          </div>
        ) : null}

        <div className="relative flex flex-wrap items-center gap-2">
          <div className="relative flex flex-1 items-center gap-3 rounded-full bg-light-bg-secondary px-3 py-2 dark:bg-dark-bg-secondary">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
          disabled={disabled || uploading || compressing || sending || !!selectedFile}
              className="rounded-full p-2 text-light-text-secondary transition-colors hover:text-light-primary disabled:opacity-50 dark:text-dark-text-secondary dark:hover:text-dark-primary"
            >
              <i className="fa-solid fa-image fa-lg" />
            </button>
            <textarea
              ref={inputRef}
              value={text}
              onInput={handleTextChange}
              onKeyDown={handleKeyDown}
              placeholder="Napisz wiadomość..."
          disabled={disabled || uploading || compressing || sending}
              rows={1}
              className="flex-1 resize-none bg-transparent text-sm text-light-text-primary placeholder-light-text-tertiary outline-none dark:text-dark-text-primary dark:placeholder-dark-text-tertiary"
            />
            <button
              type="submit"
          disabled={disabled || isSendDisabled || uploading || compressing || sending}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-light-primary text-white transition-colors hover:bg-light-primary-hover disabled:opacity-60 dark:bg-dark-primary dark:hover:bg-dark-primary-hover"
            >
              <i className="fa-solid fa-paper-plane" />
            </button>
          </div>

        {mentionActive && visibleMentionCandidates.length > 0 ? (
          <div className="absolute bottom-full left-0 right-0 mb-2 max-h-64 overflow-y-auto rounded-xl border border-light-border bg-light-bg shadow-2xl dark:border-dark-border dark:bg-dark-bg-secondary">
            <MentionDropdown
              candidates={visibleMentionCandidates}
              highlightedIndex={highlightedIndex}
              onHover={(index) => setHighlightedIndex(index)}
              onSelect={handleMentionSelect}
            />
          </div>
        ) : null}
        </div>

        {disabled ? (
          <div className="text-xs text-light-text-tertiary dark:text-dark-text-tertiary">Pisanie jest zablokowane do momentu, aż użytkownik Ci odpowie.</div>
        ) : null}
      </form>
    </div>
  );
}
