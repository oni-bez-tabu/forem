import type { JSX } from "preact";
import type { UiMessage } from "@org/chat-ui-shared";
import { MessageItem } from "./MessageItem";

export interface MessageListProps {
  messages: UiMessage[];
  currentUserId: string;
}

export function MessageList({ messages, currentUserId }: MessageListProps): JSX.Element {
  return (
    <div>
      {messages.map((message) => (
        <MessageItem key={message.id} message={message} currentUserId={currentUserId} />
      ))}
    </div>
  );
}

