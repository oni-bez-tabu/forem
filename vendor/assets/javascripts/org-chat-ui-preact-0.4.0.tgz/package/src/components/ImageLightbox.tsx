import type { JSX } from "preact";
import { useEffect, useCallback } from "preact/hooks";

export interface ImageLightboxProps {
  imageUrl: string;
  alt?: string;
  open: boolean;
  onClose: () => void;
}

export function ImageLightbox({ imageUrl, alt, open, onClose }: ImageLightboxProps): JSX.Element | null {
  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    },
    [onClose]
  );

  const handleBackdropClick = useCallback(
    (event: MouseEvent) => {
      if (event.target === event.currentTarget) {
        onClose();
      }
    },
    [onClose]
  );

  useEffect(() => {
    if (!open) return;

    // Block body scroll when lightbox is open
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    // Add escape key listener
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = originalOverflow;
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open, handleKeyDown]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={alt ?? "Powiększony obraz"}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90"
      onClick={handleBackdropClick as unknown as JSX.MouseEventHandler<HTMLDivElement>}
    >
      <button
        type="button"
        onClick={onClose}
        className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
        aria-label="Zamknij"
      >
        <i className="fa-solid fa-xmark text-xl" />
      </button>

      <div className="relative">
        <img
          src={imageUrl}
          alt={alt ?? "Powiększony obraz"}
          className="max-h-[95vh] max-w-[95vw] object-contain"
        />
        {/* Transparent overlay to block right-click and drag */}
        <div className="absolute inset-0" aria-hidden="true" />
      </div>
    </div>
  );
}
