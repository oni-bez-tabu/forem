import { useEffect } from 'preact/hooks';
import { chatStyles } from '../generated/styles';

const STYLE_ID = 'chat-sdk-styles';
let stylesInjected = false;

export function useChatStyles(): void {
  useEffect(() => {
    if (stylesInjected) return;
    if (typeof document === 'undefined') return;
    if (document.getElementById(STYLE_ID)) {
      stylesInjected = true;
      return;
    }

    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = chatStyles;
    document.head.appendChild(style);
    stylesInjected = true;
  }, []);
}
