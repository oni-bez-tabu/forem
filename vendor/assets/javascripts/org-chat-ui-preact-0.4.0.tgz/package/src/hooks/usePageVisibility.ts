import { useEffect, useState } from "preact/hooks";

/**
 * Web-specific hook do kontrolowania widoczności zakładki.
 * Dla środowisk bez `document` zwraca zawsze true.
 */
export function usePageVisibility(): boolean {
  const [isVisible, setIsVisible] = useState<boolean>(() => {
    if (typeof document === "undefined") {
      return true;
    }
    return document.visibilityState === "visible";
  });

  useEffect(() => {
    if (typeof document === "undefined") {
      return undefined;
    }
    const onChange = () => setIsVisible(document.visibilityState === "visible");
    document.addEventListener("visibilitychange", onChange);
    return () => {
      document.removeEventListener("visibilitychange", onChange);
    };
  }, []);

  return isVisible;
}

