import { MessageService, FirestoreAdapter as MessageFirestoreAdapter } from "./MessageService.js";
import {
  ChatClient as ChatClientContract,
  Message,
  Thread,
  SendMessageRequest,
  SendMessageInput,
  ThreadValidationError,
  CommunityRole,
  NotAuthorizedError,
  ChatGloballyBannedError,
  UserBannedInCommunityError,
  UserBlockedError,
  ThreadUserPreferences,
  UserProfile,
} from "./types.js";
// NOTE: RateLimitConfig usunięty - rate limiting jest wymuszany przez Cloud Functions

export interface AuthAdapter {
  signInWithCustomToken(token: string): Promise<{ uid: string; chatBanned?: boolean; chatBanReason?: string }>;
}

export interface ChatFirestoreAdapter extends MessageFirestoreAdapter {
  getThreadsForUser(userId: string): Promise<Thread[]>;
  subscribeToThreads(
    userId: string,
    onChange: (threads: Thread[]) => void
  ): () => void;
  getUnreadCountForUser(threadId: string, userId: string): Promise<number>;
  subscribeToTotalUnread(userId: string, onChange: (count: number) => void): () => void;
  setTyping(threadId: string, userId: string, isTyping: boolean): Promise<void>;
  subscribeToTyping(threadId: string, onChange: (userIds: string[]) => void): () => void;
  updateCommunityBan(threadId: string, userId: string, banned: boolean): Promise<void>;
  updateThreadMembership(input: {
    threadId: string;
    members: string[];
    acceptedBy?: string[];
    roles?: Record<string, CommunityRole> | undefined;
    bannedMembers?: string[];
  }): Promise<void>;
  updateUserBlockList(userId: string, targetUserId: string, block: boolean): Promise<void>;
  isUserBlocked(blockingUserId: string, blockedUserId: string): Promise<boolean>;
  decrementTotalUnread(userId: string, count: number, threadId?: string): Promise<void>;
  getThreadUserPrefs(threadId: string, userId: string): Promise<ThreadUserPreferences>;
  setThreadMuted(threadId: string, userId: string, muted: boolean): Promise<void>;
  subscribeToUserProfile(userId: string, onChange: (profile: UserProfile | undefined) => void): () => void;
  getThreadUnreadMap(userId: string): Promise<Record<string, number>>;
}

export interface MediaAdapter {
  uploadImage(file: File): Promise<string>;
  uploadImageBase64(data: { base64: string; mimeType: string; fileName: string }): Promise<string>;
}

type ChatClientDeps = {
  firebaseConfig: Record<string, unknown>;
  customToken: string;
  auth: AuthAdapter;
  firestore: ChatFirestoreAdapter;
  media?: MediaAdapter;
  // rateLimitConfig usunięty - rate limiting jest wymuszany przez Cloud Functions
  nowProvider?: () => number;
};

export class ChatClient implements ChatClientContract {
  private readonly firebaseConfig: Record<string, unknown>;
  private readonly customToken: string;
  private readonly auth: AuthAdapter;
  private readonly firestore: ChatFirestoreAdapter;
  private readonly media?: MediaAdapter;
  // rateLimitConfig usunięty
  private readonly nowProvider?: () => number;
  private messageService: MessageService | null = null;
  private userId: string | null = null;
  private chatBanned = false;

  constructor(params: ChatClientDeps) {
    this.firebaseConfig = params.firebaseConfig;
    this.customToken = params.customToken;
    this.auth = params.auth;
    this.firestore = params.firestore;
    this.media = params.media;
    // rateLimitConfig usunięty
    this.nowProvider = params.nowProvider;
  }

  async init(): Promise<void> {
    const authResult = await this.auth.signInWithCustomToken(this.customToken);
    this.userId = authResult.uid;
    this.chatBanned = Boolean(authResult.chatBanned);
    this.messageService = new MessageService({
      firestore: this.firestore,
      currentUserId: this.userId,
      chatBanned: this.chatBanned,
      // rateLimitConfig usunięty - CF wymusza limity
      nowProvider: this.nowProvider,
    });
  }

  async getThreads(): Promise<Thread[]> {
    this.assertInitialized();
    const threads = await this.firestore.getThreadsForUser(this.userId as string);
    const enriched = await this.enrichWithUnreadCount(threads);
    return this.sortAndFilterThreads(enriched);
  }

  subscribeThreads(onChange: (threads: Thread[]) => void): () => void {
    this.assertInitialized();
    let currentThreads: Thread[] = [];
    let refreshTimeout: ReturnType<typeof setTimeout> | null = null;
    
    const refreshUnreadCounts = async () => {
      if (currentThreads.length === 0) {
        return; // Nie odświeżaj jeśli nie ma wątków
      }
      // Odśwież unreadCount dla wszystkich wątków
      const enriched = await this.enrichWithUnreadCount(currentThreads);
      onChange(this.sortAndFilterThreads(enriched));
    };
    
    const scheduleRefresh = () => {
      // Anuluj poprzedni timeout jeśli istnieje
      if (refreshTimeout) {
        clearTimeout(refreshTimeout);
      }
      // Opóźnij odświeżenie o 100ms aby uniknąć zbyt częstych aktualizacji
      // (gdy odczytujesz wiele wiadomości naraz)
      refreshTimeout = setTimeout(() => {
        refreshTimeout = null;
        void refreshUnreadCounts();
      }, 100);
    };
    
    const unsubscribeThreads = this.firestore.subscribeToThreads(this.userId as string, async (threads) => {
      currentThreads = threads;
      const enriched = await this.enrichWithUnreadCount(threads);
      onChange(this.sortAndFilterThreads(enriched));
    });
    
    // Subskrybuj zmiany w totalUnread - gdy się zmienia, odśwież unreadCount dla wątków
    // (to jest workaround - gdy odczytujesz wiadomość, totalUnread się zmniejsza,
    // więc odświeżamy unreadCount dla wątków)
    const unsubscribeTotalUnread = this.firestore.subscribeToTotalUnread(this.userId as string, () => {
      scheduleRefresh();
    });
    
    return () => {
      unsubscribeThreads();
      unsubscribeTotalUnread();
      if (refreshTimeout) {
        clearTimeout(refreshTimeout);
      }
    };
  }

  openThread(
    threadId: string,
    onMessage: (message: Message) => void
  ): Promise<() => void> {
    this.assertInitialized();
    return this.messageService!.openThread(threadId, onMessage);
  }

  async getUnreadCount(threadId: string): Promise<number> {
    this.assertInitialized();
    return this.firestore.getUnreadCountForUser(threadId, this.userId as string);
  }

  async sendMessage(input: SendMessageRequest): Promise<Thread | void>;
  async sendMessage(threadId: string, message: SendMessageInput): Promise<void>;
  async sendMessage(
    inputOrThreadId: SendMessageRequest | string,
    legacyMessage?: SendMessageInput
  ): Promise<Thread | void> {
    this.assertInitialized();
    if (typeof inputOrThreadId === "string") {
      // Backward compatibility for old signature sendMessage(threadId, message)
      await this.messageService?.sendMessage({
        threadId: inputOrThreadId,
        message: legacyMessage ?? {},
      });
      return;
    }

    const result = await this.messageService?.sendMessage(inputOrThreadId);
    if ("threadType" in inputOrThreadId) {
      return result as Thread;
    }
    return;
  }

  async likeMessage(threadId: string, messageId: string): Promise<void> {
    this.assertInitialized();
    await this.messageService?.likeMessage(threadId, messageId);
  }

  async fetchMessages(
    threadId: string,
    options?: { limit?: number; beforeMessageId?: string }
  ): Promise<Message[]> {
    this.assertInitialized();
    return this.messageService!.fetchMessages(threadId, options);
  }

  async unlikeMessage(threadId: string, messageId: string): Promise<void> {
    this.assertInitialized();
    await this.messageService?.unlikeMessage(threadId, messageId);
  }

  async markAsRead(threadId: string, messageId: string): Promise<void> {
    this.assertInitialized();
    await this.messageService?.markAsRead(threadId, messageId);
  }

  async acceptThread(threadId: string): Promise<void> {
    this.assertInitialized();
    this.assertNotGloballyBanned();
    await this.messageService?.acceptThread(threadId);
  }

  async leaveThread(threadId: string): Promise<void> {
    this.assertInitialized();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    if (!thread.members.includes(this.userId as string)) {
      throw new ThreadValidationError("NOT_THREAD_MEMBER");
    }
    if (thread.type === "direct" || thread.type === "community") {
      throw new ThreadValidationError("LEAVE_NOT_ALLOWED");
    }
    const userId = this.userId as string;
    const unread = await this.firestore.getUnreadCountForUser(threadId, userId);
    const updatedMembers = thread.members.filter((m) => m !== userId);
    const updatedAccepted = (thread.acceptedBy ?? []).filter((m) => m !== userId);
    const updatedRoles =
      thread.roles !== undefined
        ? Object.fromEntries(Object.entries(thread.roles).filter(([id]) => id !== userId))
        : undefined;
    const updatedBanned = (thread.bannedMembers ?? []).filter((m) => m !== userId);

    await this.firestore.updateThreadMembership({
      threadId,
      members: updatedMembers,
      acceptedBy: updatedAccepted,
      roles: updatedRoles,
      bannedMembers: updatedBanned,
    });
    if (unread > 0) {
      await this.firestore.decrementTotalUnread(userId, unread, threadId);
    }
  }

  async banUserFromCommunity(threadId: string, targetUserId: string): Promise<void> {
    this.assertInitialized();
    this.assertNotGloballyBanned();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    this.assertCommunityModerationAllowed(thread);
    await this.firestore.updateCommunityBan(threadId, targetUserId, true);
  }

  async blockUser(targetUserId: string): Promise<void> {
    this.assertInitialized();
    await this.firestore.updateUserBlockList(this.userId as string, targetUserId, true);
  }

  async unblockUser(targetUserId: string): Promise<void> {
    this.assertInitialized();
    await this.firestore.updateUserBlockList(this.userId as string, targetUserId, false);
  }

  async isUserBlocked(targetUserId: string): Promise<boolean> {
    this.assertInitialized();
    return this.firestore.isUserBlocked(this.userId as string, targetUserId);
  }

  async unbanUserFromCommunity(threadId: string, targetUserId: string): Promise<void> {
    this.assertInitialized();
    this.assertNotGloballyBanned();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    this.assertCommunityModerationAllowed(thread);
    await this.firestore.updateCommunityBan(threadId, targetUserId, false);
  }

  subscribeTotalUnread(onChange: (count: number) => void): () => void {
    this.assertInitialized();
    return this.firestore.subscribeToTotalUnread(this.userId as string, onChange);
  }

  async setTyping(threadId: string, isTyping: boolean): Promise<void> {
    this.assertInitialized();
    this.assertNotGloballyBanned();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    this.assertTypingAllowed(thread);
    await this.firestore.setTyping(threadId, this.userId as string, isTyping);
  }

  subscribeTyping(threadId: string, onChange: (userIds: string[]) => void): () => void {
    this.assertInitialized();
    return this.firestore.subscribeToTyping(threadId, onChange);
  }

  async muteThread(threadId: string): Promise<void> {
    this.assertInitialized();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    this.assertThreadMember(thread);
    await this.firestore.setThreadMuted(threadId, this.userId as string, true);
  }

  async unmuteThread(threadId: string): Promise<void> {
    this.assertInitialized();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    this.assertThreadMember(thread);
    await this.firestore.setThreadMuted(threadId, this.userId as string, false);
  }

  async getThreadUserPrefs(threadId: string): Promise<ThreadUserPreferences> {
    this.assertInitialized();
    const thread = await this.firestore.getThread(threadId);
    if (!thread) {
      throw new ThreadValidationError("THREAD_NOT_FOUND");
    }
    this.assertThreadMember(thread);
    return this.firestore.getThreadUserPrefs(threadId, this.userId as string);
  }

  subscribeUserProfile(userId: string, onChange: (profile: UserProfile | undefined) => void): () => void {
    this.assertInitialized();
    return this.firestore.subscribeToUserProfile(userId, onChange);
  }

  async uploadImage(file: File): Promise<string> {
    this.assertInitialized();
    if (!this.media) {
      throw new Error("Image upload is not configured");
    }
    return this.media.uploadImage(file);
  }

  async uploadImageBase64(data: { base64: string; mimeType: string; fileName: string }): Promise<string> {
    this.assertInitialized();
    if (!this.media) {
      throw new Error("Image upload is not configured");
    }
    return this.media.uploadImageBase64(data);
  }

  private async enrichWithUnreadCount(threads: Thread[]): Promise<Thread[]> {
    const userId = this.userId as string;
    let threadUnreadMap: Record<string, number> = {};
    try {
      threadUnreadMap = await this.firestore.getThreadUnreadMap(userId);
    } catch {
      threadUnreadMap = {};
    }

    const withCounts = await Promise.all(
      threads.map(async (thread) => {
        const mapped = threadUnreadMap[thread.id];
        if (mapped !== undefined) {
          return { ...thread, unreadCount: Math.max(0, mapped) };
        }
        const unreadCount = await this.firestore.getUnreadCountForUser(thread.id, userId);
        return { ...thread, unreadCount };
      })
    );
    return withCounts;
  }

  private sortAndFilterThreads(threads: Thread[]): Thread[] {
    return [...threads].sort((a, b) => {
      const aTime = a.lastMessage?.createdAt ?? a.createdAt;
      const bTime = b.lastMessage?.createdAt ?? b.createdAt;

      if (aTime.seconds === bTime.seconds) {
        if (aTime.nanoseconds === bTime.nanoseconds) {
          return a.id.localeCompare(b.id);
        }
        return bTime.nanoseconds - aTime.nanoseconds;
      }
      return bTime.seconds - aTime.seconds;
    });
  }

  private assertInitialized(): void {
    if (!this.userId || !this.messageService) {
      throw new Error("ChatClient not initialized");
    }
  }

  private assertNotGloballyBanned(): void {
    if (this.chatBanned) {
      throw new ChatGloballyBannedError();
    }
  }

  private assertThreadMember(thread: Thread): void {
    if (!thread.members.includes(this.userId as string)) {
      throw new ThreadValidationError("NOT_THREAD_MEMBER");
    }
  }

  private assertCommunityModerationAllowed(thread: Thread): void {
    if (thread.type !== "community") {
      throw new NotAuthorizedError();
    }
    const role = thread.roles?.[this.userId as string];
    if (role !== "owner" && role !== "moderator") {
      throw new NotAuthorizedError();
    }
  }

  private assertTypingAllowed(thread: Thread): void {
    if (!thread.members.includes(this.userId as string)) {
      throw new ThreadValidationError("NOT_THREAD_MEMBER");
    }
    if (thread.type === "group" && !(thread.acceptedBy ?? []).includes(this.userId as string)) {
      throw new ThreadValidationError("CONSENT_REQUIRED");
    }
    if (thread.type === "community" && (thread.bannedMembers ?? []).includes(this.userId as string)) {
      throw new UserBannedInCommunityError();
    }
    if (
      thread.type === "direct" &&
      !thread.directUnlocked &&
      thread.lastMessage?.senderId === (this.userId as string)
    ) {
      throw new ThreadValidationError("WAIT_FOR_REPLY");
    }
  }
}

