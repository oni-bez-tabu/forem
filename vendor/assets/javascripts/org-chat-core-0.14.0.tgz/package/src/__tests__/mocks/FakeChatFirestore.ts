import { ChatFirestoreAdapter } from "../../ChatClient.js";
import { CommunityRole, Message, Thread, Timestamp, UserProfile } from "../../types.js";

const fixedTimestamp: Timestamp = { seconds: 1, nanoseconds: 2 };

export class FakeChatFirestore implements ChatFirestoreAdapter {
  private threads = new Map<string, Thread>();
  private messages = new Map<string, Map<string, Message>>();
  private listeners = new Map<string, Array<(m: Message) => void>>();
  private counter = 0;
  private totalUnread = new Map<string, number>();
  private unreadListeners = new Map<string, Array<(count: number) => void>>();
  private blocks = new Map<string, Set<string>>();

  async consumeRateLimit(): Promise<{ allowed: true }> {
    return { allowed: true };
  }

  constructor(threads: Thread[] = []) {
    threads.forEach((t) => this.threads.set(t.id, { ...t, unreadCount: t.unreadCount ?? 0 }));
  }

  async getThreadsForUser(userId: string): Promise<Thread[]> {
    return Array.from(this.threads.values()).filter((t) => t.members.includes(userId));
  }

  async getThread(threadId: string): Promise<Thread | null> {
    return this.threads.get(threadId) ?? null;
  }

  async findDirectThreadByMembers(memberA: string, memberB: string): Promise<Thread | null> {
    const found = Array.from(this.threads.values()).find(
      (t) => t.type === "direct" && t.members.includes(memberA) && t.members.includes(memberB)
    );
    return found ?? null;
  }

  async createThreadWithMessageAtomic(input: {
    thread: {
      type: Thread["type"];
      members: string[];
      name?: string;
      acceptedBy?: string[];
      directUnlocked?: boolean;
      roles?: Record<string, CommunityRole>;
      bannedMembers?: string[];
    };
    message: {
      threadId: string;
      senderId: string;
      clientMessageId?: string;
      type: "text" | "image";
      text?: string;
      imageUrl?: string;
      replyTo?: { messageId: string; senderId: string; text?: string; imageUrl?: string };
    };
  }): Promise<{ thread: Thread; message: Message }> {
    const id = input.message.threadId || `t-${this.threads.size + 1}`;
    const thread: Thread = {
      id,
      type: input.thread.type,
      members: input.thread.members,
      createdAt: fixedTimestamp,
      name: input.thread.name,
      acceptedBy: input.thread.acceptedBy,
      directUnlocked: input.thread.directUnlocked,
      unreadCount: 0,
      roles: input.thread.roles,
      bannedMembers: input.thread.bannedMembers,
    };
    this.threads.set(id, thread);
    const message = await this.addMessageAtomic(
      {
        threadId: id,
        senderId: input.message.senderId,
        type: input.message.type,
        text: input.message.text,
        imageUrl: input.message.imageUrl,
        replyTo: input.message.replyTo,
      },
      { threadUpdates: { directUnlocked: thread.directUnlocked } }
    );
    thread.lastMessage = {
      id: message.id,
      senderId: message.senderId,
      text: message.text,
      imageUrl: message.imageUrl,
      createdAt: message.createdAt,
    };
    this.threads.set(id, thread);
    return { thread, message };
  }

  subscribeToMessages(threadId: string, onMessage: (message: Message) => void): () => void {
    const list = this.listeners.get(threadId) ?? [];
    this.listeners.set(threadId, [...list, onMessage]);
    return () => {
      const current = this.listeners.get(threadId) ?? [];
      this.listeners.set(threadId, current.filter((cb) => cb !== onMessage));
    };
  }

  private emit(threadId: string, message: Message): void {
    (this.listeners.get(threadId) ?? []).forEach((cb) => cb(message));
  }

  async addMessageAtomic(
    input: {
      threadId: string;
      senderId: string;
      type: "text" | "image";
      text?: string;
      imageUrl?: string;
      replyTo?: { messageId: string; senderId: string; text?: string; imageUrl?: string };
    },
    options?: {
      threadUpdates?: { directUnlocked?: boolean; acceptedByAdd?: string[] };
      unreadFanout?: { recipients: string[]; senderId: string };
    }
  ): Promise<Message> {
    const id = `m-${this.counter++}`;
    const message: Message = {
      id,
      threadId: input.threadId,
      senderId: input.senderId,
      type: input.type,
      text: input.text,
      imageUrl: input.imageUrl,
      replyTo: input.replyTo,
      likes: [],
      readBy: [input.senderId],
      createdAt: fixedTimestamp,
    };
    if (!this.messages.has(input.threadId)) {
      this.messages.set(input.threadId, new Map());
    }
    this.messages.get(input.threadId)?.set(id, message);
    this.emit(input.threadId, message);
    const thread = this.threads.get(input.threadId);
    if (thread) {
      thread.lastMessage = {
        id: message.id,
        senderId: message.senderId,
        text: message.text,
        imageUrl: message.imageUrl,
        createdAt: message.createdAt,
      };
      if (options?.threadUpdates?.directUnlocked !== undefined) {
        thread.directUnlocked = options.threadUpdates.directUnlocked;
      }
      if (options?.threadUpdates?.acceptedByAdd) {
        const accepted = new Set(thread.acceptedBy ?? []);
        options.threadUpdates.acceptedByAdd.forEach((u) => accepted.add(u));
        thread.acceptedBy = Array.from(accepted);
      }
      if (options?.unreadFanout?.recipients?.length) {
        options.unreadFanout.recipients.forEach((uid) => {
          this.totalUnread.set(uid, (this.totalUnread.get(uid) ?? 0) + 1);
          (this.unreadListeners.get(uid) ?? []).forEach((cb) => cb(this.totalUnread.get(uid) ?? 0));
        });
      }
    }
    return message;
  }

  async getMessage(threadId: string, messageId: string): Promise<Message | null> {
    return this.messages.get(threadId)?.get(messageId) ?? null;
  }

  async listMessages(threadId: string, options: { limit: number; beforeMessageId?: string }): Promise<Message[]> {
    const all = Array.from(this.messages.get(threadId)?.values() ?? []);
    const sortedDesc = all.sort((a, b) => {
      const aMs = a.createdAt.seconds * 1000 + a.createdAt.nanoseconds / 1_000_000;
      const bMs = b.createdAt.seconds * 1000 + b.createdAt.nanoseconds / 1_000_000;
      if (aMs === bMs) {
        return b.id.localeCompare(a.id);
      }
      return bMs - aMs;
    });
    const startIndex = options.beforeMessageId
      ? sortedDesc.findIndex((m) => m.id === options.beforeMessageId) + 1
      : 0;
    const page = sortedDesc.slice(startIndex, startIndex + options.limit);
    return [...page].reverse();
  }

  async appendMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) throw new Error("Message not found");
    if (!message.likes.includes(userId)) {
      message.likes = [...message.likes, userId];
    }
  }

  async removeMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) throw new Error("Message not found");
    if (message.likes.includes(userId)) {
      message.likes = message.likes.filter((id) => id !== userId);
    }
  }

  async appendMessageReadBy(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) throw new Error("Message not found");
    if (!message.readBy.includes(userId)) {
      message.readBy = [...message.readBy, userId];
      this.totalUnread.set(userId, Math.max(0, (this.totalUnread.get(userId) ?? 0) - 1));
      (this.unreadListeners.get(userId) ?? []).forEach((cb) => cb(this.totalUnread.get(userId) ?? 0));
    }
  }

  async appendThreadAcceptedBy(threadId: string, userId: string): Promise<void> {
    const thread = this.threads.get(threadId);
    if (!thread) throw new Error("Thread not found");
    const accepted = new Set(thread.acceptedBy ?? []);
    accepted.add(userId);
    thread.acceptedBy = Array.from(accepted);
    this.threads.set(threadId, thread);
  }

  async updateCommunityBan(threadId: string, userId: string, banned: boolean): Promise<void> {
    const thread = this.threads.get(threadId);
    if (!thread) throw new Error("Thread not found");
    const current = new Set(thread.bannedMembers ?? []);
    if (banned) {
      current.add(userId);
    } else {
      current.delete(userId);
    }
    this.threads.set(threadId, { ...thread, bannedMembers: Array.from(current) });
  }

  async updateThreadMembership(input: {
    threadId: string;
    members: string[];
    acceptedBy?: string[];
    roles?: Record<string, CommunityRole>;
    bannedMembers?: string[];
  }): Promise<void> {
    const thread = this.threads.get(input.threadId);
    if (!thread) throw new Error("Thread not found");
    this.threads.set(input.threadId, {
      ...thread,
      members: input.members,
      acceptedBy: input.acceptedBy ?? thread.acceptedBy,
      roles: input.roles,
      bannedMembers: input.bannedMembers ?? thread.bannedMembers,
    });
  }

  async setTyping(): Promise<void> {
    return;
  }

  subscribeToTyping(_threadId: string, _onChange: (userIds: string[]) => void): () => void {
    return () => {};
  }

  subscribeToTotalUnread(userId: string, onChange: (count: number) => void): () => void {
    const list = this.unreadListeners.get(userId) ?? [];
    this.unreadListeners.set(userId, [...list, onChange]);
    onChange(this.totalUnread.get(userId) ?? 0);
    return () => {
      const current = this.unreadListeners.get(userId) ?? [];
      this.unreadListeners.set(userId, current.filter((cb) => cb !== onChange));
    };
  }

  async decrementTotalUnread(userId: string, count: number, _threadId?: string): Promise<void> {
    if (count <= 0) return;
    this.totalUnread.set(userId, Math.max(0, (this.totalUnread.get(userId) ?? 0) - count));
    (this.unreadListeners.get(userId) ?? []).forEach((cb) => cb(this.totalUnread.get(userId) ?? 0));
  }

  async getThreadUnreadMap(_userId: string): Promise<Record<string, number>> {
    return {};
  }

  async updateUserBlockList(userId: string, targetUserId: string, block: boolean): Promise<void> {
    const set = this.blocks.get(userId) ?? new Set<string>();
    if (block) {
      set.add(targetUserId);
    } else {
      set.delete(targetUserId);
    }
    this.blocks.set(userId, set);
  }

  async isUserBlocked(blockingUserId: string, blockedUserId: string): Promise<boolean> {
    return (this.blocks.get(blockingUserId) ?? new Set<string>()).has(blockedUserId);
  }

  async getUnreadCountForUser(threadId: string, userId: string): Promise<number> {
    const messages = this.messages.get(threadId);
    if (!messages) return 0;
    let unread = 0;
    messages.forEach((m) => {
      if (m.senderId !== userId && !m.readBy.includes(userId)) {
        unread += 1;
      }
    });
    return unread;
  }

  subscribeToThreads(_userId: string, onChange: (threads: Thread[]) => void): () => void {
    onChange(Array.from(this.threads.values()));
    return () => {};
  }

  subscribeToUserProfile(_userId: string, onChange: (profile: UserProfile | undefined) => void): () => void {
    onChange(undefined);
    return () => {};
  }

  async getThreadUserPrefs(threadId: string, userId: string): Promise<{ threadId: string; userId: string; muted: boolean }> {
    return { threadId, userId, muted: false };
  }

  async resolveUsernamesToIds(usernames: string[]): Promise<Map<string, string>> {
    const map = new Map<string, string>();
    usernames.forEach((u) => map.set(u, u));
    return map;
  }

  async setThreadMuted(): Promise<void> {
    return;
  }
}
