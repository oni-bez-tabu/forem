import { AuthAdapter } from "../../ChatClient.js";

export class FakeAuth implements AuthAdapter {
  constructor(private readonly uid: string, private readonly chatBanned = false) {}

  async signInWithCustomToken(): Promise<{ uid: string; chatBanned?: boolean }> {
    return { uid: this.uid, chatBanned: this.chatBanned };
  }
}
