import {
  FirestoreAdapter,
  RateLimitConsumeInput,
  RateLimitConsumeResult,
} from "../../MessageService.js";
import {
  LastMessage,
  Message,
  MessageType,
  ReplyTo,
  Timestamp,
  Thread,
} from "../../types.js";

// NOTE: Rate limiting jest wymuszany przez Cloud Functions, nie przez klienta

export class InMemoryFirestoreAdapter implements FirestoreAdapter {
  private counter = 0;
  private readonly threads = new Map<string, Thread>();
  private readonly messages = new Map<string, Map<string, Message>>();
  private readonly lastMessages = new Map<string, LastMessage>();
  private readonly timestamp: Timestamp;
  private readonly blocks = new Map<string, Set<string>>();

  constructor(params: { now: Timestamp }) {
    this.timestamp = params.now;
  }

  async addMessageAtomic(
    input: {
      threadId: string;
      senderId: string;
      clientMessageId?: string;
      type: MessageType;
      text?: string;
      imageUrl?: string;
      replyTo?: ReplyTo;
    },
    options?: { threadUpdates?: { directUnlocked?: boolean; acceptedByAdd?: string[] } }
  ): Promise<Message> {
    const id = input.clientMessageId ?? `msg-${this.counter++}`;
    const existing = this.messages.get(input.threadId)?.get(id);
    if (existing) {
      return existing;
    }
    const message: Message = {
      id,
      threadId: input.threadId,
      senderId: input.senderId,
      clientMessageId: input.clientMessageId,
      type: input.type,
      text: input.text,
      imageUrl: input.imageUrl,
      replyTo: input.replyTo,
      likes: [],
      readBy: [input.senderId],
      createdAt: this.timestamp,
    };
    if (!this.messages.has(input.threadId)) {
      this.messages.set(input.threadId, new Map());
    }
    this.messages.get(input.threadId)?.set(id, message);
    this.lastMessages.set(input.threadId, {
      id: message.id,
      senderId: message.senderId,
      text: message.text,
      imageUrl: message.imageUrl,
      createdAt: message.createdAt,
    });
    const thread = this.threads.get(input.threadId);
    if (thread) {
      thread.lastMessage = this.lastMessages.get(input.threadId);
      if (options?.threadUpdates?.directUnlocked !== undefined) {
        thread.directUnlocked = options.threadUpdates.directUnlocked;
      }
      if (options?.threadUpdates?.acceptedByAdd) {
        const currentAccepted = new Set(thread.acceptedBy ?? []);
        options.threadUpdates.acceptedByAdd.forEach((u) => currentAccepted.add(u));
        thread.acceptedBy = Array.from(currentAccepted);
      }
      this.threads.set(thread.id, thread);
    }
    return message;
  }

  async getMessage(threadId: string, messageId: string): Promise<Message | null> {
    const threadMessages = this.messages.get(threadId);
    return threadMessages?.get(messageId) ?? null;
  }

  async listMessages(
    threadId: string,
    options: { limit: number; beforeMessageId?: string }
  ): Promise<Message[]> {
    const all = Array.from(this.messages.get(threadId)?.values() ?? []);
    const sortedDesc = all.sort((a, b) => {
      const aMs = a.createdAt.seconds * 1000 + a.createdAt.nanoseconds / 1_000_000;
      const bMs = b.createdAt.seconds * 1000 + b.createdAt.nanoseconds / 1_000_000;
      if (aMs === bMs) {
        return b.id.localeCompare(a.id) * -1;
      }
      return bMs - aMs;
    });
    const startIndex = options.beforeMessageId
      ? sortedDesc.findIndex((m) => m.id === options.beforeMessageId) + 1
      : 0;
    const page = sortedDesc.slice(startIndex, startIndex + options.limit);
    return [...page].reverse();
  }

  async appendMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) {
      throw new Error("Message not found");
    }
    if (!message.likes.includes(userId)) {
      message.likes = [...message.likes, userId];
    }
  }

  async removeMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) {
      throw new Error("Message not found");
    }
    if (message.likes.includes(userId)) {
      message.likes = message.likes.filter((id: string) => id !== userId);
    }
  }

  async appendMessageReadBy(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) {
      throw new Error("Message not found");
    }
    if (!message.readBy.includes(userId)) {
      message.readBy = [...message.readBy, userId];
    }
  }

  getStoredMessage(threadId: string, messageId: string): Message | undefined {
    return this.messages.get(threadId)?.get(messageId);
  }

  getLastMessage(threadId: string): LastMessage | undefined {
    return this.lastMessages.get(threadId);
  }

  seedMessage(threadId: string, message: Message): void {
    if (!this.messages.has(threadId)) {
      this.messages.set(threadId, new Map());
    }
    this.messages.get(threadId)?.set(message.id, message);
  }

  async createThreadWithMessageAtomic(input: {
    thread: { type: "direct" | "group" | "community"; members: string[]; name?: string; acceptedBy?: string[]; directUnlocked?: boolean };
    message: {
      threadId: string;
      senderId: string;
      clientMessageId?: string;
      type: MessageType;
      text?: string;
      imageUrl?: string;
      replyTo?: ReplyTo;
    };
  }): Promise<{ thread: Thread; message: Message }> {
    const threadId = `thread-${this.threads.size + 1}`;
    const thread: Thread = {
      id: threadId,
      type: input.thread.type,
      members: input.thread.members,
      createdAt: this.timestamp,
      name: input.thread.name,
      acceptedBy: input.thread.acceptedBy,
      directUnlocked: input.thread.directUnlocked,
      unreadCount: 0,
    };
    this.threads.set(threadId, thread);
    const message = await this.addMessageAtomic(
      {
        threadId,
        senderId: input.message.senderId,
        clientMessageId: input.message.clientMessageId,
        type: input.message.type,
        text: input.message.text,
        imageUrl: input.message.imageUrl,
        replyTo: input.message.replyTo,
      },
      { threadUpdates: { directUnlocked: thread.directUnlocked } }
    );
    thread.lastMessage = this.lastMessages.get(threadId);
    this.threads.set(threadId, thread);
    return { thread, message };
  }

  async getThread(threadId: string): Promise<Thread | null> {
    return this.threads.get(threadId) ?? null;
  }

  async findDirectThreadByMembers(memberA: string, memberB: string): Promise<Thread | null> {
    const thread = Array.from(this.threads.values()).find(
      (t) => t.type === "direct" && t.members.includes(memberA) && t.members.includes(memberB)
    );
    return thread ?? null;
  }

  seedThread(thread: Thread & { unreadCount?: number }): void {
    this.threads.set(thread.id, { ...thread, unreadCount: thread.unreadCount ?? 0 });
  }

  async appendThreadAcceptedBy(threadId: string, userId: string): Promise<void> {
    const thread = this.threads.get(threadId);
    if (!thread) {
      throw new Error("Thread not found");
    }
    const current = new Set(thread.acceptedBy ?? []);
    current.add(userId);
    thread.acceptedBy = Array.from(current);
    this.threads.set(threadId, thread);
  }

  subscribeToMessages(threadId: string, onMessage: (message: Message) => void): () => void {
    const existing = Array.from(this.messages.get(threadId)?.values() ?? []);
    existing
      .sort((a, b) => {
        if (a.createdAt.seconds === b.createdAt.seconds) {
          return a.createdAt.nanoseconds - b.createdAt.nanoseconds;
        }
        return a.createdAt.seconds - b.createdAt.seconds;
      })
      .forEach((msg) => onMessage(msg));
    return () => {};
  }

  async isUserBlocked(blockingUserId: string, blockedUserId: string): Promise<boolean> {
    return (this.blocks.get(blockingUserId) ?? new Set<string>()).has(blockedUserId);
  }

  block(blockingUserId: string, blockedUserId: string): void {
    const set = this.blocks.get(blockingUserId) ?? new Set<string>();
    set.add(blockedUserId);
    this.blocks.set(blockingUserId, set);
  }

  async getThreadUserPrefs(threadId: string, userId: string): Promise<{ threadId: string; userId: string; muted: boolean }> {
    return { threadId, userId, muted: false };
  }

  async resolveUsernamesToIds(usernames: string[]): Promise<Map<string, string>> {
    const map = new Map<string, string>();
    usernames.forEach((u) => map.set(u, u));
    return map;
  }

  async setThreadMuted(): Promise<void> {
    return;
  }

  async consumeRateLimit(_input: RateLimitConsumeInput): Promise<RateLimitConsumeResult> {
    // NOTE: Rate limiting jest wymuszany przez Cloud Functions, nie przez klienta
    return { allowed: true };
  }
}
