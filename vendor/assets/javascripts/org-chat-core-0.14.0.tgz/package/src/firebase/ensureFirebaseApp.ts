import { FirebaseApp, getApp, getApps, initializeApp } from "firebase/app";

export function ensureFirebaseApp(config: Record<string, unknown>): FirebaseApp {
  const existing = getApps();
  if (existing.length > 0) {
    return getApp();
  }
  return initializeApp(config);
}
