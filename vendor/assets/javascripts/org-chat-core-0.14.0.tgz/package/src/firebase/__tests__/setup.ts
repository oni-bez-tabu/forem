/**
 * Setup for Firebase Web SDK tests with Firestore emulator
 * Uses Admin SDK for test setup and authenticates client SDK
 */
import { initializeApp, FirebaseApp, deleteApp, getApps } from "firebase/app";
import { getFirestore, connectFirestoreEmulator, Firestore } from "firebase/firestore";
import { getAuth, connectAuthEmulator, signInWithCustomToken, Auth } from "firebase/auth";
import * as admin from "firebase-admin";

export const testConfig = {
  projectId: "chat-sdk-33ade",
  firestoreHost: "localhost",
  firestorePort: 8080,
  authHost: "localhost",
  authPort: 9099,
  testUserId: "test-user-123",
};

let testApp: FirebaseApp | null = null;
let testDb: Firestore | null = null;
let testAuth: Auth | null = null;
let adminDb: admin.firestore.Firestore | null = null;
let adminAuth: admin.auth.Auth | null = null;

/**
 * Initialize Firebase app and Firestore with emulator
 * Authenticates a test user
 */
export async function setupTestEnvironment(): Promise<{
  app: FirebaseApp;
  db: Firestore;
  auth: Auth;
  adminDb: admin.firestore.Firestore;
  adminAuth: admin.auth.Auth;
}> {
  if (testApp && testDb && testAuth && adminDb && adminAuth) {
    return { app: testApp, db: testDb, auth: testAuth, adminDb, adminAuth };
  }

  // Clean up any existing apps
  const existingApps = getApps();
  existingApps.forEach((app) => deleteApp(app));

  // Set emulator environment variables BEFORE initializing Admin SDK
  process.env.FIRESTORE_EMULATOR_HOST = `${testConfig.firestoreHost}:${testConfig.firestorePort}`;
  process.env.FIREBASE_AUTH_EMULATOR_HOST = `${testConfig.authHost}:${testConfig.authPort}`;

  // Initialize admin app
  if (admin.apps.length === 0) {
    admin.initializeApp({ projectId: testConfig.projectId });
  }
  adminDb = admin.firestore();
  adminAuth = admin.auth();

  // Initialize client app (apiKey required even for emulator)
  testApp = initializeApp({
    projectId: testConfig.projectId,
    apiKey: "fake-api-key-for-testing",
  }, "test-app");
  testDb = getFirestore(testApp);
  testAuth = getAuth(testApp);

  // Connect to emulators BEFORE auth operations
  connectFirestoreEmulator(testDb, testConfig.firestoreHost, testConfig.firestorePort);
  connectAuthEmulator(testAuth, `http://${testConfig.authHost}:${testConfig.authPort}`, { disableWarnings: true });

  // Create and sign in test user using emulator
  const customToken = await adminAuth.createCustomToken(testConfig.testUserId);
  await signInWithCustomToken(testAuth, customToken);

  return { app: testApp, db: testDb, auth: testAuth, adminDb, adminAuth };
}

/**
 * Clear all Firestore data using emulator REST API
 * More reliable than manually deleting collections
 */
export async function clearFirestore(): Promise<void> {
  try {
    const response = await fetch(
      `http://${testConfig.firestoreHost}:${testConfig.firestorePort}/emulator/v1/projects/${testConfig.projectId}/databases/(default)/documents`,
      { method: "DELETE" }
    );

    if (!response.ok) {
      throw new Error(`Failed to clear Firestore: ${response.statusText}`);
    }
  } catch (error) {
    console.error("Error clearing Firestore:", error);
    throw error;
  }
}

/**
 * Helper to wait for async operations
 */
export function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
