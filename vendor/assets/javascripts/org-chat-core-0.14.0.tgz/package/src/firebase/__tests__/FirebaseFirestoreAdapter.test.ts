/**
 * Integration tests for FirebaseFirestoreAdapter
 * Tests adapter methods with Firebase emulator
 * Uses Admin SDK for setup to bypass security rules
 */
import { describe, it, expect, beforeAll, afterEach } from "vitest";
import { Firestore } from "firebase/firestore";
import * as admin from "firebase-admin";
import { FirebaseFirestoreAdapter } from "../FirebaseFirestoreAdapter.js";
import { setupTestEnvironment, clearFirestore, wait, testConfig } from "./setup.js";

let db: Firestore;
let adminDb: admin.firestore.Firestore;
let adapter: FirebaseFirestoreAdapter;

// Use authenticated user ID for tests that require auth
const TEST_USER_ID = testConfig.testUserId;

beforeAll(async () => {
  const env = await setupTestEnvironment();
  db = env.db;
  adminDb = env.adminDb;
  adapter = new FirebaseFirestoreAdapter(db);
});

afterEach(async () => {
  await clearFirestore();
  await wait(500); // Wait for deletions to propagate in emulator
});

describe("FirebaseFirestoreAdapter", () => {
  describe("getThreadsForUser", () => {
    it("zwraca tylko wątki użytkownika", async () => {
      const userId = TEST_USER_ID; // Use authenticated user
      const otherUserId = "user-2";

      // Create userThreads for authenticated user using Admin SDK
      await adminDb.collection("userThreads").doc(userId).collection("threads").doc("thread-1").set({
        id: "thread-1",
        type: "direct",
        members: [userId, otherUserId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await adminDb.collection("userThreads").doc(userId).collection("threads").doc("thread-2").set({
        id: "thread-2",
        type: "group",
        members: [userId, otherUserId, "user-3"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // Create userThreads for other user (should not be returned)
      await adminDb.collection("userThreads").doc(otherUserId).collection("threads").doc("thread-other").set({
        id: "thread-other",
        type: "direct",
        members: [otherUserId, "user-3"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const threads = await adapter.getThreadsForUser(userId);

      expect(threads.length).toBe(2);
      expect(threads.map(t => t.id).sort()).toEqual(["thread-1", "thread-2"]);
      expect(threads.every(t => t.members.includes(userId))).toBe(true);
    });

    it("zwraca pustą tablicę gdy użytkownik nie ma wątków", async () => {
      const userId = TEST_USER_ID;

      const threads = await adapter.getThreadsForUser(userId);

      expect(threads).toEqual([]);
    });

    it("zwraca wątki z pełnymi danymi (lastMessage, unreadCount)", async () => {
      const userId = TEST_USER_ID;

      await adminDb.collection("userThreads").doc(userId).collection("threads").doc("thread-full").set({
        id: "thread-full",
        type: "direct",
        members: [userId, "user-2"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        lastMessage: {
          id: "msg-1",
          senderId: "user-2",
          text: "Hello!",
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        },
        unreadCount: 3,
      });

      await wait(500);

      const threads = await adapter.getThreadsForUser(userId);

      expect(threads.length).toBe(1);
      expect(threads[0].lastMessage).toBeDefined();
      expect(threads[0].lastMessage?.text).toBe("Hello!");
      expect(threads[0].unreadCount).toBe(3);
    });
  });

  describe("subscribeToThreads", () => {
    it("otrzymuje istniejące wątki przy subskrypcji", async () => {
      const userId = TEST_USER_ID;

      // Create existing thread
      await adminDb.collection("userThreads").doc(userId).collection("threads").doc("thread-existing").set({
        id: "thread-existing",
        type: "direct",
        members: [userId, "user-2"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const received: any[] = [];
      const unsubscribe = adapter.subscribeToThreads(userId, (threads) => {
        received.push(threads);
      });

      await wait(1000);

      expect(received.length).toBeGreaterThan(0);
      expect(received[0].length).toBe(1);
      expect(received[0][0].id).toBe("thread-existing");

      unsubscribe();
    });

    it("otrzymuje aktualizacje w czasie rzeczywistym", async () => {
      const userId = TEST_USER_ID;

      const received: any[] = [];
      const unsubscribe = adapter.subscribeToThreads(userId, (threads) => {
        received.push([...threads]);
      });

      await wait(500);

      // Add new thread after subscription
      await adminDb.collection("userThreads").doc(userId).collection("threads").doc("thread-new").set({
        id: "thread-new",
        type: "group",
        members: [userId, "user-2", "user-3"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(1000);

      // Should receive at least 2 snapshots: initial (empty) and after add
      expect(received.length).toBeGreaterThanOrEqual(2);
      const lastSnapshot = received[received.length - 1];
      expect(lastSnapshot.length).toBe(1);
      expect(lastSnapshot[0].id).toBe("thread-new");

      unsubscribe();
    });
  });

  describe("addMessageAtomic", () => {
    // NOTE: These tests use Admin SDK to create messages because in production,
    // message creation is validated by Cloud Functions, not client-side security rules
    it("odczytuje wiadomość tekstową z wątku", async () => {
      const threadId = "thread-read-msg";
      const senderId = TEST_USER_ID;
      const messageId = "test-msg-1";

      // Create message using Admin SDK
      await adminDb.collection("messages").doc(threadId).collection("items").doc(messageId).set({
        threadId,
        senderId,
        type: "text",
        text: "Hello world!",
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      // Verify adapter can read it
      const message = await adapter.getMessage(threadId, messageId);

      expect(message).toBeDefined();
      expect(message?.text).toBe("Hello world!");
      expect(message?.senderId).toBe(senderId);
      expect(message?.type).toBe("text");
      expect(message?.readBy).toEqual([senderId]);
      expect(message?.likes).toEqual([]);
    });

    it("używa clientMessageId gdy podany", async () => {
      const threadId = "thread-client-id";
      const senderId = TEST_USER_ID;
      const clientMessageId = "client-msg-123";

      // Create message using Admin SDK with clientMessageId
      await adminDb.collection("messages").doc(threadId).collection("items").doc(clientMessageId).set({
        threadId,
        senderId,
        type: "text",
        text: "With client ID",
        clientMessageId,
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      // Verify adapter can read it with clientMessageId
      const message = await adapter.getMessage(threadId, clientMessageId);

      expect(message).toBeDefined();
      expect(message?.id).toBe(clientMessageId);
      expect(message?.clientMessageId).toBe(clientMessageId);
      expect(message?.text).toBe("With client ID");
    });

    it("dodaje wiadomość z obrazem", async () => {
      const threadId = "thread-image";
      const senderId = TEST_USER_ID;
      const messageId = "msg-image";

      // Create message with image using Admin SDK
      await adminDb.collection("messages").doc(threadId).collection("items").doc(messageId).set({
        threadId,
        senderId,
        type: "image",
        text: "Check this out",
        imageUrl: "https://example.com/image.jpg",
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      // Verify adapter can read image message
      const message = await adapter.getMessage(threadId, messageId);

      expect(message).toBeDefined();
      expect(message?.type).toBe("image");
      expect(message?.text).toBe("Check this out");
      expect(message?.imageUrl).toBe("https://example.com/image.jpg");
    });

    it("dodaje wiadomość z replyTo", async () => {
      const threadId = "thread-reply";
      const senderId = TEST_USER_ID;
      const messageId = "msg-reply";

      // Create message with replyTo using Admin SDK
      await adminDb.collection("messages").doc(threadId).collection("items").doc(messageId).set({
        threadId,
        senderId,
        type: "text",
        text: "Reply text",
        replyTo: {
          messageId: "original-msg",
          senderId: "user-2",
          text: "Original message",
        },
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      // Verify adapter can read message with replyTo
      const message = await adapter.getMessage(threadId, messageId);

      expect(message).toBeDefined();
      expect(message?.replyTo).toBeDefined();
      expect(message?.replyTo?.messageId).toBe("original-msg");
      expect(message?.replyTo?.senderId).toBe("user-2");
      expect(message?.replyTo?.text).toBe("Original message");
    });

    it("dodaje wiadomość z mentions", async () => {
      const threadId = "thread-mentions";
      const senderId = TEST_USER_ID;
      const messageId = "msg-mentions";

      // Create message with mentions using Admin SDK
      await adminDb.collection("messages").doc(threadId).collection("items").doc(messageId).set({
        threadId,
        senderId,
        type: "text",
        text: "@user-2 hello!",
        mentions: ["user-2"],
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      // Verify adapter can read message with mentions
      const message = await adapter.getMessage(threadId, messageId);

      expect(message).toBeDefined();
      expect(message?.mentions).toEqual(["user-2"]);
      expect(message?.text).toBe("@user-2 hello!");
    });
  });

  describe("listMessages", () => {
    it("zwraca wiadomości w kolejności rosnącej (od najstarszej w paczce)", async () => {
      const threadId = "thread-list";
      const senderId = TEST_USER_ID;

      // Create 5 messages
      for (let i = 1; i <= 5; i++) {
        await adminDb.collection("messages").doc(threadId).collection("items").doc(`msg-${i}`).set({
          threadId,
          senderId,
          type: "text",
          text: `Message ${i}`,
          likes: [],
          readBy: [senderId],
          createdAt: admin.firestore.Timestamp.fromMillis(Date.now() + i * 1000),
        });
      }

      await wait(500);

      const messages = await adapter.listMessages(threadId, { limit: 10 });

      expect(messages.length).toBe(5);
      expect(messages[0].text).toBe("Message 1");
      expect(messages[4].text).toBe("Message 5");
    });

    it("paginuje wiadomości z cursorem beforeMessageId", async () => {
      const threadId = "thread-paginate";
      const senderId = TEST_USER_ID;

      // Create 10 messages
      for (let i = 1; i <= 10; i++) {
        await adminDb.collection("messages").doc(threadId).collection("items").doc(`msg-${i}`).set({
          threadId,
          senderId,
          type: "text",
          text: `Message ${i}`,
          likes: [],
          readBy: [senderId],
          createdAt: admin.firestore.Timestamp.fromMillis(Date.now() + i * 1000),
        });
      }

      await wait(500);

      // Fetch first page (last 3 messages: 10, 9, 8 -> reversed to 8, 9, 10)
      const page1 = await adapter.listMessages(threadId, { limit: 3 });
      expect(page1.length).toBe(3);
      expect(page1[0].text).toBe("Message 8");
      expect(page1[2].text).toBe("Message 10");

      // Fetch second page using cursor (before msg-8, get 7, 6, 5)
      const page2 = await adapter.listMessages(threadId, { limit: 3, beforeMessageId: "msg-8" });
      expect(page2.length).toBe(3);
      expect(page2[0].text).toBe("Message 5");
      expect(page2[2].text).toBe("Message 7");
    });

    it("respektuje limit wiadomości", async () => {
      const threadId = "thread-limit";
      const senderId = TEST_USER_ID;

      // Create 20 messages
      for (let i = 1; i <= 20; i++) {
        await adminDb.collection("messages").doc(threadId).collection("items").doc(`msg-${i}`).set({
          threadId,
          senderId,
          type: "text",
          text: `Message ${i}`,
          likes: [],
          readBy: [senderId],
          createdAt: admin.firestore.Timestamp.fromMillis(Date.now() + i * 1000),
        });
      }

      await wait(500);

      const messages = await adapter.listMessages(threadId, { limit: 5 });

      expect(messages.length).toBe(5);
    });

    it("zwraca pustą tablicę gdy brak wiadomości", async () => {
      const threadId = "thread-empty";

      const messages = await adapter.listMessages(threadId, { limit: 10 });

      expect(messages).toEqual([]);
    });
  });

  describe("subscribeToMessages", () => {
    it("otrzymuje istniejące wiadomości przy subskrypcji", async () => {
      const threadId = "thread-subscribe-msg";
      const senderId = TEST_USER_ID;

      // Create existing message
      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-existing").set({
        threadId,
        senderId,
        type: "text",
        text: "Existing message",
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const received: any[] = [];
      const unsubscribe = adapter.subscribeToMessages(threadId, (message) => {
        received.push(message);
      });

      await wait(1000);

      expect(received.length).toBeGreaterThan(0);
      expect(received[0].text).toBe("Existing message");

      unsubscribe();
    });

    it("otrzymuje nowe wiadomości w czasie rzeczywistym", async () => {
      const threadId = "thread-realtime-msg";
      const senderId = TEST_USER_ID;

      const received: any[] = [];
      const unsubscribe = adapter.subscribeToMessages(threadId, (message) => {
        received.push(message);
      });

      await wait(500);

      // Add new message after subscription
      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-new").set({
        threadId,
        senderId,
        type: "text",
        text: "New message!",
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(1000);

      const newMessages = received.filter(m => m.text === "New message!");
      expect(newMessages.length).toBeGreaterThan(0);

      unsubscribe();
    });

    it("otrzymuje modyfikacje wiadomości", async () => {
      const threadId = "thread-modify-msg";
      const senderId = TEST_USER_ID;

      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-modify").set({
        threadId,
        senderId,
        type: "text",
        text: "Original",
        likes: [],
        readBy: [senderId],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const received: any[] = [];
      const unsubscribe = adapter.subscribeToMessages(threadId, (message) => {
        received.push({ ...message });
      });

      await wait(500);

      // Modify the message (add like)
      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-modify").update({
        likes: ["user-liker"],
      });

      await wait(1000);

      const modified = received.filter(m => m.likes && m.likes.length > 0);
      expect(modified.length).toBeGreaterThan(0);
      expect(modified[modified.length - 1].likes).toContain("user-liker");

      unsubscribe();
    });
  });

  describe("getUnreadCountForUser", () => {
    it("zwraca 0 gdy wszystkie wiadomości są przeczytane", async () => {
      const threadId = "thread-all-read";
      const userId = TEST_USER_ID;

      // Create messages that are all read by user
      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-1").set({
        threadId,
        senderId: "user-2",
        type: "text",
        text: "Message 1",
        readBy: [userId, "user-2"],
        likes: [],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-2").set({
        threadId,
        senderId: "user-2",
        type: "text",
        text: "Message 2",
        readBy: [userId, "user-2"],
        likes: [],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const unreadCount = await adapter.getUnreadCountForUser(threadId, userId);

      expect(unreadCount).toBe(0);
    });

    it("zwraca liczbę nieprzeczytanych wiadomości", async () => {
      const threadId = "thread-unread";
      const userId = TEST_USER_ID;

      // Create 3 messages: 2 unread, 1 read
      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-1").set({
        threadId,
        senderId: "user-2",
        type: "text",
        text: "Unread 1",
        readBy: ["user-2"], // userId NOT in readBy
        likes: [],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-2").set({
        threadId,
        senderId: "user-2",
        type: "text",
        text: "Read",
        readBy: [userId, "user-2"], // userId in readBy
        likes: [],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-3").set({
        threadId,
        senderId: "user-2",
        type: "text",
        text: "Unread 2",
        readBy: ["user-2"], // userId NOT in readBy
        likes: [],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const unreadCount = await adapter.getUnreadCountForUser(threadId, userId);

      expect(unreadCount).toBe(2);
    });

    it("nie liczy własnych wiadomości jako nieprzeczytane", async () => {
      const threadId = "thread-own-messages";
      const userId = TEST_USER_ID;

      // User's own message (should not count as unread)
      await adminDb.collection("messages").doc(threadId).collection("items").doc("msg-own").set({
        threadId,
        senderId: userId,
        type: "text",
        text: "My message",
        readBy: [userId],
        likes: [],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const unreadCount = await adapter.getUnreadCountForUser(threadId, userId);

      expect(unreadCount).toBe(0);
    });
  });

  describe("subscribeToTotalUnread", () => {
    it("otrzymuje aktualną wartość totalUnreadCount", async () => {
      const userId = TEST_USER_ID;

      // Set initial totalUnreadCount
      await adminDb.collection("userChatMeta").doc(userId).set({
        userId,
        totalUnreadCount: 5,
      });

      await wait(500);

      const received: number[] = [];
      const unsubscribe = adapter.subscribeToTotalUnread(userId, (count) => {
        received.push(count);
      });

      await wait(1000);

      expect(received.length).toBeGreaterThan(0);
      expect(received[0]).toBe(5);

      unsubscribe();
    });

    it("otrzymuje aktualizacje w czasie rzeczywistym", async () => {
      const userId = TEST_USER_ID;

      // Set initial value
      await adminDb.collection("userChatMeta").doc(userId).set({
        userId,
        totalUnreadCount: 3,
      });

      await wait(500);

      const received: number[] = [];
      const unsubscribe = adapter.subscribeToTotalUnread(userId, (count) => {
        received.push(count);
      });

      await wait(500);

      // Update totalUnreadCount
      await adminDb.collection("userChatMeta").doc(userId).update({
        totalUnreadCount: 7,
      });

      await wait(1000);

      expect(received.length).toBeGreaterThanOrEqual(2);
      const lastValue = received[received.length - 1];
      expect(lastValue).toBe(7);

      unsubscribe();
    });

    it("zwraca 0 gdy brak dokumentu userChatMeta", async () => {
      const userId = TEST_USER_ID;

      // Ensure document doesn't exist
      await adminDb.collection("userChatMeta").doc(userId).delete();
      await wait(300);

      const received: number[] = [];
      const unsubscribe = adapter.subscribeToTotalUnread(userId, (count) => {
        received.push(count);
      });

      await wait(1000);

      // Should receive 0 as default when document doesn't exist
      expect(received.length).toBeGreaterThan(0);
      expect(received[0]).toBe(0);

      unsubscribe();
    });
  });

  describe("updateUserBlockList and isUserBlocked", () => {
    it("blokuje użytkownika", async () => {
      const userId = TEST_USER_ID;
      const targetUserId = "user-to-block";

      // Initially not blocked
      const initiallyBlocked = await adapter.isUserBlocked(userId, targetUserId);
      expect(initiallyBlocked).toBe(false);

      // Block user
      await adapter.updateUserBlockList(userId, targetUserId, true);
      await wait(500);

      // Verify blocked
      const blocked = await adapter.isUserBlocked(userId, targetUserId);
      expect(blocked).toBe(true);
    });

    it("odblokowuje użytkownika", async () => {
      const userId = TEST_USER_ID;
      const targetUserId = "user-to-unblock";

      // Block first
      await adapter.updateUserBlockList(userId, targetUserId, true);
      await wait(500);

      const blocked = await adapter.isUserBlocked(userId, targetUserId);
      expect(blocked).toBe(true);

      // Unblock
      await adapter.updateUserBlockList(userId, targetUserId, false);
      await wait(500);

      // Verify unblocked
      const unblocked = await adapter.isUserBlocked(userId, targetUserId);
      expect(unblocked).toBe(false);
    });

    it("blokowanie jest jednostronne", async () => {
      const userId = TEST_USER_ID;
      const target1 = "user-target-1";
      const target2 = "user-target-2";

      // User blocks target1 but not target2
      await adapter.updateUserBlockList(userId, target1, true);
      await wait(500);

      // User blocked target1
      const blocked1 = await adapter.isUserBlocked(userId, target1);
      expect(blocked1).toBe(true);

      // User did NOT block target2 (one-way, selective blocking)
      const blocked2 = await adapter.isUserBlocked(userId, target2);
      expect(blocked2).toBe(false);
    });
  });

  describe("setTyping and subscribeToTyping", () => {
    it("ustawia typing indicator", async () => {
      const threadId = "thread-typing";
      const userId = TEST_USER_ID;

      // Create thread with user as member (required by security rules)
      await adminDb.collection("threads").doc(threadId).set({
        id: threadId,
        type: "group",
        members: [userId, "user-2"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const received: string[][] = [];
      const unsubscribe = adapter.subscribeToTyping(threadId, (userIds) => {
        received.push([...userIds]);
      });

      await wait(500);

      // Set user as typing
      await adapter.setTyping(threadId, userId, true);

      await wait(1000);

      // Should receive update with userId
      const withTyping = received.filter(ids => ids.includes(userId));
      expect(withTyping.length).toBeGreaterThan(0);

      unsubscribe();
    });

    it("usuwa typing indicator", async () => {
      const threadId = "thread-typing-stop";
      const userId = TEST_USER_ID;

      // Create thread with user as member
      await adminDb.collection("threads").doc(threadId).set({
        id: threadId,
        type: "group",
        members: [userId, "user-2"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      // Set typing first
      await adapter.setTyping(threadId, userId, true);
      await wait(500);

      const received: string[][] = [];
      const unsubscribe = adapter.subscribeToTyping(threadId, (userIds) => {
        received.push([...userIds]);
      });

      await wait(500);

      // Stop typing
      await adapter.setTyping(threadId, userId, false);

      await wait(1000);

      // Should receive update without userId
      const lastSnapshot = received[received.length - 1];
      expect(lastSnapshot).toBeDefined();
      expect(lastSnapshot.includes(userId)).toBe(false);

      unsubscribe();
    });

    it("śledzi wielu użytkowników piszących jednocześnie", async () => {
      const threadId = "thread-multi-typing";
      const user1 = TEST_USER_ID;
      const user2 = "user-2";

      // Create thread with both users as members
      await adminDb.collection("threads").doc(threadId).set({
        id: threadId,
        type: "group",
        members: [user1, user2, "user-3"],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(500);

      const received: string[][] = [];
      const unsubscribe = adapter.subscribeToTyping(threadId, (userIds) => {
        received.push([...userIds]);
      });

      await wait(500);

      // User1 starts typing (via adapter - authenticated)
      await adapter.setTyping(threadId, user1, true);
      await wait(300);

      // User2 starts typing (via Admin SDK - bypasses auth)
      await adminDb.collection("threads").doc(threadId).collection("typing").doc(user2).set({
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await wait(1000);

      // Should receive snapshot with both users
      const withBoth = received.filter(ids => ids.includes(user1) && ids.includes(user2));
      expect(withBoth.length).toBeGreaterThan(0);

      unsubscribe();
    });
  });

  describe("setThreadMuted and getThreadUserPrefs", () => {
    it("wycisza wątek", async () => {
      const threadId = "thread-to-mute";
      const userId = TEST_USER_ID;

      // Mute thread
      await adapter.setThreadMuted(threadId, userId, true);
      await wait(500);

      // Verify muted
      const prefs = await adapter.getThreadUserPrefs(threadId, userId);

      expect(prefs.muted).toBe(true);
      expect(prefs.threadId).toBe(threadId);
      expect(prefs.userId).toBe(userId);
      expect(prefs.mutedAt).toBeDefined();
    });

    it("odcisza wątek", async () => {
      const threadId = "thread-to-unmute";
      const userId = TEST_USER_ID;

      // Mute first
      await adapter.setThreadMuted(threadId, userId, true);
      await wait(500);

      const mutedPrefs = await adapter.getThreadUserPrefs(threadId, userId);
      expect(mutedPrefs.muted).toBe(true);

      // Unmute
      await adapter.setThreadMuted(threadId, userId, false);
      await wait(500);

      // Verify unmuted
      const unmutedPrefs = await adapter.getThreadUserPrefs(threadId, userId);
      expect(unmutedPrefs.muted).toBe(false);
    });

    it("zwraca domyślne preferencje gdy nie istnieją", async () => {
      const threadId = "thread-no-prefs";
      const userId = TEST_USER_ID;

      // Get prefs without setting them first
      const prefs = await adapter.getThreadUserPrefs(threadId, userId);

      expect(prefs.threadId).toBe(threadId);
      expect(prefs.userId).toBe(userId);
      expect(prefs.muted).toBe(false);
      expect(prefs.mutedAt).toBeUndefined();
    });
  });
});
