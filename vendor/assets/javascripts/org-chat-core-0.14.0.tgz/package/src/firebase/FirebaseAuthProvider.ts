import { FirebaseApp, getApp, getApps, initializeApp } from "firebase/app";
import { getAuth, signInWithCustomToken } from "firebase/auth";

export class FirebaseAuthProvider {
  private readonly firebaseConfig: Record<string, unknown>;
  private readonly customToken: string;
  private app: FirebaseApp | null = null;

  constructor(params: { firebaseConfig: Record<string, unknown>; customToken: string }) {
    this.firebaseConfig = params.firebaseConfig;
    this.customToken = params.customToken;
  }

  async init(): Promise<{ userId: string }> {
    this.app = this.ensureApp();
    const auth = getAuth(this.app);
    const credential = await signInWithCustomToken(auth, this.customToken);
    return { userId: credential.user.uid };
  }

  private ensureApp(): FirebaseApp {
    if (this.app) {
      return this.app;
    }
    const existing = getApps();
    if (existing.length > 0) {
      return existing[0];
    }
    return initializeApp(this.firebaseConfig);
  }
}

