import { describe, expect, it, vi } from "vitest";
import { ChatClient, AuthAdapter, ChatFirestoreAdapter } from "./ChatClient";
import { Message, Thread, Timestamp } from "./types";

const fixedTimestamp: Timestamp = { seconds: 1, nanoseconds: 2 };

class FakeAuth implements AuthAdapter {
  constructor(private readonly uid: string) {}
  async signInWithCustomToken(): Promise<{ uid: string; chatBanned?: boolean }> {
    return { uid: this.uid, chatBanned: false };
  }
}

class FakeFirestore implements ChatFirestoreAdapter {
  private threads = new Map<string, Thread>();
  private messages = new Map<string, Map<string, Message>>();
  private listeners = new Map<string, Array<(m: Message) => void>>();
  private counter = 0;
  private totalUnread = new Map<string, number>();
  private unreadListeners = new Map<string, Array<(count: number) => void>>();
  private blocks = new Map<string, Set<string>>();
  async consumeRateLimit(): Promise<{ allowed: true }> {
    return { allowed: true };
  }

  constructor(threads: Thread[] = []) {
    threads.forEach((t) => this.threads.set(t.id, { ...t, unreadCount: t.unreadCount ?? 0 }));
  }

  async getThreadsForUser(userId: string): Promise<Thread[]> {
    return Array.from(this.threads.values()).filter((t) =>
      t.members.includes(userId)
    );
  }

  async getThread(threadId: string): Promise<Thread | null> {
    return this.threads.get(threadId) ?? null;
  }

  async findDirectThreadByMembers(memberA: string, memberB: string): Promise<Thread | null> {
    const found = Array.from(this.threads.values()).find(
      (t) => t.type === "direct" && t.members.includes(memberA) && t.members.includes(memberB)
    );
    return found ?? null;
  }

  async createThreadWithMessageAtomic(input: {
    thread: {
      type: Thread["type"];
      members: string[];
      name?: string;
      acceptedBy?: string[];
      directUnlocked?: boolean;
      roles?: Record<string, string>;
      bannedMembers?: string[];
    };
    message: {
      threadId: string;
      senderId: string;
      clientMessageId?: string;
      type: "text" | "image";
      text?: string | undefined;
      imageUrl?: string | undefined;
      replyTo?: {
        messageId: string;
        senderId: string;
        text?: string | undefined;
        imageUrl?: string | undefined;
      } | undefined;
    };
  }): Promise<{ thread: Thread; message: Message }> {
    const id = input.message.threadId || `t-${this.threads.size + 1}`;
    const thread: Thread = {
      id,
      type: input.thread.type,
      members: input.thread.members,
      createdAt: fixedTimestamp,
      name: input.thread.name,
      acceptedBy: input.thread.acceptedBy,
      directUnlocked: input.thread.directUnlocked,
      unreadCount: 0,
      roles: (input.thread as any).roles,
      bannedMembers: (input.thread as any).bannedMembers,
    };
    this.threads.set(id, thread);
    const message = await this.addMessageAtomic(
      {
        threadId: id,
        senderId: input.message.senderId,
        type: input.message.type,
        text: input.message.text,
        imageUrl: input.message.imageUrl,
        replyTo: input.message.replyTo,
      },
      { threadUpdates: { directUnlocked: thread.directUnlocked } }
    );
    thread.lastMessage = {
      id: message.id,
      senderId: message.senderId,
      text: message.text,
      imageUrl: message.imageUrl,
      createdAt: message.createdAt,
    };
    this.threads.set(id, thread);
    return { thread, message };
  }

  subscribeToMessages(
    threadId: string,
    onMessage: (message: Message) => void
  ): () => void {
    const list = this.listeners.get(threadId) ?? [];
    this.listeners.set(threadId, [...list, onMessage]);
    return () => {
      const current = this.listeners.get(threadId) ?? [];
      this.listeners.set(
        threadId,
        current.filter((cb) => cb !== onMessage)
      );
    };
  }

  private emit(threadId: string, message: Message): void {
    (this.listeners.get(threadId) ?? []).forEach((cb) => cb(message));
  }

  async addMessageAtomic(
    input: {
      threadId: string;
      senderId: string;
      type: "text" | "image";
      text?: string | undefined;
      imageUrl?: string | undefined;
      replyTo?: {
        messageId: string;
        senderId: string;
        text?: string | undefined;
        imageUrl?: string | undefined;
      } | undefined;
    },
    options?: { threadUpdates?: { directUnlocked?: boolean; acceptedByAdd?: string[] }; unreadFanout?: { recipients: string[]; senderId: string } }
  ): Promise<Message> {
    const id = `m-${this.counter++}`;
    const message: Message = {
      id,
      threadId: input.threadId,
      senderId: input.senderId,
      type: input.type,
      text: input.text,
      imageUrl: input.imageUrl,
      replyTo: input.replyTo,
      likes: [],
      readBy: [input.senderId],
      createdAt: fixedTimestamp,
    };
    if (!this.messages.has(input.threadId)) {
      this.messages.set(input.threadId, new Map());
    }
    this.messages.get(input.threadId)?.set(id, message);
    this.emit(input.threadId, message);
    const thread = this.threads.get(input.threadId);
    if (thread) {
      thread.lastMessage = {
        id: message.id,
        senderId: message.senderId,
        text: message.text,
        imageUrl: message.imageUrl,
        createdAt: message.createdAt,
      };
      if (options?.threadUpdates?.directUnlocked !== undefined) {
        thread.directUnlocked = options.threadUpdates.directUnlocked;
      }
      if (options?.threadUpdates?.acceptedByAdd) {
        const accepted = new Set(thread.acceptedBy ?? []);
        options.threadUpdates.acceptedByAdd.forEach((u) => accepted.add(u));
        thread.acceptedBy = Array.from(accepted);
      }
      if (options?.unreadFanout?.recipients?.length) {
        options.unreadFanout.recipients.forEach((uid) => {
          this.totalUnread.set(uid, (this.totalUnread.get(uid) ?? 0) + 1);
          (this.unreadListeners.get(uid) ?? []).forEach((cb) => cb(this.totalUnread.get(uid) ?? 0));
        });
      }
    }
    return message;
  }

  async getMessage(threadId: string, messageId: string): Promise<Message | null> {
    return this.messages.get(threadId)?.get(messageId) ?? null;
  }

  async listMessages(
    threadId: string,
    options: { limit: number; beforeMessageId?: string }
  ): Promise<Message[]> {
    const all = Array.from(this.messages.get(threadId)?.values() ?? []);
    const sortedDesc = all.sort((a, b) => {
      const aMs = a.createdAt.seconds * 1000 + a.createdAt.nanoseconds / 1_000_000;
      const bMs = b.createdAt.seconds * 1000 + b.createdAt.nanoseconds / 1_000_000;
      if (aMs === bMs) {
        return b.id.localeCompare(a.id);
      }
      return bMs - aMs;
    });
    const startIndex = options.beforeMessageId
      ? sortedDesc.findIndex((m) => m.id === options.beforeMessageId) + 1
      : 0;
    const page = sortedDesc.slice(startIndex, startIndex + options.limit);
    return [...page].reverse();
  }

  async appendMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) {
      throw new Error("Message not found");
    }
    if (!message.likes.includes(userId)) {
      message.likes = [...message.likes, userId];
    }
  }

  async removeMessageLike(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) {
      throw new Error("Message not found");
    }
    if (message.likes.includes(userId)) {
      message.likes = message.likes.filter((id) => id !== userId);
    }
  }

  async appendMessageReadBy(threadId: string, messageId: string, userId: string): Promise<void> {
    const message = this.messages.get(threadId)?.get(messageId);
    if (!message) {
      throw new Error("Message not found");
    }
    if (!message.readBy.includes(userId)) {
      message.readBy = [...message.readBy, userId];
      this.totalUnread.set(userId, Math.max(0, (this.totalUnread.get(userId) ?? 0) - 1));
      (this.unreadListeners.get(userId) ?? []).forEach((cb) => cb(this.totalUnread.get(userId) ?? 0));
    }
  }

  async appendThreadAcceptedBy(threadId: string, userId: string): Promise<void> {
    const thread = this.threads.get(threadId);
    if (!thread) {
      throw new Error("Thread not found");
    }
    const accepted = new Set(thread.acceptedBy ?? []);
    accepted.add(userId);
    this.threads.set(threadId, { ...thread, acceptedBy: Array.from(accepted) });
  }

  async updateCommunityBan(threadId: string, userId: string, banned: boolean): Promise<void> {
    const thread = this.threads.get(threadId);
    if (!thread) {
      throw new Error("Thread not found");
    }
    const current = new Set(thread.bannedMembers ?? []);
    if (banned) {
      current.add(userId);
    } else {
      current.delete(userId);
    }
    this.threads.set(threadId, { ...thread, bannedMembers: Array.from(current) });
  }

  async updateThreadMembership(input: {
    threadId: string;
    members: string[];
    acceptedBy?: string[];
    roles?: Record<string, string> | undefined;
    bannedMembers?: string[];
  }): Promise<void> {
    const thread = this.threads.get(input.threadId);
    if (!thread) {
      throw new Error("Thread not found");
    }
    this.threads.set(input.threadId, {
      ...thread,
      members: input.members,
      acceptedBy: input.acceptedBy ?? thread.acceptedBy,
      roles: input.roles,
      bannedMembers: input.bannedMembers ?? thread.bannedMembers,
    });
  }

  async setTyping(): Promise<void> {
    return;
  }

  subscribeToTyping(_threadId: string, _onChange: (userIds: string[]) => void): () => void {
    return () => {};
  }

  subscribeToTotalUnread(userId: string, onChange: (count: number) => void): () => void {
    const list = this.unreadListeners.get(userId) ?? [];
    this.unreadListeners.set(userId, [...list, onChange]);
    onChange(this.totalUnread.get(userId) ?? 0);
    return () => {
      const current = this.unreadListeners.get(userId) ?? [];
      this.unreadListeners.set(
        userId,
        current.filter((cb) => cb !== onChange)
      );
    };
  }

  async decrementTotalUnread(userId: string, count: number, _threadId?: string): Promise<void> {
    if (count <= 0) return;
    this.totalUnread.set(userId, Math.max(0, (this.totalUnread.get(userId) ?? 0) - count));
    (this.unreadListeners.get(userId) ?? []).forEach((cb) => cb(this.totalUnread.get(userId) ?? 0));
  }

  async getThreadUnreadMap(_userId: string): Promise<Record<string, number>> {
    return {};
  }

  async updateUserBlockList(userId: string, targetUserId: string, block: boolean): Promise<void> {
    const set = this.blocks.get(userId) ?? new Set<string>();
    if (block) {
      set.add(targetUserId);
    } else {
      set.delete(targetUserId);
    }
    this.blocks.set(userId, set);
  }

  async isUserBlocked(blockingUserId: string, blockedUserId: string): Promise<boolean> {
    return (this.blocks.get(blockingUserId) ?? new Set<string>()).has(blockedUserId);
  }

  async getUnreadCountForUser(_threadId: string, _userId: string): Promise<number> {
    const messages = this.messages.get(_threadId);
    if (!messages) {
      return 0;
    }
    let unread = 0;
    messages.forEach((m) => {
      if (m.senderId !== _userId && !m.readBy.includes(_userId)) {
        unread += 1;
      }
    });
    return unread;
  }

  async getThreadUserPrefs(threadId: string, userId: string): Promise<{ threadId: string; userId: string; muted: boolean }> {
    return { threadId, userId, muted: false };
  }

  subscribeToThreads(
    _userId: string,
    onChange: (threads: Thread[]) => void
  ): () => void {
    onChange(Array.from(this.threads.values()));
    return () => {};
  }

  async resolveUsernamesToIds(usernames: string[]): Promise<Map<string, string>> {
    const map = new Map<string, string>();
    usernames.forEach((u) => map.set(u, u));
    return map;
  }

  async setThreadMuted(): Promise<void> {
    return;
  }
}

const makeClient = (uid: string, threads: Thread[] = []) => {
  const auth = new FakeAuth(uid);
  const baseThreads =
    threads.length > 0
      ? threads
      : [
          {
            id: "t1",
            type: "direct",
            members: [uid, "user-2"],
            createdAt: fixedTimestamp,
            acceptedBy: [uid, "user-2"],
            directUnlocked: true,
            lastMessage: {
              id: "seed",
              senderId: uid,
              text: "init",
              createdAt: fixedTimestamp,
            },
            unreadCount: 0,
          },
        ];
  const firestore = new FakeFirestore(baseThreads);
  const client = new ChatClient({
    firebaseConfig: {},
    customToken: "token",
    auth,
    firestore,
  });
  return { client, firestore };
};

describe("ChatClient", () => {
  it("signs in on init and fetches threads for current user", async () => {
    const threads: Thread[] = [
      {
        id: "t1",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: fixedTimestamp,
        unreadCount: 0,
        lastMessage: {
          id: "m1",
          senderId: "user-1",
          text: "hello",
          createdAt: fixedTimestamp,
        },
      },
      {
        id: "t2",
        type: "group",
        members: ["user-2"],
        createdAt: fixedTimestamp,
        unreadCount: 0,
      },
    ];
    const { client } = makeClient("user-1", threads);

    await client.init();
    const result = await client.getThreads();

    expect(result).toHaveLength(1);
    expect(result[0].id).toBe("t1");
  });

  it("delegates sendMessage for text through MessageService", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();

    await client.sendMessage({ threadId: "t1", message: { text: "hello" } });

    const messages = firestore["messages"].get("t1");
    expect(messages?.size).toBe(1);
    expect(messages?.values().next().value.text).toBe("hello");
  });

  it("delegates sendMessage for image payloads through MessageService", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();

    await client.sendMessage({ threadId: "t1", message: { text: "caption", imageUrl: "https://img" } });

    const messages = firestore["messages"].get("t1");
    expect(messages?.values().next().value.text).toBe("caption");
    expect(messages?.values().next().value.imageUrl).toBe("https://img");
  });

  it("delegates likeMessage and markAsRead", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();

    await client.sendMessage({ threadId: "t1", message: { text: "hello" } });
    const msgId = firestore["messages"].get("t1")?.values().next().value.id as string;

    await client.likeMessage("t1", msgId);
    await client.markAsRead("t1", msgId);

    const message = firestore["messages"].get("t1")?.get(msgId);
    expect(message?.likes).toEqual(["user-1"]);
    expect(message?.readBy).toEqual(["user-1"]);
  });

  it("delegates unlikeMessage", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();

    await client.sendMessage({ threadId: "t1", message: { text: "hello" } });
    const msgId = firestore["messages"].get("t1")?.values().next().value.id as string;

    await client.likeMessage("t1", msgId);
    await client.unlikeMessage("t1", msgId);

    const message = firestore["messages"].get("t1")?.get(msgId);
    expect(message?.likes).toEqual([]);
  });

  it("derives unread count from readBy and sender", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();

    const incoming = await firestore.addMessageAtomic({
      threadId: "t1",
      senderId: "user-2",
      type: "text",
      text: "new message",
    });

    const unreadBefore = await client.getUnreadCount("t1");
    expect(unreadBefore).toBe(1);

    await client.markAsRead("t1", incoming.id);

    const unreadAfter = await client.getUnreadCount("t1");
    expect(unreadAfter).toBe(0);
  });

  it("subscribes to messages and supports unsubscribe", async () => {
    const { client } = makeClient("user-1");
    await client.init();
    const received: Message[] = [];

    const unsubscribe = await client.openThread("t1", (m) => received.push(m));
    await client.sendMessage({ threadId: "t1", message: { text: "first" } });
    unsubscribe();
    await client.sendMessage({ threadId: "t1", message: { text: "second" } });

    expect(received.map((m) => m.text)).toEqual(["first"]);
  });

  it("wzbogaca wątki o unreadCount w subskrypcji", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();

    await firestore.addMessageAtomic({
      threadId: "t1",
      senderId: "user-2",
      type: "text",
      text: "hi",
    });

    const cb = vi.fn();
    const unsubscribe = client.subscribeThreads(cb);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const threads = cb.mock.calls[0]?.[0] as Thread[];
    expect(threads[0].unreadCount).toBe(1);
    unsubscribe();
  });

  it("throws if methods are called before init", async () => {
    const { client } = makeClient("user-1");
    await expect(client.getThreads()).rejects.toThrow("ChatClient not initialized");
  });

  it("subscribes to total unread changes", async () => {
    const { client, firestore } = makeClient("user-1");
    await client.init();
    const changes: number[] = [];
    const unsubscribe = client.subscribeTotalUnread((count) => changes.push(count));

    await client.sendMessage({ threadId: "t1", message: { text: "hello" } });
    const msgId = firestore["messages"].get("t1")?.values().next().value.id as string;
    await client.markAsRead("t1", msgId);

    unsubscribe();
    expect(changes[0]).toBeDefined();
    expect(changes.some((c) => c === 0)).toBe(true);
  });

  it("creates community with owner role and allows moderation ban/unban", async () => {
    const { client, firestore } = makeClient("owner-1");
    await client.init();
    const created = (await client.sendMessage({
      threadType: "community",
      members: ["member-1"],
      name: "comm",
      message: { text: "hi" },
    })) as Thread;

    const stored = await firestore.getThread(created.id);
    expect(stored?.roles?.["owner-1"]).toBe("owner");
    await client.banUserFromCommunity(created.id, "member-1");
    const afterBan = await firestore.getThread(created.id);
    expect(afterBan?.bannedMembers).toContain("member-1");
    await client.unbanUserFromCommunity(created.id, "member-1");
    const afterUnban = await firestore.getThread(created.id);
    expect(afterUnban?.bannedMembers).not.toContain("member-1");
  });

  it("removes user from group on leaveThread", async () => {
    const groupThread: Thread = {
      id: "g-1",
      type: "group",
      members: ["user-1", "user-2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["user-1", "user-2"],
      unreadCount: 0,
    };
    const { client, firestore } = makeClient("user-1", [groupThread]);
    await client.init();

    await client.leaveThread("g-1");
    const updated = await firestore.getThread("g-1");
    expect(updated?.members).toEqual(["user-2"]);
  });

  it("prevents sending direct message when recipient blocked sender", async () => {
    const { client, firestore } = makeClient("sender");
    await client.init();
    const created = (await client.sendMessage({
      threadType: "direct",
      members: ["recipient"],
      message: { text: "hello" },
    })) as Thread;
    // Recipient blocks sender - sender cannot send to recipient anymore
    await firestore.updateUserBlockList("recipient", "sender", true);
    await expect(client.sendMessage({ threadId: created.id, message: { text: "second" } })).rejects.toHaveProperty(
      "code",
      "USER_BLOCKED"
    );
  });

  it("allows sending direct message when sender blocked recipient (blocking is one-way)", async () => {
    const { client, firestore } = makeClient("sender");
    await client.init();
    const created = (await client.sendMessage({
      threadType: "direct",
      members: ["recipient"],
      message: { text: "hello" },
    })) as Thread;
    // Unlock the thread (simulates recipient replying)
    const storedThread = firestore["threads"].get(created.id);
    if (storedThread) {
      storedThread.directUnlocked = true;
      // Also update lastMessage.senderId to recipient so WAIT_FOR_REPLY doesn't trigger
      storedThread.lastMessage = {
        ...storedThread.lastMessage!,
        senderId: "recipient",
      };
    }
    // Sender blocks recipient - sender CAN still send to recipient
    await firestore.updateUserBlockList("sender", "recipient", true);
    // Should not throw - sending should succeed
    await client.sendMessage({ threadId: created.id, message: { text: "second" } });
    // Verify the message was created
    const messages = firestore["messages"].get(created.id);
    expect(messages?.size).toBe(2); // First message + second message
    const lastMessage = Array.from(messages?.values() ?? []).find(m => m.text === "second");
    expect(lastMessage).toBeDefined();
    expect(lastMessage?.text).toBe("second");
  });

  it("block/unblock API updates block list", async () => {
    const { client, firestore } = makeClient("owner-1");
    await client.init();
    await client.blockUser("target-1");
    expect(await firestore.isUserBlocked("owner-1", "target-1")).toBe(true);
    await client.unblockUser("target-1");
    expect(await firestore.isUserBlocked("owner-1", "target-1")).toBe(false);
  });

  it("uploadImageBase64 delegates to media adapter", async () => {
    const uploadImageBase64 = vi.fn().mockResolvedValue("https://uploaded.com/image.jpg");
    const auth = new FakeAuth("user-1");
    const firestore = new FakeFirestore([
      {
        id: "t1",
        type: "direct",
        members: ["user-1", "user-2"],
        createdAt: fixedTimestamp,
        unreadCount: 0,
      },
    ]);
    const media = {
      uploadImage: vi.fn(),
      uploadImageBase64,
    };
    const client = new ChatClient({
      firebaseConfig: {},
      customToken: "token",
      auth,
      firestore,
      media,
    });
    await client.init();

    const result = await client.uploadImageBase64({
      base64: "SGVsbG8gV29ybGQ=",
      mimeType: "image/jpeg",
      fileName: "test.jpg",
    });

    expect(uploadImageBase64).toHaveBeenCalledWith({
      base64: "SGVsbG8gV29ybGQ=",
      mimeType: "image/jpeg",
      fileName: "test.jpg",
    });
    expect(result).toBe("https://uploaded.com/image.jpg");
  });

  it("uploadImageBase64 throws when media adapter not configured", async () => {
    const { client } = makeClient("user-1");
    await client.init();

    await expect(
      client.uploadImageBase64({
        base64: "SGVsbG8gV29ybGQ=",
        mimeType: "image/jpeg",
        fileName: "test.jpg",
      })
    ).rejects.toThrow("Image upload is not configured");
  });

  it("decrements total unread when leaving group", async () => {
    const groupThread: Thread = {
      id: "g-2",
      type: "group",
      members: ["user-1", "user-2"],
      createdAt: fixedTimestamp,
      acceptedBy: ["user-1", "user-2"],
      unreadCount: 0,
    };
    const { client, firestore } = makeClient("user-1", [groupThread]);
    await client.init();
    await firestore.addMessageAtomic({
      threadId: "g-2",
      senderId: "user-2",
      type: "text",
      text: "hi",
    });

    const changes: number[] = [];
    const unsub = client.subscribeTotalUnread((c) => changes.push(c));
    await client.leaveThread("g-2");
    unsub();
    expect(changes.some((c) => c === 0)).toBe(true);
  });
});

