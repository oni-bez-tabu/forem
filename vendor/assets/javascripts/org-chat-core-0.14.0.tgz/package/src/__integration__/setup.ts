/**
 * Integration test setup for end-to-end flows
 * Creates multiple authenticated users and simulates Cloud Functions behavior
 */
import { initializeApp, FirebaseApp, deleteApp, getApps } from "firebase/app";
import { getFirestore, connectFirestoreEmulator, Firestore } from "firebase/firestore";
import { getAuth, connectAuthEmulator, signInWithCustomToken, Auth } from "firebase/auth";
import * as admin from "firebase-admin";
import { ChatClient } from "../ChatClient.js";
import { MessageService } from "../MessageService.js";
import { FirebaseFirestoreAdapter } from "../firebase/FirebaseFirestoreAdapter.js";

export const testConfig = {
  projectId: "chat-sdk-33ade",
  firestoreHost: "localhost",
  firestorePort: 8080,
  authHost: "localhost",
  authPort: 9099,
};

export interface TestUser {
  userId: string;
  app: FirebaseApp;
  db: Firestore;
  auth: Auth;
  adapter: FirebaseFirestoreAdapter;
  messageService: MessageService;
  chatClient: ChatClient;
}

let adminDb: admin.firestore.Firestore | null = null;
let adminAuth: admin.auth.Auth | null = null;
const testUsers = new Map<string, TestUser>();

/**
 * Initialize Firebase Admin SDK for test setup
 */
export async function initializeAdmin(): Promise<{
  adminDb: admin.firestore.Firestore;
  adminAuth: admin.auth.Auth;
}> {
  if (adminDb && adminAuth) {
    return { adminDb, adminAuth };
  }

  // Set emulator environment variables BEFORE initializing Admin SDK
  process.env.FIRESTORE_EMULATOR_HOST = `${testConfig.firestoreHost}:${testConfig.firestorePort}`;
  process.env.FIREBASE_AUTH_EMULATOR_HOST = `${testConfig.authHost}:${testConfig.authPort}`;

  if (admin.apps.length === 0) {
    admin.initializeApp({ projectId: testConfig.projectId });
  }
  adminDb = admin.firestore();
  adminAuth = admin.auth();

  return { adminDb, adminAuth };
}

/**
 * Create an authenticated test user with full ChatClient setup
 */
export async function createTestUser(userId: string): Promise<TestUser> {
  if (testUsers.has(userId)) {
    return testUsers.get(userId)!;
  }

  const { adminAuth: auth } = await initializeAdmin();

  // Create Firebase app for this user
  const app = initializeApp(
    {
      projectId: testConfig.projectId,
      apiKey: "fake-api-key-for-testing",
    },
    `test-user-${userId}`
  );

  const db = getFirestore(app);
  const userAuth = getAuth(app);

  // Connect to emulators
  connectFirestoreEmulator(db, testConfig.firestoreHost, testConfig.firestorePort);
  connectAuthEmulator(userAuth, `http://${testConfig.authHost}:${testConfig.authPort}`, {
    disableWarnings: true,
  });

  // Authenticate user
  const customToken = await auth.createCustomToken(userId);
  await signInWithCustomToken(userAuth, customToken);

  // Create adapter and services
  const adapter = new FirebaseFirestoreAdapter(db);
  const messageService = new MessageService({
    firestore: adapter,
    currentUserId: userId,
    chatBanned: false,
  });
  const chatClient = new ChatClient({
    firebaseConfig: {
      projectId: testConfig.projectId,
      apiKey: "fake-api-key-for-testing",
    },
    customToken: customToken,
    auth: {
      signInWithCustomToken: async () => ({ uid: userId, chatBanned: false }),
    },
    firestore: adapter,
  });

  const testUser: TestUser = {
    userId,
    app,
    db,
    auth: userAuth,
    adapter,
    messageService,
    chatClient,
  };

  testUsers.set(userId, testUser);
  return testUser;
}

/**
 * Get admin SDK instances
 */
export function getAdmin(): {
  adminDb: admin.firestore.Firestore;
  adminAuth: admin.auth.Auth;
} {
  if (!adminDb || !adminAuth) {
    throw new Error("Admin SDK not initialized. Call initializeAdmin() first.");
  }
  return { adminDb, adminAuth };
}

/**
 * Clear all Firestore data using emulator REST API
 */
export async function clearFirestore(): Promise<void> {
  try {
    const response = await fetch(
      `http://${testConfig.firestoreHost}:${testConfig.firestorePort}/emulator/v1/projects/${testConfig.projectId}/databases/(default)/documents`,
      { method: "DELETE" }
    );

    if (!response.ok) {
      throw new Error(`Failed to clear Firestore: ${response.statusText}`);
    }
  } catch (error) {
    console.error("Error clearing Firestore:", error);
    throw error;
  }
}

/**
 * Clean up all test users and Firebase apps
 */
export async function cleanupTestUsers(): Promise<void> {
  const apps = getApps();
  for (const app of apps) {
    await deleteApp(app);
  }
  testUsers.clear();
}

/**
 * Helper to wait for async operations
 */
export function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Initialize required Firestore documents for integration tests
 * Call this at the beginning of each test to setup necessary data
 */
export async function initializeTestData(userIds: string[]): Promise<void> {
  const { adminDb } = getAdmin();

  // Create userProfiles and userBlocks for all users
  for (const userId of userIds) {
    // Create userProfile (required by security rules)
    await adminDb.collection("userProfiles").doc(userId).set({
      uid: userId,
      displayName: `Test User ${userId}`,
      photoURL: null,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Create empty userBlocks
    await adminDb.collection("userBlocks").doc(userId).set({
      userId,
      blockedUserIds: [],
    });
  }

  await wait(500);
}

/**
 * Simulate Cloud Function: Update directUnlocked when reply is sent
 * In production, this is done by onMessageCreate Cloud Function
 */
export async function simulateDirectUnlock(threadId: string): Promise<void> {
  const { adminDb } = getAdmin();
  await adminDb.collection("threads").doc(threadId).update({
    directUnlocked: true,
  });
}

/**
 * Simulate Cloud Function: Update lastMessage on thread
 * In production, this is done by onMessageCreate Cloud Function
 */
export async function simulateLastMessageUpdate(
  threadId: string,
  messageData: {
    id: string;
    senderId: string;
    text: string;
    imageUrl?: string | null;
  }
): Promise<void> {
  const { adminDb } = getAdmin();
  await adminDb.collection("threads").doc(threadId).update({
    lastMessage: {
      id: messageData.id,
      senderId: messageData.senderId,
      text: messageData.text,
      imageUrl: messageData.imageUrl ?? null,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    },
  });
}

/**
 * Simulate Cloud Function: Fanout userBlockedBy when a user blocks someone
 * In production, this is done by onUserBlockWrite Cloud Function
 * Creates/updates userBlockedBy/{blockedUserId}.blockedByUserIds
 */
export async function simulateUserBlockedByFanout(
  blockingUserId: string,
  blockedUserId: string,
  isBlocking: boolean
): Promise<void> {
  const { adminDb } = getAdmin();
  const ref = adminDb.collection("userBlockedBy").doc(blockedUserId);

  if (isBlocking) {
    await ref.set(
      { blockedByUserIds: admin.firestore.FieldValue.arrayUnion(blockingUserId) },
      { merge: true }
    );
  } else {
    await ref.set(
      { blockedByUserIds: admin.firestore.FieldValue.arrayRemove(blockingUserId) },
      { merge: true }
    );
  }
}

/**
 * Simulate Cloud Function: Fanout thread to userThreads collection
 * In production, this is done by onThreadCreate Cloud Function
 * Creates userThreads/{userId}/threads/{threadId} for each member
 */
export async function simulateThreadFanout(
  threadId: string,
  threadData: {
    type: "direct" | "group" | "community";
    members: string[];
    name?: string;
    directUnlocked?: boolean;
    acceptedBy?: string[];
    roles?: Record<string, "owner" | "moderator" | "member">;
    bannedMembers?: string[];
    lastMessage?: {
      id: string;
      senderId: string;
      text: string;
      imageUrl?: string | null;
      createdAt?: admin.firestore.Timestamp;
    } | null;
  }
): Promise<void> {
  const { adminDb } = getAdmin();

  const createdAt = admin.firestore.FieldValue.serverTimestamp();
  const lastMessage = threadData.lastMessage ?? null;

  const fanoutThread: Record<string, unknown> = {
    threadId,
    type: threadData.type,
    members: threadData.members,
    name: threadData.name ?? null,
    directUnlocked: threadData.directUnlocked ?? null,
    acceptedBy: threadData.acceptedBy ?? [],
    roles: threadData.roles ?? null,
    bannedMembers: threadData.bannedMembers ?? null,
    createdAt,
    lastMessage,
    lastMessageAt: (lastMessage as any)?.createdAt ?? createdAt,
  };

  await Promise.all(
    threadData.members.map(async (userId) => {
      await adminDb
        .collection("userThreads")
        .doc(userId)
        .collection("threads")
        .doc(threadId)
        .set(fanoutThread, { merge: true });
    })
  );
}
