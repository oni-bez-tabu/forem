/**
 * Integration test: Community Moderation Flow
 * Tests community creation, member banning, and moderation
 */
import { describe, it, expect, beforeAll, afterEach, afterAll } from "vitest";
import {
  createTestUser,
  initializeAdmin,
  clearFirestore,
  cleanupTestUsers,
  wait,
  initializeTestData,
  getAdmin,
  type TestUser,
} from "./setup.js";
import * as admin from "firebase-admin";

let owner: TestUser;
let member: TestUser;

beforeAll(async () => {
  await initializeAdmin();
  owner = await createTestUser("owner-1");
  member = await createTestUser("member-1");
});

afterEach(async () => {
  await clearFirestore();
  await wait(500);
});

afterAll(async () => {
  await cleanupTestUsers();
});

describe("Community Moderation Flow", () => {
  it("owner może zbanować membera w community", async () => {
    const { adminDb } = getAdmin();
    await initializeTestData(["owner-1", "member-1"]);

    // Owner creates community thread
    const { thread } = await owner.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "community",
        members: ["owner-1", "member-1"],
        roles: {
          "owner-1": "owner",
        },
        name: "Test Community",
      },
      message: {
        threadId: "",
        senderId: "owner-1",
        type: "text",
        text: "Welcome to the community!",
      },
    });

    await wait(500);

    // Member can send message initially
    const messageFromMember = await member.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Hello from member!",
      },
    });

    expect((messageFromMember as any).text).toBe("Hello from member!");

    await wait(500);

    // Owner bans member
    await owner.adapter.updateCommunityBan(thread.id, "member-1", true);
    await wait(500);

    // Verify member is banned
    const threadAfterBan = await owner.adapter.getThread(thread.id);
    expect(threadAfterBan?.bannedMembers).toContain("member-1");

    // Member cannot send message after ban
    await expect(
      member.messageService.sendMessage({
        threadId: thread.id,
        message: {
          text: "Message after ban (should fail)",
        },
      })
    ).rejects.toThrow("banned in this community");
  });

  it("owner może odbanować membera", async () => {
    const { adminDb } = getAdmin();
    await initializeTestData(["owner-1", "member-1"]);

    // Create community and immediately ban member
    const { thread } = await owner.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "community",
        members: ["owner-1", "member-1"],
        roles: {
          "owner-1": "owner",
        },
        name: "Test Community",
        bannedMembers: ["member-1"], // Start with member banned
      },
      message: {
        threadId: "",
        senderId: "owner-1",
        type: "text",
        text: "Community created",
      },
    });

    await wait(500);

    // Verify member is banned
    const threadBeforeUnban = await owner.adapter.getThread(thread.id);
    expect(threadBeforeUnban?.bannedMembers).toContain("member-1");

    // Member cannot send
    await expect(
      member.messageService.sendMessage({
        threadId: thread.id,
        message: {
          text: "Should fail",
        },
      })
    ).rejects.toThrow("banned in this community");

    // Owner unbans member
    await owner.adapter.updateCommunityBan(thread.id, "member-1", false);
    await wait(500);

    // Verify member is unbanned
    const threadAfterUnban = await owner.adapter.getThread(thread.id);
    expect(threadAfterUnban?.bannedMembers).not.toContain("member-1");

    // Member can now send message
    const messageAfterUnban = await member.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Message after unban",
      },
    });

    expect((messageAfterUnban as any).text).toBe("Message after unban");
  });

  it("community wymaga nazwy przy tworzeniu", async () => {
    await initializeTestData(["owner-1"]);

    // Community without name should work (name is optional in type definition)
    // but in practice, UI should enforce it
    const { thread } = await owner.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "community",
        members: ["owner-1"],
        roles: {
          "owner-1": "owner",
        },
      },
      message: {
        threadId: "",
        senderId: "owner-1",
        type: "text",
        text: "Test",
      },
    });

    expect(thread.type).toBe("community");
    expect(thread.roles?.["owner-1"]).toBe("owner");
  });

  it("member może wysyłać wiadomości w community", async () => {
    await initializeTestData(["owner-1", "member-1"]);

    // Owner creates community with member
    const { thread } = await owner.adapter.createThreadWithMessageAtomic({
      thread: {
        type: "community",
        members: ["owner-1", "member-1"],
        roles: {
          "owner-1": "owner",
        },
        name: "Test Community",
      },
      message: {
        threadId: "",
        senderId: "owner-1",
        type: "text",
        text: "Welcome!",
      },
    });

    await wait(500);

    // Member can send message (is a member)
    const messageFromMember = await member.messageService.sendMessage({
      threadId: thread.id,
      message: {
        text: "Thanks for inviting me!",
      },
    });

    expect((messageFromMember as any).text).toBe("Thanks for inviting me!");
  });
});
