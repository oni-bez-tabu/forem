/**
 * Centralny logger dla chat-sdk
 * 
 * Logowanie jest kontrolowane przez zmienną środowiskową CHAT_SDK_DEBUG:
 * - Node.js: process.env.CHAT_SDK_DEBUG
 * - Przeglądarka: window.__CHAT_SDK_DEBUG__ lub localStorage.getItem('CHAT_SDK_DEBUG')
 * 
 * Wartości uznawane za "włączone": 'true', '1', 'yes', 'on' (case-insensitive)
 * Gdy debug jest wyłączony, logger jest no-op (zero overhead w produkcji)
 */

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

/**
 * Sprawdza czy debug jest włączony (sprawdzane dynamicznie przy każdym wywołaniu)
 */
function isDebugEnabled(): boolean {
  // Node.js / Firebase Functions
  if (typeof process !== 'undefined' && process.env) {
    const envValue = process.env.CHAT_SDK_DEBUG;
    if (envValue) {
      const normalized = envValue.toLowerCase().trim();
      return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
    }
  }

  // Przeglądarka - window.__CHAT_SDK_DEBUG__
  if (typeof window !== 'undefined') {
    const windowValue = (window as any).__CHAT_SDK_DEBUG__;
    if (windowValue !== undefined) {
      if (typeof windowValue === 'boolean') return windowValue;
      if (typeof windowValue === 'string') {
        const normalized = windowValue.toLowerCase().trim();
        return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
      }
    }

    // Przeglądarka - localStorage
    try {
      const storageValue = localStorage.getItem('CHAT_SDK_DEBUG');
      if (storageValue) {
        const normalized = storageValue.toLowerCase().trim();
        return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
      }
    } catch {
      // localStorage może być niedostępny (np. w trybie incognito)
    }
  }

  return false;
}

/**
 * Logger z możliwością włączania/wyłączania przez flagę debugowania
 * Sprawdza flagę dynamicznie przy każdym wywołaniu, więc można włączyć/wyłączyć w runtime
 */
export const logger = {
  debug: (...args: unknown[]): void => {
    if (isDebugEnabled()) {
      console.log(...args);
    }
  },

  info: (...args: unknown[]): void => {
    if (isDebugEnabled()) {
      console.info(...args);
    }
  },

  warn: (...args: unknown[]): void => {
    if (isDebugEnabled()) {
      console.warn(...args);
    }
  },

  error: (...args: unknown[]): void => {
    if (isDebugEnabled()) {
      console.error(...args);
    }
  },
};
