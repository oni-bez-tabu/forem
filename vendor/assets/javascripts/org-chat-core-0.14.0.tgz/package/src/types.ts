// Public types for chat-core SDK (MVP) as defined in SPEC_CHAT_CORE.md.

export type ThreadType = "direct" | "group" | "community";
export type CommunityRole = "owner" | "moderator" | "member";
export type MessageType = "text" | "image";
export type MessageValidationErrorCode = "EMPTY_MESSAGE" | "IMAGE_ONLY_NOT_ALLOWED" | "TEXT_TOO_LONG";
export type ThreadValidationErrorCode =
  | "THREAD_NOT_FOUND"
  | "NOT_THREAD_MEMBER"
  | "LEAVE_NOT_ALLOWED"
  | "CONSENT_REQUIRED"
  | "DIRECT_MEMBERS_INVALID"
  | "DIRECT_ALREADY_EXISTS"
  | "DIRECT_NAME_NOT_ALLOWED"
  | "GROUP_MEMBERS_INVALID"
  | "COMMUNITY_MEMBERS_INVALID"
  | "COMMUNITY_NAME_REQUIRED"
  | "WAIT_FOR_REPLY";
export type RateLimitErrorCode = "RATE_LIMIT_EXCEEDED" | "TEMP_CHAT_SUSPENDED";
export type MessageDomainErrorCode =
  | MessageValidationErrorCode
  | "CHAT_GLOBALLY_BANNED"
  | "USER_BANNED_IN_COMMUNITY"
  | "NOT_AUTHORIZED"
  | "USER_BLOCKED"
  | "REPLY_NOT_FOUND"
  | "MESSAGE_NOT_FOUND"
  | RateLimitErrorCode
  | ThreadValidationErrorCode;

// Firestore-agnostic timestamp shape
export interface Timestamp {
  seconds: number;
  nanoseconds: number;
}

export interface ReplyTo {
  messageId: string;
  senderId: string;
  text?: string;
  imageUrl?: string;
}

export interface LastMessage {
  id: string;
  clientMessageId?: string;
  senderId: string;
  text?: string;
  imageUrl?: string;
  createdAt: Timestamp;
}

export interface Thread {
  id: string;
  type: ThreadType;
  members: string[]; // userId[]
  createdAt: Timestamp;
  lastMessage?: LastMessage;
  name?: string;
  directUnlocked?: boolean;
  acceptedBy?: string[];
  roles?: Record<string, CommunityRole>;
  bannedMembers?: string[];
  unreadCount: number;
}

export interface Message {
  id: string;
  clientMessageId?: string;
  threadId: string;
  senderId: string;
  type: MessageType;
  text?: string;
  imageUrl?: string;
  replyTo?: ReplyTo;
  likes: string[];   // userId[]
  readBy: string[];  // userId[]
  mentions?: string[]; // userId[]
  createdAt: Timestamp;
}

export interface UserProfile {
  username?: string;
  displayName?: string;
  avatarUrl?: string;
}

export interface ThreadUserPreferences {
  threadId: string;
  userId: string;
  muted: boolean;
  mutedAt?: Timestamp;
}

export type SendMessageInput = {
  clientMessageId?: string;
  text?: string;
  imageUrl?: string;
  replyToId?: string;
};

export type SendMessageRequest =
  | {
      threadId: string;
      message: SendMessageInput;
    }
  | {
      threadType: ThreadType;
      members: string[];
      name?: string;
      message: SendMessageInput;
    };

const messageValidationMessages: Record<MessageValidationErrorCode, string> = {
  EMPTY_MESSAGE: "Message must contain text",
  IMAGE_ONLY_NOT_ALLOWED: "Image-only messages are not allowed",
  TEXT_TOO_LONG: "Message text is too long",
};

export class MessageValidationError extends Error {
  readonly code: MessageValidationErrorCode;

  constructor(code: MessageValidationErrorCode, customMessage?: string) {
    super(customMessage ?? messageValidationMessages[code]);
    this.name = "MessageValidationError";
    this.code = code;
    Object.setPrototypeOf(this, MessageValidationError.prototype);
  }
}

export class ReplyNotFoundError extends Error {
  readonly code: "REPLY_NOT_FOUND" = "REPLY_NOT_FOUND";

  constructor() {
    super("Reply target not found");
    this.name = "ReplyNotFoundError";
    Object.setPrototypeOf(this, ReplyNotFoundError.prototype);
  }
}

export class MessageNotFoundError extends Error {
  readonly code: "MESSAGE_NOT_FOUND" = "MESSAGE_NOT_FOUND";

  constructor() {
    super("Message not found");
    this.name = "MessageNotFoundError";
    Object.setPrototypeOf(this, MessageNotFoundError.prototype);
  }
}

const threadValidationMessages: Record<ThreadValidationErrorCode, string> = {
  THREAD_NOT_FOUND: "Thread not found",
  NOT_THREAD_MEMBER: "User is not a member of the thread",
  LEAVE_NOT_ALLOWED: "Cannot leave this thread",
  CONSENT_REQUIRED: "CONSENT_REQUIRED",
  DIRECT_MEMBERS_INVALID: "Wątki direct wymagają dokładnie 2 unikalnych członków",
  DIRECT_ALREADY_EXISTS: "Direct thread for this user pair already exists",
  DIRECT_NAME_NOT_ALLOWED: "Direct threads cannot have a name",
  GROUP_MEMBERS_INVALID: "Wątki grupowe wymagają od 2 do 8 członków",
  COMMUNITY_MEMBERS_INVALID: "Wątki community wymagają od 2 do 8 członków",
  COMMUNITY_NAME_REQUIRED: "Wątki community muszą mieć nazwę",
  WAIT_FOR_REPLY: "Wait for the other user to reply",
};

export class ThreadValidationError extends Error {
  readonly code: ThreadValidationErrorCode;

  constructor(code: ThreadValidationErrorCode) {
    super(threadValidationMessages[code]);
    this.name = "ThreadValidationError";
    this.code = code;
    Object.setPrototypeOf(this, ThreadValidationError.prototype);
  }
}

const authDomainMessages: Record<
  Extract<MessageDomainErrorCode, "CHAT_GLOBALLY_BANNED" | "NOT_AUTHORIZED" | "USER_BANNED_IN_COMMUNITY" | "USER_BLOCKED">,
  string
> = {
  CHAT_GLOBALLY_BANNED: "User is globally banned from chat",
  NOT_AUTHORIZED: "User is not authorized to perform this action",
  USER_BANNED_IN_COMMUNITY: "User is banned in this community",
  USER_BLOCKED: "User is blocked",
};

export class ChatGloballyBannedError extends Error {
  readonly code: "CHAT_GLOBALLY_BANNED" = "CHAT_GLOBALLY_BANNED";

  constructor() {
    super(authDomainMessages.CHAT_GLOBALLY_BANNED);
    this.name = "ChatGloballyBannedError";
    Object.setPrototypeOf(this, ChatGloballyBannedError.prototype);
  }
}

export class NotAuthorizedError extends Error {
  readonly code: "NOT_AUTHORIZED" = "NOT_AUTHORIZED";

  constructor() {
    super(authDomainMessages.NOT_AUTHORIZED);
    this.name = "NotAuthorizedError";
    Object.setPrototypeOf(this, NotAuthorizedError.prototype);
  }
}

export class UserBannedInCommunityError extends Error {
  readonly code: "USER_BANNED_IN_COMMUNITY" = "USER_BANNED_IN_COMMUNITY";

  constructor() {
    super(authDomainMessages.USER_BANNED_IN_COMMUNITY);
    this.name = "UserBannedInCommunityError";
    Object.setPrototypeOf(this, UserBannedInCommunityError.prototype);
  }
}

export class UserBlockedError extends Error {
  readonly code: "USER_BLOCKED" = "USER_BLOCKED";

  constructor() {
    super(authDomainMessages.USER_BLOCKED);
    this.name = "UserBlockedError";
    Object.setPrototypeOf(this, UserBlockedError.prototype);
  }
}

const rateLimitMessages: Record<RateLimitErrorCode, string> = {
  RATE_LIMIT_EXCEEDED: "Rate limit exceeded",
  TEMP_CHAT_SUSPENDED: "Chat temporarily suspended due to abuse",
};

export class RateLimitExceededError extends Error {
  readonly code: "RATE_LIMIT_EXCEEDED" = "RATE_LIMIT_EXCEEDED";

  constructor() {
    super(rateLimitMessages.RATE_LIMIT_EXCEEDED);
    this.name = "RateLimitExceededError";
    Object.setPrototypeOf(this, RateLimitExceededError.prototype);
  }
}

export class TempChatSuspendedError extends Error {
  readonly code: "TEMP_CHAT_SUSPENDED" = "TEMP_CHAT_SUSPENDED";
  readonly suspendedUntilMs?: number;

  constructor(suspendedUntilMs?: number) {
    super(rateLimitMessages.TEMP_CHAT_SUSPENDED);
    this.name = "TempChatSuspendedError";
    this.suspendedUntilMs = suspendedUntilMs;
    Object.setPrototypeOf(this, TempChatSuspendedError.prototype);
  }
}

export interface ChatClient {
  init(): Promise<void>;
  getThreads(): Promise<Thread[]>;
  subscribeThreads(onChange: (threads: Thread[]) => void): () => void;
  openThread(
    threadId: string,
    onMessage: (message: Message) => void
  ): Promise<() => void>;
  getUnreadCount(threadId: string): Promise<number>;
  sendMessage(input: SendMessageRequest): Promise<Thread | void>;
  likeMessage(threadId: string, messageId: string): Promise<void>;
  unlikeMessage(threadId: string, messageId: string): Promise<void>;
  markAsRead(threadId: string, messageId: string): Promise<void>;
  fetchMessages(
    threadId: string,
    options?: { limit?: number; beforeMessageId?: string }
  ): Promise<Message[]>;
  acceptThread(threadId: string): Promise<void>;
  leaveThread(threadId: string): Promise<void>;
  banUserFromCommunity(threadId: string, userId: string): Promise<void>;
  unbanUserFromCommunity(threadId: string, userId: string): Promise<void>;
  blockUser(userId: string): Promise<void>;
  unblockUser(userId: string): Promise<void>;
  isUserBlocked(userId: string): Promise<boolean>;
  setTyping(threadId: string, isTyping: boolean): Promise<void>;
  subscribeTyping(threadId: string, onChange: (userIds: string[]) => void): () => void;
  subscribeTotalUnread(onChange: (count: number) => void): () => void;
  muteThread(threadId: string): Promise<void>;
  unmuteThread(threadId: string): Promise<void>;
  getThreadUserPrefs(threadId: string): Promise<ThreadUserPreferences>;
  subscribeUserProfile(userId: string, onChange: (profile: UserProfile | undefined) => void): () => void;
  uploadImage(file: File): Promise<string>;
  uploadImageBase64(data: { base64: string; mimeType: string; fileName: string }): Promise<string>;
}