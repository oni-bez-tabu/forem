import { describe, expect, it } from "vitest";
import type {
  ChatClient,
  LastMessage,
  Message,
  MessageType,
  ReplyTo,
  Thread,
  ThreadType,
  Timestamp,
  SendMessageInput,
  SendMessageRequest,
} from "./types";

type Assert<T extends true> = T;
type Equals<A, B> =
  (<T>() => T extends A ? 1 : 2) extends (<T>() => T extends B ? 1 : 2)
    ? true
    : false;

const mockTimestamp: Timestamp = {
  seconds: 0,
  nanoseconds: 0,
};

// Type-level coverage of public surface
type _ThreadTypeUnion = Assert<
  Equals<ThreadType, "direct" | "group" | "community">
>;
type _MessageTypeUnion = Assert<Equals<MessageType, "text" | "image">>;
type _ThreadMembersAreStrings = Assert<Equals<Thread["members"], string[]>>;
type _MessageLikesAreStrings = Assert<Equals<Message["likes"], string[]>>;
type _MessageReadByAreStrings = Assert<Equals<Message["readBy"], string[]>>;
type _ReplyToOptionalFields = Assert<
  Equals<ReplyTo["text" | "imageUrl"], string | undefined>
>;
type _LastMessageOptionalFields = Assert<
  Equals<LastMessage["text" | "imageUrl"], string | undefined>
>;
type _ChatClientSignature = Assert<
  Equals<
    ChatClient["openThread"],
    (threadId: string, onMessage: (message: Message) => void) => Promise<() => void>
  >
>;
type _ChatClientSendMessageSignature = Assert<
  Equals<ChatClient["sendMessage"], (input: SendMessageRequest) => Promise<Thread | void>>
>;

describe("types", () => {
  it("accepts the plain timestamp shape", () => {
    expect(mockTimestamp).toMatchObject({ seconds: 0, nanoseconds: 0 });
  });

  it("accepts a valid thread and message shape", () => {
    const thread: Thread = {
      id: "thread-1",
      type: "direct",
      members: ["u1", "u2"],
      createdAt: mockTimestamp,
      unreadCount: 0,
      lastMessage: {
        id: "msg-1",
        senderId: "u1",
        text: "hi",
        createdAt: mockTimestamp,
      },
    };

    const message: Message = {
      id: "msg-1",
      threadId: "thread-1",
      senderId: "u1",
      type: "text",
      text: "hi",
      replyTo: {
        messageId: "msg-0",
        senderId: "u2",
        text: "prev",
      },
      likes: ["u2"],
      readBy: ["u1", "u2"],
      createdAt: mockTimestamp,
    };

    expect(thread.lastMessage?.id).toBe("msg-1");
    expect(message.replyTo?.messageId).toBe("msg-0");
  });

  it("accepts an image message shape", () => {
    const message: Message = {
      id: "msg-2",
      threadId: "thread-1",
      senderId: "u1",
      type: "image",
      text: "caption",
      imageUrl: "https://example.com/image.png",
      likes: [],
      readBy: [],
      createdAt: mockTimestamp,
    };

    expect(message.type).toBe("image");
    expect(message.imageUrl).toBeDefined();
  });
});

