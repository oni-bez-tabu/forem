import type { JSX } from "preact";
import type { Thread } from "@org/chat-core";
import { Composer } from "./Composer";
import { MessageItem } from "./MessageItem";
import { AcceptConversation } from "./AcceptConversation";
import { useEffect, useMemo, useRef, useState } from "preact/hooks";
import { useChatClient, useChatContext, useUserProfile, useThreadState } from "@org/chat-ui-shared";
import type { UiMessage } from "@org/chat-ui-shared";
import { useChatStyles } from "../hooks/useChatStyles";

export interface ThreadViewProps {
  threadId: string;
  thread?: Thread | null;
  currentUserId: string;
  isActive?: boolean;
  onThreadActivity?: () => Promise<void> | void;
  onThreadLeft?: () => void;
  onBack?: () => void;
}

export function ThreadView({
  threadId,
  thread,
  currentUserId,
  isActive = true,
  onThreadActivity,
  onThreadLeft,
  onBack,
}: ThreadViewProps): JSX.Element {
  useChatStyles();
  const client = useChatClient();
  const [actionError, setActionError] = useState<string | null>(null);
  const [prefsLoading, setPrefsLoading] = useState(false);
  const [threadMuted, setThreadMuted] = useState<boolean | null>(null);
  const [blockLoading, setBlockLoading] = useState(false);
  const [isBlocked, setIsBlocked] = useState<boolean | null>(null);
  const [optionsOpen, setOptionsOpen] = useState(false);
  const [moderationLoading, setModerationLoading] = useState<string | null>(null);
  const [leaveLoading, setLeaveLoading] = useState(false);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const { ensureProfileSubscription, getProfile } = useChatContext();
  const {
    messages,
    replyingTo,
    setReplyingTo,
    clearReply,
    send,
    retry,
    likeMessage,
    unlikeMessage,
    sendError,
    clearError,
    canSend,
    typingUsers,
    onTyping,
    onStopTyping,
    loadOlder,
    loadingOlder,
    hasMoreOlder,
  } = useThreadState({
    threadId,
    thread,
    currentUserId,
    isActive,
    onThreadActivity,
  });

  const otherUserId = thread?.type === "direct" ? thread.members.find((m) => m !== currentUserId) : null;
  const otherUserProfile = useUserProfile(otherUserId);
  const currentRole = thread?.roles?.[currentUserId];
  const canModerate = thread?.type === "community" && (currentRole === "owner" || currentRole === "moderator");
  const messagesRef = useRef<HTMLDivElement | null>(null);
  const anchorRef = useRef<{ prevHeight: number; prevTop: number } | null>(null);
  const [historyAttempted, setHistoryAttempted] = useState(false);

  useEffect(() => {
    setHistoryAttempted(false);
  }, [threadId]);
  const typingNames = useMemo(
    () => typingUsers.map((id) => getProfile(id)?.displayName ?? id),
    [typingUsers, getProfile]
  );

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      if (!thread) {
        setThreadMuted(null);
        setIsBlocked(null);
        return;
      }
      setPrefsLoading(true);
      try {
        const prefs = await client.getThreadUserPrefs(thread.id);
        if (!cancelled) {
          setThreadMuted(Boolean(prefs?.muted));
        }
      } catch (err) {
        if (!cancelled) {
          setActionError(err instanceof Error ? err.message : "Nie udało się pobrać preferencji wątku");
        }
      } finally {
        if (!cancelled) {
          setPrefsLoading(false);
        }
      }
      if (thread.type === "direct" && otherUserId) {
        try {
          const blocked = await client.isUserBlocked(otherUserId);
          if (!cancelled) {
            setIsBlocked(blocked);
          }
        } catch (err) {
          if (!cancelled) {
            setActionError(err instanceof Error ? err.message : "Nie udało się sprawdzić blokady");
          }
        }
      } else {
        setIsBlocked(null);
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [client, thread, threadId, otherUserId]);

  useEffect(() => {
    const unique = Array.from(new Set(typingUsers));
    unique.forEach((id) => ensureProfileSubscription(id));
  }, [typingUsers, ensureProfileSubscription]);

  useEffect(() => {
    if (!thread) return;
    thread.members.forEach((id) => ensureProfileSubscription(id));
  }, [thread, ensureProfileSubscription]);

  useEffect(() => {
    const handler = () => setOptionsOpen(false);
    if (optionsOpen) {
      document.addEventListener("click", handler);
    }
    return () => document.removeEventListener("click", handler);
  }, [optionsOpen]);

  // Scroll do dołu przy wejściu do wątku oraz po nowych wiadomościach
  useEffect(() => {
    const el = messagesRef.current;
    if (!el) return;

    // Use double requestAnimationFrame to ensure DOM is fully rendered
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (anchorRef.current) {
          const { prevHeight, prevTop } = anchorRef.current;
          const delta = el.scrollHeight - prevHeight;
          el.scrollTop = prevTop + delta;
          anchorRef.current = null;
        } else {
          el.scrollTop = el.scrollHeight;
        }
      });
    });
  }, [threadId, messages.length]);

  // Additional scroll to bottom on initial mount with messages
  const initialScrollDone = useRef(false);
  useEffect(() => {
    if (messages.length > 0 && !initialScrollDone.current) {
      initialScrollDone.current = true;
      const el = messagesRef.current;
      if (el) {
        // Small delay to ensure layout is complete
        setTimeout(() => {
          el.scrollTop = el.scrollHeight;
        }, 50);
      }
    }
  }, [messages.length]);

  // Reset initial scroll flag when thread changes
  useEffect(() => {
    initialScrollDone.current = false;
  }, [threadId]);

  const toggleMute = async () => {
    if (!thread) return;
    setActionError(null);
    setPrefsLoading(true);
    try {
      if (threadMuted) {
        await client.unmuteThread(thread.id);
        setThreadMuted(false);
      } else {
        await client.muteThread(thread.id);
        setThreadMuted(true);
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : "Nie udało się zaktualizować wyciszenia");
    } finally {
      setPrefsLoading(false);
    }
  };

  const toggleBlock = async () => {
    if (!thread || thread.type !== "direct" || !otherUserId) return;
    setActionError(null);
    setBlockLoading(true);
    try {
      const blocked = await client.isUserBlocked(otherUserId);
      if (blocked) {
        await client.unblockUser(otherUserId);
        setIsBlocked(false);
      } else {
        await client.blockUser(otherUserId);
        setIsBlocked(true);
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : "Nie udało się zaktualizować blokady");
    } finally {
      setBlockLoading(false);
    }
  };

  const toggleCommunityBan = async (member: string, banned: boolean) => {
    if (!thread || thread.type !== "community") return;
    setActionError(null);
    setModerationLoading(member);
    try {
      if (banned) {
        await client.unbanUserFromCommunity(thread.id, member);
      } else {
        await client.banUserFromCommunity(thread.id, member);
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : "Nie udało się zaktualizować użytkownika");
    } finally {
      setModerationLoading(null);
    }
  };

  const handleLeaveConfirmed = async () => {
    if (!thread || (thread.type !== "group" && thread.type !== "community")) return;
    setActionError(null);
    setLeaveLoading(true);
    // Optymistycznie zamknij widok zanim backend potwierdzi
    onThreadLeft?.();
    try {
      await client.leaveThread(thread.id);
      await onThreadActivity?.();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : "Nie udało się opuścić wątku");
    } finally {
      setLeaveLoading(false);
      setOptionsOpen(false);
      setShowLeaveConfirm(false);
    }
  };

  const displayNameFor = (id: string): string =>
    getProfile(id)?.displayName ?? getProfile(id)?.username ?? id;
  const usernameFor = (id: string): string =>
    getProfile(id)?.username ?? id;

  const headerTitle =
    thread?.name && thread.name.trim().length > 0
      ? thread.name
      : thread
      ? thread.members.filter((m) => m !== currentUserId).map(displayNameFor).join(", ")
      : "Wątek";

  const memberUsernames = (thread?.members ?? []).map((id) => `@${usernameFor(id)}`);
  const headerSubtitle =
    thread?.type === "direct" && otherUserId
      ? `@${usernameFor(otherUserId)}`
      : thread && (thread.type === "group" || thread.type === "community")
      ? memberUsernames.join(", ")
      : thread
      ? thread.type
      : "";

  const draftsRef = useRef<Record<string, string>>({});
  const [draft, setDraft] = useState<string>("");

  useEffect(() => {
    const next = draftsRef.current[threadId] ?? "";
    setDraft(next);
    requestAnimationFrame(() => {
      const input = document.querySelector<HTMLTextAreaElement>("textarea[data-composer]");
      if (input) {
        input.style.height = "auto";
        input.style.height = `${Math.min(input.scrollHeight, 96)}px`;
      }
    });
  }, [threadId]);

  const handleDraftChange = (value: string) => {
    draftsRef.current[threadId] = value;
    setDraft(value);
  };
  const groupPrimaryMember = thread?.members.find((m) => m !== currentUserId) ?? thread?.members[0];
  const groupPrimaryProfile = groupPrimaryMember ? getProfile(groupPrimaryMember) : undefined;
  const headerAvatar =
    thread?.type === "direct"
      ? otherUserProfile?.avatarUrl
      : (thread as Partial<Thread> & { avatarUrl?: string }).avatarUrl ?? groupPrimaryProfile?.avatarUrl;
  const headerFallback = headerTitle?.trim()?.slice(0, 2).toUpperCase() || "??";

  return (
    <div className="chat-sdk-root flex h-full min-h-0 flex-col bg-light-bg text-light-text-primary dark:bg-dark-bg dark:text-dark-text-primary">
      <header className="flex items-center justify-between border-b border-light-border px-3 py-3 dark:border-dark-border">
        <div className="flex items-center gap-3">
          {/* Przycisk powrotu - widoczny tylko na mobile */}
          {onBack ? (
            <button
              type="button"
              onClick={onBack}
              className="flex items-center justify-center rounded-full p-2 text-light-text-secondary transition-colors hover:bg-light-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-bg-tertiary lg:hidden"
              aria-label="Wróć do listy wątków"
            >
              <i className="fa-solid fa-arrow-left" />
            </button>
          ) : null}
          
          {headerAvatar ? (
            <img src={headerAvatar} alt={headerTitle} className="h-10 w-10 rounded-full object-cover" />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-sky-500 text-sm font-semibold text-white">
              {headerFallback}
            </div>
          )}
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold">{headerTitle || "Wątek"}</h2>
              {threadMuted ? (
                <i
                  className="fa-solid fa-bell-slash text-light-text-tertiary dark:text-dark-text-tertiary text-xs"
                  title="Wątek wyciszony"
                  aria-label="Wątek wyciszony"
                />
              ) : null}
              {thread?.type === "direct" && isBlocked ? (
                <i
                  className="fa-solid fa-ban text-red-500 text-xs"
                  title="Użytkownik zablokowany"
                  aria-label="Użytkownik zablokowany"
                />
              ) : null}
            </div>
            {headerSubtitle ? (
              <p className="text-xs text-light-text-tertiary dark:text-dark-text-tertiary">{headerSubtitle}</p>
            ) : null}
          </div>
        </div>
        <div className="relative">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setOptionsOpen((v) => !v);
            }}
            className="rounded-full p-2 text-light-text-secondary transition-colors hover:bg-light-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-bg-tertiary"
            aria-label="Opcje wątku"
          >
            <i className="fa-solid fa-ellipsis-vertical" />
          </button>
          {optionsOpen ? (
            <div
              className="absolute right-0 mt-2 w-56 rounded-xl border border-light-border bg-light-bg shadow-2xl dark:border-dark-border dark:bg-dark-bg-secondary z-50"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={toggleMute}
                className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-light-text-primary transition-colors hover:bg-light-bg-tertiary dark:text-dark-text-primary dark:hover:bg-dark-bg-tertiary"
              >
                {prefsLoading ? <span className="text-xs">...</span> : <i className="fa-solid fa-bell-slash" />}
                {threadMuted ? "Włącz powiadomienia" : "Wycisz powiadomienia"}
              </button>
            {thread && (thread.type === "group" || thread.type === "community") ? (
              <button
                type="button"
                onClick={() => {
                  setOptionsOpen(false);
                  setShowLeaveConfirm(true);
                }}
                disabled={leaveLoading}
                className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-red-500 transition-colors hover:bg-light-bg-tertiary dark:hover:bg-dark-bg-tertiary"
              >
                {leaveLoading ? <span className="text-xs">...</span> : <i className="fa-solid fa-door-open" />}
                Opuść wątek
              </button>
            ) : null}
              {thread?.type === "direct" && otherUserId ? (
                <button
                  type="button"
                  onClick={() => {
                    if (isBlocked) {
                      void toggleBlock();
                    } else {
                      setOptionsOpen(false);
                      setShowBlockConfirm(true);
                    }
                  }}
                  className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-light-text-primary transition-colors hover:bg-light-bg-tertiary dark:text-dark-text-primary dark:hover:bg-dark-bg-tertiary"
                  disabled={blockLoading}
                >
                  {blockLoading ? <span className="text-xs">...</span> : <i className="fa-solid fa-ban" />}
                  {isBlocked ? "Odblokuj użytkownika" : "Zablokuj użytkownika"}
                </button>
              ) : null}
              {thread?.type === "community" && canModerate && thread.members.length > 0 ? (
                <div className="border-t border-light-border px-4 py-2 text-xs font-semibold text-light-text-tertiary dark:border-dark-border dark:text-dark-text-tertiary">
                  Zarządzaj użytkownikami
                  <div className="mt-2 space-y-1">
                    {thread.members
                      .filter((m) => m !== currentUserId)
                      .map((member) => {
                        const banned = (thread.bannedMembers ?? []).includes(member);
                        return (
                          <button
                            key={member}
                            type="button"
                            onClick={() => void toggleCommunityBan(member, banned)}
                            className="flex w-full items-center justify-between rounded-lg px-2 py-1 text-left text-[12px] text-light-text-primary hover:bg-light-bg-tertiary dark:text-dark-text-primary dark:hover:bg-dark-bg-tertiary"
                            disabled={moderationLoading === member}
                          >
                            <span className="truncate">@{member}</span>
                            <span className="text-[11px] text-light-text-secondary dark:text-dark-text-secondary">
                              {moderationLoading === member ? "..." : banned ? "Odbanuj" : "Banuj"}
                            </span>
                          </button>
                        );
                      })}
                  </div>
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      </header>

      {actionError ? (
        <div className="bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-900/20 dark:text-red-200">{actionError}</div>
      ) : null}

      {thread ? <AcceptConversation thread={thread} currentUserId={currentUserId} /> : null}

      <div
        ref={messagesRef}
        className="flex-1 min-h-0 overflow-y-auto px-2 sm:px-3 md:px-4 lg:px-6 py-6 pb-14"
        onScroll={(e) => {
          const el = e.currentTarget;
          if (el.scrollTop < 80 && hasMoreOlder && !loadingOlder) {
            anchorRef.current = { prevHeight: el.scrollHeight, prevTop: el.scrollTop };
            setHistoryAttempted(true);
            void loadOlder();
          }
        }}
      >
        <div className="flex flex-col items-center pb-2">
          {loadingOlder ? (
            <div className="text-xs text-light-text-tertiary dark:text-dark-text-tertiary py-2">Ładowanie...</div>
          ) : null}
          {historyAttempted && !hasMoreOlder && messages.length > 0 && !loadingOlder ? (
            <div className="text-[11px] text-light-text-tertiary dark:text-dark-text-tertiary py-1">Brak starszych wiadomości</div>
          ) : null}
        </div>
        {messages.map((message: UiMessage, index: number) => {
          const prev = index > 0 ? messages[index - 1] : null;
          const createdAtMs = (m: UiMessage) => m.createdAt.seconds * 1000 + Math.floor(m.createdAt.nanoseconds / 1_000_000);
          const groupedWithPrevious =
            prev &&
            prev.senderId === message.senderId &&
            createdAtMs(message) - createdAtMs(prev) <= 60_000;

          return (
            <div key={message.id} className={index === 0 ? "" : groupedWithPrevious ? "mt-2" : "mt-6"}>
              <MessageItem
                message={message}
                currentUserId={currentUserId}
                onReply={setReplyingTo}
                onLike={(id) => void likeMessage(id)}
                onUnlike={(id) => void unlikeMessage(id)}
                onRetry={message.localId ? (localId) => void retry(localId) : undefined}
                groupedWithPrevious={Boolean(groupedWithPrevious)}
              />
            </div>
          );
        })}
      </div>

      <div className="relative border-t border-light-border px-4 pt-4 pb-4 dark:border-dark-border">
        {typingUsers.length > 0 ? (
          <div className="pointer-events-none absolute -top-8 left-4 inline-flex items-center gap-2 rounded-full bg-light-bg-secondary px-3 py-1 text-[12px] text-light-text-secondary shadow-sm dark:bg-dark-bg-tertiary dark:text-dark-text-secondary">
            <span className="truncate max-w-[180px]">
              {typingNames.join(", ")} {typingUsers.length === 1 ? "pisze" : "piszą"}
            </span>
            <div className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-light-text-secondary dark:bg-dark-text-secondary" style={{ animationDelay: "0ms" }} />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-light-text-secondary dark:bg-dark-text-secondary" style={{ animationDelay: "120ms" }} />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-light-text-secondary dark:bg-dark-text-secondary" style={{ animationDelay: "240ms" }} />
            </div>
          </div>
        ) : null}

        <Composer
          onSend={send}
          replyingTo={replyingTo}
          error={sendError}
          onClearError={clearError}
          onCancelReply={clearReply}
          disabled={!canSend}
          onTyping={onTyping}
          onStopTyping={onStopTyping}
          autoFocus
          thread={thread}
          threadId={threadId}
          draft={draft}
          onDraftChange={handleDraftChange}
          currentUserId={currentUserId}
        />
      </div>

      {showLeaveConfirm ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-sm rounded-2xl border border-light-border bg-light-bg p-6 shadow-2xl dark:border-dark-border dark:bg-dark-bg-secondary">
            <h3 className="text-lg font-bold text-light-text-primary dark:text-dark-text-primary">Opuścić wątek?</h3>
            <p className="mt-2 text-sm text-light-text-secondary dark:text-dark-text-secondary">
              Nie będziesz już widzieć nowych wiadomości w tym wątku.
            </p>
            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowLeaveConfirm(false)}
                className="rounded-lg px-4 py-2 text-sm font-semibold text-light-text-secondary hover:bg-light-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-bg-tertiary"
              >
                Anuluj
              </button>
              <button
                type="button"
                onClick={() => void handleLeaveConfirmed()}
                disabled={leaveLoading}
                className="rounded-lg bg-red-500 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-600 disabled:opacity-60"
              >
                {leaveLoading ? "Opuszczanie..." : "Opuść wątek"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {showBlockConfirm && thread?.type === "direct" && otherUserId ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-sm rounded-2xl border border-light-border bg-light-bg p-6 shadow-2xl dark:border-dark-border dark:bg-dark-bg-secondary">
            <h3 className="text-lg font-bold text-light-text-primary dark:text-dark-text-primary">Zablokować użytkownika?</h3>
            <p className="mt-2 text-sm text-light-text-secondary dark:text-dark-text-secondary">
              Nie dostaniesz wiadomości ani powiadomień od tego użytkownika. Możesz go później odblokować z poziomu wątku.
            </p>
            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowBlockConfirm(false)}
                className="rounded-lg px-4 py-2 text-sm font-semibold text-light-text-secondary hover:bg-light-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-bg-tertiary"
              >
                Anuluj
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowBlockConfirm(false);
                  void toggleBlock();
                }}
                disabled={blockLoading}
                className="rounded-lg bg-red-500 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-600 disabled:opacity-60"
              >
                {blockLoading ? "Blokuję..." : "Zablokuj"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}


