import type { JSX } from "preact";
import { useEffect, useMemo, useRef, useState } from "preact/hooks";
import { useChatContext, useUserProfile } from "@org/chat-ui-shared";
import type { UiMessage } from "@org/chat-ui-shared";

const decodeTextarea = typeof document !== "undefined" ? document.createElement("textarea") : null;
function decodeEntities(text: string): string {
  if (!text || !decodeTextarea) return text;
  let current = text;
  for (let i = 0; i < 3; i += 1) {
    decodeTextarea.innerHTML = current;
    const next = decodeTextarea.value;
    if (next === current) {
      break;
    }
    current = next;
  }
  return current;
}

export interface MessageItemProps {
  message: UiMessage;
  currentUserId: string;
  onLike?: (messageId: string) => void;
  onUnlike?: (messageId: string) => void;
  onRetry?: (localId: string) => void;
  onReply?: (message: UiMessage) => void;
  groupedWithPrevious?: boolean;
}


function formatTime(message: UiMessage): string {
  const createdAtMs = message.createdAt.seconds * 1000 + Math.floor(message.createdAt.nanoseconds / 1_000_000);
  const date = new Date(createdAtMs);
  const now = new Date();

  const isSameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getFullYear() === yesterday.getFullYear() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getDate() === yesterday.getDate();

  const timePart = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  if (isSameDay) {
    return timePart;
  }
  if (isYesterday) {
    return `Wczoraj, ${timePart}`;
  }

  const datePart = date.toLocaleDateString([], {
    day: "2-digit",
    month: "short",
    year: date.getFullYear() === now.getFullYear() ? undefined : "numeric",
  });
  return `${datePart}, ${timePart}`;
}

export function MessageItem({ message, currentUserId, onLike, onUnlike, onRetry, onReply, groupedWithPrevious }: MessageItemProps): JSX.Element {
  const { ensureProfileSubscription, getProfile } = useChatContext();
  const isOwnMessage = message.senderId === currentUserId;
  const senderProfile = useUserProfile(message.senderId);
  const senderName = senderProfile?.displayName ?? message.senderId;
  const senderAvatar = senderProfile?.avatarUrl;
  const repliedSenderId = message.replyTo?.senderId;
  const repliedProfile = useUserProfile(repliedSenderId);
  const repliedName = repliedSenderId ? repliedProfile?.displayName ?? repliedSenderId : null;
  const interestedUserIds = useMemo(
    () => [message.senderId, repliedSenderId, ...(message.likes ?? [])].filter(Boolean) as string[],
    [message.senderId, repliedSenderId, message.likes]
  );
  useEffect(() => {
    const unique = Array.from(new Set(interestedUserIds));
    unique.forEach((id) => ensureProfileSubscription(id));
  }, [interestedUserIds, ensureProfileSubscription]);

  const canRetry = message.deliveryStatus === "failed" && Boolean(message.localId) && Boolean(onRetry);
  const timeLabel = formatTime(message);
  const likeCount = message.likes?.length ?? 0;
  const isLikedByCurrentUser = (message.likes ?? []).includes(currentUserId);
  const likeNames = (message.likes ?? []).map((id) => getProfile(id)?.displayName ?? id);
  const likesTooltip = likeNames.length > 0 ? likeNames.join(", ") : undefined;
  const [showLikesTooltip, setShowLikesTooltip] = useState(false);
  const rawMessageText = message.text?.trim() ?? "";
  const messageText = useMemo(() => decodeEntities(rawMessageText), [rawMessageText]);
  const repliedText = useMemo(() => decodeEntities(message.replyTo?.text ?? ""), [message.replyTo?.text]);
  const looksLikeFileName =
    Boolean(message.imageUrl) &&
    messageText.length > 0 &&
    /\.(png|jpe?g|gif|webp|bmp|svg|heic|heif)$/i.test(messageText);
  const showImage = Boolean(message.imageUrl);
  // Tekst powinien być widoczny także przy wiadomościach ze zdjęciem (regres: pokazywało się samo zdjęcie)
  const showText = messageText.length > 0 && (!looksLikeFileName || !showImage);
  const bubbleClasses = `relative inline-block max-w-[88vw] sm:max-w-xl rounded-2xl px-4 py-3 ${
    isOwnMessage
      ? "rounded-tr-none rounded-br-2xl rounded-bl-2xl rounded-tl-2xl bg-light-primary text-white dark:bg-dark-primary"
      : "rounded-tl-none rounded-tr-2xl rounded-br-2xl rounded-bl-2xl bg-light-bg-tertiary text-light-text-primary dark:bg-dark-bg-tertiary dark:text-dark-text-primary"
  }`;
  const textBubbleAlignment = isOwnMessage ? "self-end" : "self-start";
  const hasActions = Boolean(onReply || onLike || onUnlike || canRetry);
  const [showInlineActions, setShowInlineActions] = useState(false);
  const longPressTimer = useRef<number | null>(null);

  const clearLongPress = () => {
    if (longPressTimer.current !== null) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const handlePointerDown = (event: PointerEvent) => {
    // Na mobile aktywuj akcje po dłuższym przytrzymaniu
    if (event.pointerType === "touch") {
      clearLongPress();
      longPressTimer.current = window.setTimeout(() => {
        setShowInlineActions(true);
        longPressTimer.current = null;
      }, 350);
    }
  };

  const handlePointerUp = () => {
    clearLongPress();
  };

  useEffect(() => () => clearLongPress(), []);

  const handleActionClick = (action: () => void) => {
    action();
    setShowInlineActions(false);
  };

  const renderActions = (mode: "overlay" | "inline") => {
    if (!hasActions) return null;
    const baseBtns = (
      <>
        {onLike || onUnlike ? (
          <button
            type="button"
            onClick={() =>
              handleActionClick(() =>
                isLikedByCurrentUser ? onUnlike?.(message.id) : onLike?.(message.id)
              )
            }
            className="rounded-full p-1 hover:bg-light-bg-tertiary dark:hover:bg-dark-bg-tertiary"
            aria-label={isLikedByCurrentUser ? "Cofnij polubienie" : "Polub"}
          >
            <i className={`fa-solid fa-heart ${isLikedByCurrentUser ? "text-red-500" : ""}`} />
          </button>
        ) : null}
        {onReply ? (
          <button
            type="button"
            onClick={() => handleActionClick(() => onReply(message))}
            className="rounded-full p-1 hover:bg-light-bg-tertiary dark:hover:bg-dark-bg-tertiary"
            aria-label="Odpowiedz"
          >
            <i className="fa-solid fa-reply" />
          </button>
        ) : null}
        {canRetry && message.localId ? (
          <button
            type="button"
            onClick={() => handleActionClick(() => onRetry?.(message.localId as string))}
            className="rounded-full p-1 hover:bg-light-bg-tertiary dark:hover:bg-dark-bg-tertiary"
          >
            <i className="fa-solid fa-rotate-right" />
          </button>
        ) : null}
      </>
    );

    if (mode === "overlay") {
      return (
        <div
          className={`group-hover-actions absolute top-1/2 -translate-y-1/2 ${
            isOwnMessage ? "right-full mr-3" : "left-full ml-3"
          } hidden sm:flex items-center gap-1 rounded-full border border-light-border bg-light-bg-secondary px-1.5 py-1 text-[12px] text-light-text-secondary opacity-0 invisible transition-all duration-200 group-hover:visible group-hover:opacity-100 shadow-sm dark:border-dark-border dark:bg-dark-bg-secondary dark:text-dark-text-secondary`}
        >
          {baseBtns}
        </div>
      );
    }

    return showInlineActions ? (
      <div
        className={`mt-2 flex items-center gap-2 rounded-full border border-light-border bg-light-bg-secondary px-2 py-1 text-[12px] text-light-text-secondary sm:hidden ${
          isOwnMessage ? "self-end" : "self-start"
        } dark:border-dark-border dark:bg-dark-bg-secondary dark:text-dark-text-secondary`}
      >
        {baseBtns}
      </div>
    ) : null;
  };

  return (
    <div
      data-message-id={message.id}
      data-local-id={message.localId}
      className={`group flex items-start ${groupedWithPrevious ? "gap-2" : "gap-3"} ${
        isOwnMessage ? "justify-end" : "justify-start"
      }`}
    >
      {!isOwnMessage ? (
        groupedWithPrevious ? (
          <div className="h-8 w-8 shrink-0" aria-hidden="true" />
        ) : (
          <img
            src={senderAvatar ?? "https://placehold.co/32x32?text=?"}
            alt={senderName}
            className="h-8 w-8 shrink-0 rounded-full object-cover"
          />
        )
      ) : null}

      <div
        className={`flex flex-col ${isOwnMessage ? "items-end" : "items-start"} max-w-xl`}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerCancel={clearLongPress}
      >
        {!groupedWithPrevious ? (
          <div
            className={`mb-1 flex items-center gap-2 text-[11px] ${
              isOwnMessage
                ? "text-light-text-tertiary dark:text-dark-text-tertiary justify-end"
                : "text-light-text-tertiary dark:text-dark-text-tertiary"
            }`}
          >
            {!isOwnMessage ? (
              <>
                <span className="font-semibold text-light-text-primary dark:text-dark-text-primary text-sm">{senderName}</span>
                <span className="text-light-text-tertiary dark:text-dark-text-tertiary">@{getProfile(message.senderId)?.username ?? message.senderId}</span>
                <span>•</span>
                <span>{timeLabel}</span>
              </>
            ) : (
              <>
                <span>{timeLabel}</span>
                <span>•</span>
                <span className="text-light-text-tertiary dark:text-dark-text-tertiary">@{getProfile(message.senderId)?.username ?? message.senderId}</span>
                <span className="font-semibold text-light-text-primary dark:text-dark-text-primary text-sm">Ty</span>
              </>
            )}
          </div>
        ) : null}

        {message.replyTo ? (
          <div className="mb-2 mr-2 flex items-center gap-2 rounded-lg border-l-2 border-light-primary bg-light-bg-tertiary px-3 py-1.5 text-xs text-light-text-secondary dark:border-dark-primary dark:bg-dark-bg-tertiary dark:text-dark-text-secondary">
            <i className="fa-solid fa-reply text-[10px] text-light-text-tertiary dark:text-dark-text-tertiary" />
            <div className="flex-1 min-w-0">
              <p className="font-medium break-words break-all whitespace-pre-wrap">{repliedName ?? repliedSenderId ?? "Użytkownik"}</p>
              {message.replyTo.text ? (
                <p className="text-light-text-tertiary dark:text-dark-text-tertiary break-words break-all whitespace-pre-wrap">
                  {repliedText}
                </p>
              ) : null}
            </div>
          </div>
        ) : null}

        <div className={`relative flex max-w-full flex-col ${isOwnMessage ? "items-end" : "items-start"} gap-2`}>
          {showText ? (
            <div className={`${bubbleClasses} ${textBubbleAlignment}`}>
              <p className="text-sm leading-relaxed break-words break-all whitespace-pre-wrap">{messageText}</p>
            </div>
          ) : null}

          {showImage ? (
            <div className="overflow-hidden rounded-2xl">
              <img src={message.imageUrl} alt="Załączony obraz" className="h-auto max-h-64 w-full object-cover" />
            </div>
          ) : null}

          {renderActions("overlay")}
        </div>

        {renderActions("inline")}

        {likeCount > 0 ? (
          <div
            className={`relative mt-1 inline-flex items-center gap-2 text-xs ${isOwnMessage ? "mr-2" : "ml-2"}`}
            onMouseEnter={() => setShowLikesTooltip(true)}
            onMouseLeave={() => setShowLikesTooltip(false)}
            onFocus={() => setShowLikesTooltip(true)}
            onBlur={() => setShowLikesTooltip(false)}
            aria-label={likesTooltip}
          >
            <i className="fa-solid fa-heart text-red-500" />
            <span className="text-light-text-tertiary dark:text-dark-text-tertiary">{likeCount}</span>
            {showLikesTooltip && likesTooltip ? (
              <div className="absolute left-1/2 top-full z-40 mt-2 w-max max-w-[220px] -translate-x-1/2 rounded-lg bg-light-text-primary px-3 py-2 text-[11px] font-medium text-white shadow-lg dark:bg-dark-bg-tertiary dark:text-dark-text-primary">
                {likesTooltip}
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      {isOwnMessage ? (
        groupedWithPrevious ? (
          <div className="h-8 w-8 shrink-0" aria-hidden="true" />
        ) : (
          <img
            src={senderAvatar ?? "https://placehold.co/32x32?text=?"}
            alt={senderName}
            className="h-8 w-8 shrink-0 rounded-full object-cover"
          />
        )
      ) : null}
    </div>
  );
}

