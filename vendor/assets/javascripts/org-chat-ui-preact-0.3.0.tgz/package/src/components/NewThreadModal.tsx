import type { JSX } from "preact";
import { useEffect, useMemo, useRef, useState } from "preact/hooks";
import type { Thread } from "@org/chat-core";
import { logger } from "@org/chat-core";

type UserSearchResult = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string;
};

export interface NewThreadModalProps {
  open: boolean;
  onClose: () => void;
  onCreate: (input: {
    type: Thread["type"];
    members: string[];
    name?: string;
    message: { text: string };
  }) => Promise<void> | void;
  preselectedMember?: string | null;
  apiBaseUrl: string;
}

export function NewThreadModal({ open, onClose, onCreate, preselectedMember, apiBaseUrl }: NewThreadModalProps): JSX.Element | null {
  const [threadType, setThreadType] = useState<Thread["type"]>("direct");
  const [selectedMembers, setSelectedMembers] = useState<UserSearchResult[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<UserSearchResult[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [nameInput, setNameInput] = useState("");
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const searchTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  const isSendDisabled = useMemo(() => text.trim().length === 0 || selectedMembers.length === 0, [text, selectedMembers]);

  // Wyszukiwanie użytkowników
  useEffect(() => {
    if (searchQuery.length < 2) {
      setSearchResults([]);
      setShowDropdown(false);
      return;
    }

    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    searchTimeoutRef.current = setTimeout(async () => {
      setSearchLoading(true);
      try {
        const response = await fetch(`${apiBaseUrl}/search/usernames?username=${encodeURIComponent(searchQuery)}`, {
          credentials: "include",
        });
        if (response.ok) {
          const data = await response.json();
          // Nowy backend zwraca { result: [...] } z polami: id, name, profile_image_90, username
          const backendUsers = Array.isArray(data.result) ? data.result : [];
          // Mapuj format backendu na format frontendu
          const mappedUsers: UserSearchResult[] = backendUsers.map((user: any) => ({
            id: String(user.id),
            username: user.username || "",
            displayName: user.name || user.username || "",
            avatarUrl: user.profile_image_90 || "",
          }));
          setSearchResults(mappedUsers);
          setShowDropdown(mappedUsers.length > 0);
        } else {
          setSearchResults([]);
          setShowDropdown(false);
        }
      } catch (err) {
        logger.error("Błąd wyszukiwania użytkowników:", err);
      } finally {
        setSearchLoading(false);
      }
    }, 300);

    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [searchQuery]);

  // Załaduj preselected member (preselectedMember to username)
  useEffect(() => {
    if (preselectedMember && open) {
      const loadPreselectedUser = async () => {
        try {
          // Użyj search endpointu zamiast api/users, bo preselectedMember to username
          const response = await fetch(`${apiBaseUrl}/search/usernames?username=${encodeURIComponent(preselectedMember)}`, {
            credentials: "include",
          });
          if (response.ok) {
            const data = await response.json();
            const backendUsers = Array.isArray(data.result) ? data.result : [];
            // Znajdź użytkownika z dokładnie takim samym username
            const matchedUser = backendUsers.find((user: any) => user.username === preselectedMember);
            if (matchedUser) {
              // Mapuj format backendu na format frontendu
              const mappedUser: UserSearchResult = {
                id: String(matchedUser.id),
                username: matchedUser.username || "",
                displayName: matchedUser.name || matchedUser.username || "",
                avatarUrl: matchedUser.profile_image_90 || "",
              };
              setSelectedMembers([mappedUser]);
              setThreadType("direct");
            } else {
              // Użytkownik nie istnieje - wyświetl błąd
              setError("Użytkownik nie został znaleziony");
              logger.error("Użytkownik nie został znaleziony:", preselectedMember);
            }
          } else {
            // Błąd - wyświetl błąd
            setError("Błąd wyszukiwania użytkownika");
            logger.error("Błąd wyszukiwania użytkownika:", preselectedMember);
          }
        } catch (err) {
          logger.error("Błąd ładowania użytkownika:", err);
          setError("Błąd ładowania użytkownika");
        }
      };
      void loadPreselectedUser();
    }
  }, [preselectedMember, open, apiBaseUrl]);

  // Zamknij dropdown przy kliknięciu poza nim
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    if (showDropdown) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showDropdown]);

  // Resetuj stan gdy modal się zamyka
  useEffect(() => {
    if (!open) {
      // Resetuj stan tylko gdy modal się zamyka
      setText("");
      setSelectedMembers([]);
      setSearchQuery("");
      setNameInput("");
      setThreadType("direct");
      setError(null);
      setLoading(false);
      setShowDropdown(false);
    }
  }, [open]);

  const handleAddMember = (user: UserSearchResult) => {
    if (threadType === "direct" && selectedMembers.length >= 1) {
      // Direct może mieć tylko jednego użytkownika
      setSelectedMembers([user]);
    } else if (!selectedMembers.some((m) => m.id === user.id)) {
      setSelectedMembers([...selectedMembers, user]);
    }
    setSearchQuery("");
    setShowDropdown(false);
  };

  const handleRemoveMember = (userId: string) => {
    setSelectedMembers(selectedMembers.filter((m) => m.id !== userId));
  };

  const handleSubmit = async (event: Event) => {
    event.preventDefault();
    
    if (selectedMembers.length === 0) {
      setError("Wybierz co najmniej jednego użytkownika.");
      return;
    }
    if (isSendDisabled) {
      setError("Wiadomość nie może być pusta.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await onCreate({
        type: threadType,
        members: selectedMembers.map((m) => m.id),
        name: threadType === "direct" ? undefined : nameInput.trim() || undefined,
        message: { text: text.trim() },
      });
      // Modal pozostaje otwarty z loaderem - zostanie zamknięty przez App.tsx gdy wątek się pojawi
      // Nie czyścimy stanu tutaj - zostanie wyczyszczony gdy modal się zamknie
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      setError(message);
      setLoading(false);
    }
    // Nie resetujemy loading tutaj - pozostanie true aż modal się zamknie
  };

  if (!open) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
      <div className="w-full max-w-lg transform rounded-2xl border border-light-border bg-light-bg shadow-2xl transition-all dark:border-dark-border dark:bg-dark-bg-secondary">
        <div className="flex items-center justify-between border-b border-light-border px-6 py-4 dark:border-dark-border">
          <h3 className="text-lg font-bold text-light-text-primary dark:text-dark-text-primary">Nowa wiadomość</h3>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-light-text-secondary hover:bg-light-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-bg-tertiary"
          >
            <i className="fa-solid fa-xmark" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 px-6 py-5">
          <div className="grid grid-cols-2 gap-3">
            <label className="cursor-pointer">
              <input
                type="radio"
                name="thread_type"
                value="direct"
                checked={threadType === "direct"}
                onChange={() => setThreadType("direct")}
                className="sr-only"
              />
              <div
                className={`relative flex flex-col items-center rounded-xl border-2 p-4 transition-all ${
                  threadType === "direct"
                    ? "border-light-primary bg-light-primary/10 dark:border-dark-primary dark:bg-dark-primary/20"
                    : "border-light-border bg-light-bg-secondary dark:border-dark-border dark:bg-dark-bg-tertiary"
                }`}
              >
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-light-primary/10 text-light-primary dark:bg-dark-primary/20 dark:text-dark-primary">
                  <i className="fa-solid fa-user" />
                </div>
                <span className="text-sm font-medium text-light-text-primary dark:text-dark-text-primary">Wiadomość</span>
                <span className="text-xs text-light-text-tertiary dark:text-dark-text-tertiary">bezpośrednia</span>
              </div>
            </label>
            <label className="cursor-pointer">
              <input
                type="radio"
                name="thread_type"
                value="group"
                checked={threadType === "group"}
                onChange={() => setThreadType("group")}
                className="sr-only"
              />
              <div
                className={`relative flex flex-col items-center rounded-xl border-2 p-4 transition-all ${
                  threadType === "group"
                    ? "border-light-primary bg-light-primary/10 dark:border-dark-primary dark:bg-dark-primary/20"
                    : "border-light-border bg-light-bg-secondary dark:border-dark-border dark:bg-dark-bg-tertiary"
                }`}
              >
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-light-primary/10 text-light-primary dark:bg-dark-primary/20 dark:text-dark-primary">
                  <i className="fa-solid fa-users" />
                </div>
                <span className="text-sm font-medium text-light-text-primary dark:text-dark-text-primary">Wątek</span>
                <span className="text-xs text-light-text-tertiary dark:text-dark-text-tertiary">grupowy</span>
              </div>
            </label>
          </div>

          <div className="space-y-3">
            <div className="relative" ref={dropdownRef}>
              <label className="mb-1 block text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary">
                {threadType === "direct" ? "Do (wybierz użytkownika)" : "Członkowie (wybierz użytkowników)"}
              </label>
              
              {/* Wybrani użytkownicy */}
              {selectedMembers.length > 0 && (
                <div className="mb-2 flex flex-wrap gap-2">
                  {selectedMembers.map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center gap-2 rounded-full bg-light-primary/10 px-3 py-1 text-sm dark:bg-dark-primary/20"
                    >
                      {member.avatarUrl ? (
                        <img src={member.avatarUrl} alt={member.displayName} className="h-5 w-5 rounded-full" />
                      ) : (
                        <div className="h-5 w-5 rounded-full bg-gradient-to-br from-indigo-500 to-sky-500" />
                      )}
                      <span className="text-light-text-primary dark:text-dark-text-primary">
                        {member.displayName || member.username}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveMember(member.id)}
                        className="text-light-text-secondary hover:text-light-text-primary dark:text-dark-text-secondary dark:hover:text-dark-text-primary"
                      >
                        <i className="fa-solid fa-xmark" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Input wyszukiwania */}
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onInput={(e) => setSearchQuery((e.target as HTMLInputElement).value)}
                  onFocus={() => {
                    if (searchQuery.length >= 2 && searchResults.length > 0) {
                      setShowDropdown(true);
                    }
                  }}
                  placeholder="Wpisz 2 znaki aby wyszukać..."
                  disabled={threadType === "direct" && selectedMembers.length >= 1}
                  className="w-full rounded-lg border border-light-border bg-light-bg-tertiary px-3 py-2 text-sm text-light-text-primary placeholder-light-text-tertiary outline-none focus:ring-2 focus:ring-light-primary disabled:opacity-50 dark:border-dark-border dark:bg-dark-bg-tertiary dark:text-dark-text-primary dark:placeholder-dark-text-tertiary dark:focus:ring-dark-primary"
                />
                {searchLoading && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <i className="fa-solid fa-spinner fa-spin text-light-text-tertiary dark:text-dark-text-tertiary" />
                  </div>
                )}
              </div>

              {/* Dropdown z wynikami */}
              {showDropdown && searchResults.length > 0 && (
                <div className="absolute z-50 mt-1 max-h-60 w-full overflow-y-auto rounded-lg border border-light-border bg-light-bg shadow-lg dark:border-dark-border dark:bg-dark-bg-secondary">
                  {searchResults.map((user) => (
                    <button
                      key={user.id}
                      type="button"
                      onClick={() => handleAddMember(user)}
                      disabled={selectedMembers.some((m) => m.id === user.id)}
                      className="flex w-full items-center gap-3 px-4 py-2 text-left transition-colors hover:bg-light-bg-tertiary disabled:opacity-50 dark:hover:bg-dark-bg-tertiary"
                    >
                      {user.avatarUrl ? (
                        <img src={user.avatarUrl} alt={user.displayName} className="h-8 w-8 rounded-full" />
                      ) : (
                        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-indigo-500 to-sky-500" />
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium text-light-text-primary dark:text-dark-text-primary">
                          {user.displayName}
                        </div>
                        <div className="text-xs text-light-text-tertiary dark:text-dark-text-tertiary">
                          @{user.username}
                        </div>
                      </div>
                      {selectedMembers.some((m) => m.id === user.id) && (
                        <i className="fa-solid fa-check text-light-primary dark:text-dark-primary" />
                      )}
                    </button>
                  ))}
                </div>
              )}

              {showDropdown && searchQuery.length >= 2 && searchResults.length === 0 && !searchLoading && (
                <div className="absolute z-50 mt-1 w-full rounded-lg border border-light-border bg-light-bg px-4 py-3 text-sm text-light-text-secondary shadow-lg dark:border-dark-border dark:bg-dark-bg-secondary dark:text-dark-text-secondary">
                  Nie znaleziono użytkowników
                </div>
              )}
            </div>

            {threadType !== "direct" ? (
              <div>
                <label className="mb-1 block text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary">Nazwa wątku</label>
                <input
                  type="text"
                  value={nameInput}
                  onInput={(e) => setNameInput((e.target as HTMLInputElement).value)}
                  placeholder="np. Grupa eventowa"
                  className="w-full rounded-lg border border-light-border bg-light-bg-tertiary px-3 py-2 text-sm text-light-text-primary placeholder-light-text-tertiary outline-none focus:ring-2 focus:ring-light-primary dark:border-dark-border dark:bg-dark-bg-tertiary dark:text-dark-text-primary dark:placeholder-dark-text-tertiary dark:focus:ring-dark-primary"
                />
              </div>
            ) : null}

            <div>
              <label className="mb-1 block text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary">Wiadomość</label>
              <textarea
                value={text}
                onInput={(e) => setText((e.target as HTMLTextAreaElement).value)}
                rows={4}
                placeholder="Hejka co tam?"
                className="w-full resize-none rounded-lg border border-light-border bg-light-bg-tertiary px-3 py-2 text-sm text-light-text-primary placeholder-light-text-tertiary outline-none focus:ring-2 focus:ring-light-primary dark:border-dark-border dark:bg-dark-bg-tertiary dark:text-dark-text-primary dark:placeholder-dark-text-tertiary dark:focus:ring-dark-primary"
              />
            </div>
          </div>

          {error ? <div className="text-sm text-red-500">{error}</div> : null}

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg px-4 py-2 text-sm font-semibold text-light-text-secondary hover:bg-light-bg-tertiary dark:text-dark-text-secondary dark:hover:bg-dark-bg-tertiary"
            >
              Anuluj
            </button>
            <button
              type="submit"
              disabled={loading || isSendDisabled}
              className="rounded-lg bg-light-primary px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-light-primary-hover disabled:opacity-60 dark:bg-dark-primary dark:hover:bg-dark-primary-hover"
            >
              {loading ? "Tworzę..." : "Utwórz wątek"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

