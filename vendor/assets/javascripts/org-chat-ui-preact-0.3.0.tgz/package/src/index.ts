// Re-export everything from shared
export * from "@org/chat-ui-shared";

// Web-specific hooks
export { usePageVisibility } from "./hooks/usePageVisibility";
export { useChatStyles } from "./hooks/useChatStyles";

// Web-specific components
export { ChatLayout, ChatLayoutSkeleton, ChatLayoutError, type ChatLayoutProps } from "./components/ChatLayout";
export { ThreadsList, type ThreadsListProps } from "./components/ThreadsPanel";
export { ThreadView } from "./components/ThreadScreen";
export { MessageItem } from "./components/MessageItem";
export { Composer } from "./components/Composer";
export { AcceptConversation } from "./components/AcceptConversation";
export { NewThreadModal } from "./components/NewThreadModal";
