import { useCallback, useEffect, useMemo, useState } from "react";
import type { Message, Thread } from "@org/chat-core";
import { useThread, UiMessage } from "./useThread";
import { ChatGloballyBannedError } from "@org/chat-core";

export interface UseThreadStateOptions {
  threadId: string;
  thread?: Thread | null;
  currentUserId: string;
  isActive?: boolean;
  onThreadActivity?: () => Promise<void> | void;
}

export interface UseThreadStateResult {
  messages: UiMessage[];
  replyingTo: Message | null;
  setReplyingTo: (message: Message | null) => void;
  clearReply: () => void;
  send: (input: { text?: string; imageUrl?: string }) => Promise<void>;
  retry: (localId: string) => Promise<void>;
  likeMessage: (messageId: string) => Promise<void>;
  unlikeMessage: (messageId: string) => Promise<void>;
  sendError: string | null;
  clearError: () => void;
  canSend: boolean;
  typingUsers: string[];
  onTyping: () => Promise<void>;
  onStopTyping: () => Promise<void>;
  loadOlder: () => Promise<void>;
  loadingOlder: boolean;
  hasMoreOlder: boolean;
}

/**
 * Logika sterująca widokiem pojedynczego wątku (odpowiedzi, read receipts, wysyłanie).
 * Oparta wyłącznie o ChatClient, niezależna od renderera.
 */
export function useThreadState({
  threadId,
  thread,
  currentUserId,
  isActive = true,
  onThreadActivity,
}: UseThreadStateOptions): UseThreadStateResult {
  const { messages, send, retry, like, unlike, markAsRead, typingUsers, setTyping, loadOlder, loadingOlder, hasMoreOlder } =
    useThread(threadId, currentUserId);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [sendError, setSendError] = useState<string | null>(null);
  const [globallyBanned, setGloballyBanned] = useState<boolean>(false);

  const unreadFromOthers = useMemo(
    () =>
      messages.filter(
        (message) => message.senderId !== currentUserId && !message.readBy.includes(currentUserId)
      ),
    [messages, currentUserId]
  );

  // Stabilna wartość string zamiast tablicy - zapobiega niepotrzebnym uruchomieniom useEffect
  // gdy tablica ma nową referencję ale te same elementy
  const unreadMessageIds = useMemo(
    () => unreadFromOthers.map((m) => m.id).join(","),
    [unreadFromOthers]
  );

  const isCommunityBanned = thread?.type === "community" && (thread.bannedMembers ?? []).includes(currentUserId);
  const needsConsent = thread?.type === "group" && !(thread.acceptedBy ?? []).includes(currentUserId);

  // WAIT_FOR_REPLY: w direct threads, jeśli wątek nie jest odblokowany
  // i ostatnia wiadomość była od obecnego użytkownika - musi czekać na odpowiedź
  const isWaitingForReply = thread?.type === "direct"
    && !(thread as { directUnlocked?: boolean }).directUnlocked
    && thread.lastMessage?.senderId === currentUserId;

  // Automatyczne oznaczanie jako przeczytane, gdy wątek jest aktywny/widoczny
  useEffect(() => {
    if (!isActive || unreadFromOthers.length === 0 || needsConsent) {
      return;
    }

    let cancelled = false;
    const markUnread = async () => {
      await Promise.all(unreadFromOthers.map((message: UiMessage) => markAsRead(message.id)));
      if (!cancelled) {
        await onThreadActivity?.();
      }
    };

    void markUnread();
    return () => {
      cancelled = true;
    };
  }, [isActive, unreadMessageIds, markAsRead, onThreadActivity, needsConsent, unreadFromOthers]);

  // Odświeżenie listy wątków, gdy pojawia się nowa wiadomość
  const latestMessageId = messages[messages.length - 1]?.id;
  useEffect(() => {
    if (!latestMessageId) {
      return;
    }
    void onThreadActivity?.();
  }, [latestMessageId, onThreadActivity]);

  const canSend = !globallyBanned && !isCommunityBanned && !needsConsent && !isWaitingForReply;

  const handleSend = useCallback(
    async (input: { text?: string; imageUrl?: string }) => {
      if (!canSend) {
        setSendError("Brak uprawnień do wysyłania wiadomości.");
        return;
      }
      setSendError(null);
      try {
        await send({ ...input, replyToId: replyingTo?.id });
        setReplyingTo(null);
        await onThreadActivity?.();
      } catch (err) {
        if (err instanceof ChatGloballyBannedError) {
          setGloballyBanned(true);
          setSendError(err.message);
          return;
        }
        const message = err instanceof Error ? err.message : "Failed to send message";
        setSendError(message);
        throw err;
      }
    },
    [send, replyingTo, onThreadActivity, canSend]
  );

  const handleRetry = useCallback(
    async (localId: string) => {
      await retry(localId);
    },
    [retry]
  );

  const clearReply = useCallback(() => setReplyingTo(null), []);

  const handleTyping = useCallback(async () => {
    if (!canSend) {
      return;
    }
    try {
      await setTyping(true);
    } catch (err) {
      if (err instanceof ChatGloballyBannedError) {
        setGloballyBanned(true);
        setSendError(err.message);
      }
    }
  }, [canSend, setTyping]);

  const handleTypingStop = useCallback(async () => {
    try {
      await setTyping(false);
    } catch (err) {
      if (err instanceof ChatGloballyBannedError) {
        setGloballyBanned(true);
        setSendError(err.message);
      }
    }
  }, [setTyping]);

  return {
    messages,
    replyingTo,
    setReplyingTo,
    clearReply,
    send: handleSend,
    retry: handleRetry,
    likeMessage: like,
    unlikeMessage: unlike,
    sendError,
    clearError: () => setSendError(null),
    canSend,
    typingUsers,
    onTyping: handleTyping,
    onStopTyping: handleTypingStop,
    loadOlder,
    loadingOlder,
    hasMoreOlder,
  };
}
